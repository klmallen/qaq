/**
 * QAQ游戏引擎 - 2D节点演示
 * 
 * 使用QAQ游戏引擎的正确架构来创建2D节点演示
 */

import Engine from '../core/engine/Engine'
import Scene from '../core/scene/Scene'
import Node2D from '../core/nodes/Node2D'
import Sprite2D from '../core/nodes/2d/Sprite2D'
import AnimatedSprite2D from '../core/nodes/2d/AnimatedSprite2D'
import Label, { TextAlign, VerticalAlign } from '../core/nodes/2d/Label'
import Button from '../core/nodes/2d/Button'
import Panel from '../core/nodes/2d/Panel'
import TextureRect from '../core/nodes/2d/TextureRect'
import * as THREE from 'three'

/**
 * QAQ 2D节点演示类
 */
export class QAQ2DDemo {
  private engine: Engine | null = null
  private scene: Scene | null = null
  private rootNode: Node2D | null = null
  private isInitialized: boolean = false
  private isRunning: boolean = false
  
  // 演示节点
  private demoNodes: Node2D[] = []
  
  // 统计信息
  private stats = {
    fps: 0,
    nodeCount: 0,
    renderTime: 0
  }
  
  /**
   * 初始化演示系统
   */
  async initialize(containerId: string, width: number = 800, height: number = 600): Promise<boolean> {
    try {
      console.log('🚀 初始化QAQ 2D节点演示...')
      
      // 获取容器元素
      const container = document.getElementById(containerId)
      if (!container) {
        throw new Error(`找不到容器元素: ${containerId}`)
      }
      
      // 获取引擎实例
      this.engine = Engine.getInstance()
      
      // 初始化引擎
      const success = await this.engine.initialize({
        container: container,
        width: width,
        height: height,
        antialias: true,
        enableShadows: false // 2D演示不需要阴影
      })
      
      if (!success) {
        throw new Error('引擎初始化失败')
      }
      
      // 切换到2D模式
      this.engine.switchTo2D()
      
      // 创建演示场景
      await this.createDemoScene()
      
      this.isInitialized = true
      console.log('✅ QAQ 2D节点演示初始化完成')
      
      return true
      
    } catch (error) {
      console.error('❌ 演示初始化失败:', error)
      return false
    }
  }
  
  /**
   * 创建演示场景
   */
  private async createDemoScene(): Promise<void> {
    if (!this.engine) return
    
    console.log('🎨 创建2D演示场景...')
    
    // 创建场景
    this.scene = new Scene('2DDemo', {
      type: 'MAIN',
      persistent: false,
      autoStart: true
    })
    
    // 创建根节点
    this.rootNode = new Node2D('Root2D')
    this.scene.addChild(this.rootNode)
    
    // 创建演示内容
    await this.createDemoContent()
    
    // 设置为主场景
    await this.engine.setMainScene(this.scene)
    
    console.log(`✅ 创建了 ${this.demoNodes.length} 个演示节点`)
  }
  
  /**
   * 创建演示内容
   */
  private async createDemoContent(): Promise<void> {
    if (!this.rootNode) return
    
    // 创建背景面板
    const backgroundPanel = new Panel('Background', {
      size: { width: 400, height: 300 },
      backgroundColor: '#2d2d2d',
      borderColor: '#404040',
      borderWidth: 2
    })
    backgroundPanel.position = { x: 0, y: 0, z: -1 }
    this.rootNode.addChild(backgroundPanel)
    this.demoNodes.push(backgroundPanel)
    
    // 创建标题标签
    const titleLabel = new Label('Title', {
      text: 'QAQ 2D节点演示',
      style: {
        fontSize: 32,
        color: '#ffffff',
        fontFamily: 'Arial'
      },
      align: TextAlign.CENTER,
      verticalAlign: VerticalAlign.MIDDLE
    })
    titleLabel.position = { x: 0, y: 100, z: 0 }
    this.rootNode.addChild(titleLabel)
    this.demoNodes.push(titleLabel)
    
    // 创建彩色精灵
    await this.createColoredSprites()
    
    // 创建信息标签
    const infoLabel = new Label('Info', {
      text: '基础2D节点渲染测试',
      style: {
        fontSize: 18,
        color: '#cccccc',
        fontFamily: 'Arial'
      },
      align: TextAlign.CENTER
    })
    infoLabel.position = { x: 0, y: -40, z: 0 }
    this.rootNode.addChild(infoLabel)
    this.demoNodes.push(infoLabel)
    
    // 创建交互按钮
    await this.createInteractiveButtons()
    
    // 更新统计信息
    this.stats.nodeCount = this.demoNodes.length
  }
  
  /**
   * 创建彩色精灵
   */
  private async createColoredSprites(): Promise<void> {
    if (!this.rootNode) return
    
    const colors = ['#ff6b35', '#4a90e2', '#28a745', '#ffc107']
    const positions = [-150, -50, 50, 150]
    
    for (let i = 0; i < colors.length; i++) {
      // 创建彩色纹理
      const canvas = document.createElement('canvas')
      canvas.width = 80
      canvas.height = 80
      const ctx = canvas.getContext('2d')!
      
      ctx.fillStyle = colors[i]
      ctx.fillRect(0, 0, 80, 80)
      
      // 添加一些细节
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(10, 10, 60, 60)
      ctx.fillStyle = colors[i]
      ctx.fillRect(20, 20, 40, 40)
      
      const texture = new THREE.CanvasTexture(canvas)
      
      // 创建精灵
      const sprite = new Sprite2D(`Sprite${i + 1}`)
      sprite.texture = texture
      sprite.position = { x: positions[i], y: 20, z: 0 }
      sprite.size = { width: 80, height: 80 }
      
      this.rootNode.addChild(sprite)
      this.demoNodes.push(sprite)
    }
  }
  
  /**
   * 创建交互按钮
   */
  private async createInteractiveButtons(): Promise<void> {
    if (!this.rootNode) return
    
    // 旋转精灵按钮
    const rotateButton = new Button('RotateButton', {
      text: '旋转精灵',
      styles: {
        normal: {
          backgroundColor: '#007bff',
          textColor: '#ffffff',
          borderColor: '#0056b3',
          borderWidth: 2
        },
        hover: {
          backgroundColor: '#0069d9',
          textColor: '#ffffff'
        },
        pressed: {
          backgroundColor: '#0056b3',
          textColor: '#ffffff'
        }
      }
    })
    rotateButton.position = { x: -60, y: -100, z: 0 }
    rotateButton.size = { width: 100, height: 35 }
    
    rotateButton.setOnPressed(() => {
      console.log('旋转精灵按钮被点击')
      this.rotateSprites()
    })
    
    this.rootNode.addChild(rotateButton)
    this.demoNodes.push(rotateButton)
    
    // 改变颜色按钮
    const colorButton = new Button('ColorButton', {
      text: '改变颜色',
      styles: {
        normal: {
          backgroundColor: '#28a745',
          textColor: '#ffffff',
          borderColor: '#1e7e34',
          borderWidth: 2
        },
        hover: {
          backgroundColor: '#218838',
          textColor: '#ffffff'
        },
        pressed: {
          backgroundColor: '#1e7e34',
          textColor: '#ffffff'
        }
      }
    })
    colorButton.position = { x: 60, y: -100, z: 0 }
    colorButton.size = { width: 100, height: 35 }
    
    colorButton.setOnPressed(() => {
      console.log('改变颜色按钮被点击')
      this.changeColors()
    })
    
    this.rootNode.addChild(colorButton)
    this.demoNodes.push(colorButton)
  }
  
  /**
   * 旋转精灵
   */
  private rotateSprites(): void {
    this.demoNodes.forEach(node => {
      if (node.name.startsWith('Sprite')) {
        const currentRotation = node.rotation?.z || 0
        node.rotation = { x: 0, y: 0, z: currentRotation + Math.PI / 4 }
      }
    })
  }
  
  /**
   * 改变颜色
   */
  private changeColors(): void {
    const colors = ['#ff6b35', '#4a90e2', '#28a745', '#ffc107', '#dc3545', '#6f42c1']
    
    this.demoNodes.forEach(node => {
      if (node instanceof Sprite2D && node.name.startsWith('Sprite')) {
        const randomColor = colors[Math.floor(Math.random() * colors.length)]
        
        // 重新创建纹理
        const canvas = document.createElement('canvas')
        canvas.width = 80
        canvas.height = 80
        const ctx = canvas.getContext('2d')!
        
        ctx.fillStyle = randomColor
        ctx.fillRect(0, 0, 80, 80)
        
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(10, 10, 60, 60)
        ctx.fillStyle = randomColor
        ctx.fillRect(20, 20, 40, 40)
        
        const texture = new THREE.CanvasTexture(canvas)
        node.texture = texture
      }
    })
  }
  
  /**
   * 启动演示
   */
  start(): void {
    if (!this.isInitialized || !this.engine) return
    
    this.engine.startRendering()
    this.isRunning = true
    
    console.log('▶️ QAQ 2D演示开始运行')
  }
  
  /**
   * 停止演示
   */
  stop(): void {
    if (!this.engine) return
    
    this.engine.stopRendering()
    this.isRunning = false
    
    console.log('⏹️ QAQ 2D演示停止运行')
  }
  
  /**
   * 获取统计信息
   */
  getStats() {
    if (this.engine) {
      // 从引擎获取实际统计信息
      const engineStats = this.engine.getStats()
      this.stats.fps = engineStats.fps || 60
      this.stats.renderTime = engineStats.renderTime || 0
    }
    
    return { ...this.stats }
  }
  
  /**
   * 模拟按钮点击
   */
  clickButton(buttonName: string): void {
    const button = this.demoNodes.find(node => node.name === buttonName && node instanceof Button) as Button
    if (button) {
      button.click()
    }
  }
  
  /**
   * 销毁演示系统
   */
  destroy(): void {
    this.stop()
    
    // 清理节点
    this.demoNodes = []
    
    if (this.engine) {
      this.engine.shutdown()
    }
    
    this.scene = null
    this.rootNode = null
    this.engine = null
    this.isInitialized = false
    
    console.log('🗑️ QAQ 2D演示系统已销毁')
  }
}
