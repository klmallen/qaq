/**
 * QAQ游戏引擎 - 简单2D相机和节点通信演示
 * 
 * 展示：
 * 1. 2D相机的创建和控制
 * 2. 按钮节点的创建和交互
 * 3. 节点间的通信机制
 */

import * as THREE from 'three'

// ============================================================================
// 简单的节点通信系统
// ============================================================================

/**
 * 简单的事件系统
 */
class SimpleEventSystem {
  private listeners: Map<string, Function[]> = new Map()
  
  /**
   * 监听事件
   */
  on(event: string, callback: Function): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, [])
    }
    this.listeners.get(event)!.push(callback)
  }
  
  /**
   * 触发事件
   */
  emit(event: string, ...args: any[]): void {
    const callbacks = this.listeners.get(event)
    if (callbacks) {
      callbacks.forEach(callback => callback(...args))
    }
  }
  
  /**
   * 移除监听
   */
  off(event: string, callback: Function): void {
    const callbacks = this.listeners.get(event)
    if (callbacks) {
      const index = callbacks.indexOf(callback)
      if (index > -1) {
        callbacks.splice(index, 1)
      }
    }
  }
}

// 全局事件系统实例
const eventSystem = new SimpleEventSystem()

// ============================================================================
// 简单的2D节点基类
// ============================================================================

/**
 * 简单的2D节点基类
 */
class Simple2DNode {
  public position: THREE.Vector3 = new THREE.Vector3()
  public scale: THREE.Vector3 = new THREE.Vector3(1, 1, 1)
  public rotation: number = 0
  public visible: boolean = true
  public mesh: THREE.Mesh | null = null
  public children: Simple2DNode[] = []
  public parent: Simple2DNode | null = null
  
  constructor(public name: string) {}
  
  /**
   * 添加子节点
   */
  addChild(child: Simple2DNode): void {
    child.parent = this
    this.children.push(child)
  }
  
  /**
   * 移除子节点
   */
  removeChild(child: Simple2DNode): void {
    const index = this.children.indexOf(child)
    if (index > -1) {
      child.parent = null
      this.children.splice(index, 1)
    }
  }
  
  /**
   * 更新节点
   */
  update(deltaTime: number): void {
    if (this.mesh) {
      this.mesh.position.copy(this.position)
      this.mesh.scale.copy(this.scale)
      this.mesh.rotation.z = this.rotation
      this.mesh.visible = this.visible
    }
    
    // 更新子节点
    this.children.forEach(child => child.update(deltaTime))
  }
  
  /**
   * 添加到场景
   */
  addToScene(scene: THREE.Scene): void {
    if (this.mesh) {
      scene.add(this.mesh)
    }
    this.children.forEach(child => child.addToScene(scene))
  }
  
  /**
   * 从场景移除
   */
  removeFromScene(scene: THREE.Scene): void {
    if (this.mesh) {
      scene.remove(this.mesh)
    }
    this.children.forEach(child => child.removeFromScene(scene))
  }
  
  /**
   * 发送消息给其他节点
   */
  sendMessage(event: string, data?: any): void {
    eventSystem.emit(event, { sender: this, data })
  }
  
  /**
   * 监听消息
   */
  listenMessage(event: string, callback: (message: { sender: Simple2DNode, data?: any }) => void): void {
    eventSystem.on(event, callback)
  }
}

/**
 * 简单的2D相机
 */
class Simple2DCamera extends Simple2DNode {
  public camera: THREE.OrthographicCamera
  public zoom: number = 1
  public followTarget: Simple2DNode | null = null
  public followSpeed: number = 5
  
  constructor(name: string, width: number, height: number) {
    super(name)
    
    // 创建正交相机
    const aspect = width / height
    const frustumSize = 600
    this.camera = new THREE.OrthographicCamera(
      -frustumSize * aspect / 2,
      frustumSize * aspect / 2,
      frustumSize / 2,
      -frustumSize / 2,
      1,
      1000
    )
    this.camera.position.z = 100
  }
  
  /**
   * 设置缩放
   */
  setZoom(zoom: number): void {
    this.zoom = zoom
    this.camera.zoom = zoom
    this.camera.updateProjectionMatrix()
  }
  
  /**
   * 设置跟随目标
   */
  setFollowTarget(target: Simple2DNode | null): void {
    this.followTarget = target
  }
  
  /**
   * 更新相机
   */
  update(deltaTime: number): void {
    super.update(deltaTime)
    
    // 跟随目标
    if (this.followTarget) {
      const targetPos = this.followTarget.position
      const currentPos = this.camera.position
      
      // 平滑跟随
      currentPos.x += (targetPos.x - currentPos.x) * this.followSpeed * deltaTime
      currentPos.y += (targetPos.y - currentPos.y) * this.followSpeed * deltaTime
    } else {
      // 使用节点位置
      this.camera.position.x = this.position.x
      this.camera.position.y = this.position.y
    }
  }
}

/**
 * 简单的按钮节点
 */
class SimpleButton extends Simple2DNode {
  private canvas: HTMLCanvasElement
  private context: CanvasRenderingContext2D
  private texture: THREE.CanvasTexture
  private isHovered: boolean = false
  private isPressed: boolean = false
  private onClick?: () => void
  private buttonText: string
  
  constructor(name: string, text: string = 'Button', width: number = 120, height: number = 40) {
    super(name)
    
    this.buttonText = text
    
    // 创建Canvas用于按钮渲染
    this.canvas = document.createElement('canvas')
    this.canvas.width = width * 2 // 高分辨率
    this.canvas.height = height * 2
    this.context = this.canvas.getContext('2d')!
    
    // 创建纹理
    this.texture = new THREE.CanvasTexture(this.canvas)
    
    // 创建几何体和材质
    const geometry = new THREE.PlaneGeometry(width, height)
    const material = new THREE.MeshBasicMaterial({
      map: this.texture,
      transparent: true,
      side: THREE.DoubleSide
    })
    
    this.mesh = new THREE.Mesh(geometry, material)
    this.mesh.name = name
    
    // 渲染按钮
    this.renderButton()
    
    // 监听全局消息
    this.setupMessageListeners()
  }
  
  /**
   * 设置按钮文本
   */
  setText(text: string): void {
    this.buttonText = text
    this.renderButton()
  }
  
  /**
   * 渲染按钮
   */
  private renderButton(): void {
    const width = this.canvas.width
    const height = this.canvas.height
    
    // 清除画布
    this.context.clearRect(0, 0, width, height)
    
    // 绘制按钮背景
    this.context.fillStyle = this.isPressed ? '#0056b3' : (this.isHovered ? '#0069d9' : '#007bff')
    this.context.fillRect(0, 0, width, height)
    
    // 绘制边框
    this.context.strokeStyle = '#0056b3'
    this.context.lineWidth = 4
    this.context.strokeRect(2, 2, width - 4, height - 4)
    
    // 绘制文本
    this.context.fillStyle = '#ffffff'
    this.context.font = 'bold 24px Arial'
    this.context.textAlign = 'center'
    this.context.textBaseline = 'middle'
    this.context.fillText(this.buttonText, width / 2, height / 2)
    
    // 更新纹理
    this.texture.needsUpdate = true
  }
  
  /**
   * 设置点击回调
   */
  setOnClick(callback: () => void): void {
    this.onClick = callback
  }
  
  /**
   * 模拟点击
   */
  click(): void {
    this.isPressed = true
    this.renderButton()
    
    setTimeout(() => {
      this.isPressed = false
      this.renderButton()
    }, 150)
    
    this.onClick?.()
  }
  
  /**
   * 设置消息监听
   */
  private setupMessageListeners(): void {
    // 监听相机缩放消息
    this.listenMessage('camera_zoom_changed', (message) => {
      console.log(`${this.name} 收到相机缩放消息:`, message.data)
    })
    
    // 监听其他按钮的点击消息
    this.listenMessage('button_clicked', (message) => {
      if (message.sender !== this) {
        console.log(`${this.name} 收到其他按钮点击消息:`, message.sender.name)
      }
    })
  }
}

/**
 * 简单的精灵节点
 */
class SimpleSprite extends Simple2DNode {
  constructor(name: string, width: number = 100, height: number = 100, color: string = '#ffffff') {
    super(name)
    
    // 创建几何体和材质
    const geometry = new THREE.PlaneGeometry(width, height)
    const material = new THREE.MeshBasicMaterial({ 
      color: color,
      transparent: true,
      side: THREE.DoubleSide
    })
    
    this.mesh = new THREE.Mesh(geometry, material)
    this.mesh.name = name
  }
  
  /**
   * 设置颜色
   */
  setColor(color: string): void {
    if (this.mesh && this.mesh.material instanceof THREE.MeshBasicMaterial) {
      this.mesh.material.color.setStyle(color)
    }
  }
}

// ============================================================================
// 简单的2D相机演示系统
// ============================================================================

/**
 * 简单的2D相机演示系统
 */
export class Simple2DCameraDemo {
  private renderer: THREE.WebGLRenderer | null = null
  private scene: THREE.Scene | null = null
  private camera: Simple2DCamera | null = null
  private rootNode: Simple2DNode | null = null
  private animationId: number = 0
  private isRunning: boolean = false
  
  // 演示节点
  private button1: SimpleButton | null = null
  private button2: SimpleButton | null = null
  private targetSprite: SimpleSprite | null = null
  
  // 统计信息
  private stats = {
    fps: 0,
    nodeCount: 0,
    renderTime: 0
  }
  
  private lastTime: number = 0
  private frameCount: number = 0
  private fpsUpdateTime: number = 0
  
  /**
   * 初始化演示系统
   */
  async initialize(containerId: string, width: number = 800, height: number = 600): Promise<boolean> {
    try {
      console.log('🚀 初始化2D相机演示系统...')
      
      // 获取容器元素
      const container = document.getElementById(containerId)
      if (!container) {
        throw new Error(`找不到容器元素: ${containerId}`)
      }
      
      // 创建渲染器
      this.renderer = new THREE.WebGLRenderer({ 
        antialias: true,
        alpha: true
      })
      this.renderer.setSize(width, height)
      this.renderer.setClearColor(0x222222, 1)
      
      // 添加到容器
      container.innerHTML = '' // 清空容器
      container.appendChild(this.renderer.domElement)
      
      // 创建场景
      this.scene = new THREE.Scene()
      
      // 创建2D相机
      this.camera = new Simple2DCamera('MainCamera', width, height)
      
      // 创建根节点
      this.rootNode = new Simple2DNode('Root')
      
      // 创建演示内容
      this.createDemoContent()
      
      console.log('✅ 2D相机演示系统初始化完成')
      return true
      
    } catch (error) {
      console.error('❌ 演示系统初始化失败:', error)
      return false
    }
  }
  
  /**
   * 创建演示内容
   */
  private createDemoContent(): void {
    if (!this.scene || !this.rootNode) return
    
    console.log('🎨 创建演示内容...')
    
    // 创建目标精灵（相机跟随目标）
    this.targetSprite = new SimpleSprite('Target', 60, 60, '#ff6b35')
    this.targetSprite.position.set(0, 0, 0)
    this.rootNode.addChild(this.targetSprite)
    
    // 创建按钮1 - 控制相机缩放
    this.button1 = new SimpleButton('ZoomButton', '缩放相机', 120, 40)
    this.button1.position.set(-100, -150, 0)
    this.button1.setOnClick(() => {
      console.log('缩放相机按钮被点击')
      this.zoomCamera()
      this.button1!.sendMessage('button_clicked', { action: 'zoom_camera' })
    })
    this.rootNode.addChild(this.button1)
    
    // 创建按钮2 - 移动目标
    this.button2 = new SimpleButton('MoveButton', '移动目标', 120, 40)
    this.button2.position.set(100, -150, 0)
    this.button2.setOnClick(() => {
      console.log('移动目标按钮被点击')
      this.moveTarget()
      this.button2!.sendMessage('button_clicked', { action: 'move_target' })
    })
    this.rootNode.addChild(this.button2)
    
    // 设置相机跟随目标
    this.camera!.setFollowTarget(this.targetSprite)
    
    // 添加所有节点到场景
    this.rootNode.addToScene(this.scene)
    
    // 更新统计信息
    this.stats.nodeCount = this.countNodes(this.rootNode)
    
    console.log(`✅ 创建了 ${this.stats.nodeCount} 个演示节点`)
  }
  
  /**
   * 计算节点数量
   */
  private countNodes(node: Simple2DNode): number {
    let count = 1
    node.children.forEach(child => {
      count += this.countNodes(child)
    })
    return count
  }
  
  /**
   * 缩放相机
   */
  private zoomCamera(): void {
    if (!this.camera) return
    
    const currentZoom = this.camera.zoom
    const newZoom = currentZoom >= 2 ? 0.5 : currentZoom + 0.5
    
    this.camera.setZoom(newZoom)
    this.camera.sendMessage('camera_zoom_changed', { zoom: newZoom })
    
    console.log(`相机缩放设置为: ${newZoom}`)
  }
  
  /**
   * 移动目标
   */
  private moveTarget(): void {
    if (!this.targetSprite) return
    
    // 随机移动目标
    const x = (Math.random() - 0.5) * 400
    const y = (Math.random() - 0.5) * 300
    
    this.targetSprite.position.set(x, y, 0)
    this.targetSprite.sendMessage('target_moved', { position: { x, y } })
    
    console.log(`目标移动到: (${x.toFixed(1)}, ${y.toFixed(1)})`)
  }
  
  /**
   * 启动演示
   */
  start(): void {
    if (this.isRunning) return
    
    this.isRunning = true
    this.lastTime = performance.now()
    this.animate()
    
    console.log('▶️ 2D相机演示开始运行')
  }
  
  /**
   * 停止演示
   */
  stop(): void {
    this.isRunning = false
    if (this.animationId) {
      cancelAnimationFrame(this.animationId)
      this.animationId = 0
    }
    
    console.log('⏹️ 2D相机演示停止运行')
  }
  
  /**
   * 动画循环
   */
  private animate = (): void => {
    if (!this.isRunning) return
    
    const currentTime = performance.now()
    const deltaTime = (currentTime - this.lastTime) / 1000
    this.lastTime = currentTime
    
    // 更新FPS
    this.frameCount++
    if (currentTime - this.fpsUpdateTime >= 1000) {
      this.stats.fps = Math.round(this.frameCount * 1000 / (currentTime - this.fpsUpdateTime))
      this.frameCount = 0
      this.fpsUpdateTime = currentTime
    }
    
    // 更新所有节点
    const renderStart = performance.now()
    if (this.rootNode) {
      this.rootNode.update(deltaTime)
    }
    if (this.camera) {
      this.camera.update(deltaTime)
    }
    
    // 渲染场景
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera.camera)
    }
    
    this.stats.renderTime = performance.now() - renderStart
    
    this.animationId = requestAnimationFrame(this.animate)
  }
  
  /**
   * 获取统计信息
   */
  getStats() {
    return { ...this.stats }
  }
  
  /**
   * 模拟按钮点击
   */
  clickButton(buttonName: string): void {
    if (buttonName === 'ZoomButton' && this.button1) {
      this.button1.click()
    } else if (buttonName === 'MoveButton' && this.button2) {
      this.button2.click()
    }
  }
  
  /**
   * 销毁演示系统
   */
  destroy(): void {
    this.stop()
    
    // 清理节点
    if (this.scene && this.rootNode) {
      this.rootNode.removeFromScene(this.scene)
    }
    
    // 清理Three.js对象
    if (this.renderer) {
      this.renderer.dispose()
      this.renderer = null
    }
    
    this.scene = null
    this.camera = null
    this.rootNode = null
    
    console.log('🗑️ 2D相机演示系统已销毁')
  }
}
