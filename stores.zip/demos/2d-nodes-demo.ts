/**
 * QAQ游戏引擎 - 2D节点综合演示
 *
 * 作者: QAQ游戏引擎开发团队
 * 创建时间: 2024年
 *
 * 功能说明:
 * - 演示所有2D节点的功能和用法
 * - 提供交互式示例和可视化效果
 * - 展示最佳实践和常见用例
 * - 包含性能测试和优化建议
 */

import Engine from '../core/engine/Engine'
import Scene from '../core/scene/Scene'
import Node2D from '../core/nodes/Node2D'
import Sprite2D, { FlipMode, StretchMode } from '../core/nodes/2d/Sprite2D'
import AnimatedSprite2D, { AnimationMode } from '../core/nodes/2d/AnimatedSprite2D'
import SpriteSheetAnimator2D, { PlayMode, BlendMode } from '../core/nodes/2d/SpriteSheetAnimator2D'
import Label, { TextAlign, VerticalAlign, OverflowMode } from '../core/nodes/2d/Label'
import Button, { ButtonState } from '../core/nodes/2d/Button'
import Panel, { GradientType } from '../core/nodes/2d/Panel'
import TextureRect, { StretchMode as TextureStretchMode, FilterMode } from '../core/nodes/2d/TextureRect'
import * as THREE from 'three'

// ============================================================================
// 演示配置和接口
// ============================================================================

/**
 * 演示配置接口
 */
export interface DemoConfig {
  /** 容器元素ID */
  containerId: string
  /** 画布宽度 */
  width?: number
  /** 画布高度 */
  height?: number
  /** 是否启用调试模式 */
  debug?: boolean
}

/**
 * 演示状态接口
 */
export interface DemoState {
  /** 当前演示索引 */
  currentDemo: number
  /** 演示列表 */
  demos: DemoItem[]
  /** 是否正在运行 */
  isRunning: boolean
  /** 统计信息 */
  stats: {
    fps: number
    nodeCount: number
    renderTime: number
  }
}

/**
 * 演示项目接口
 */
export interface DemoItem {
  /** 演示名称 */
  name: string
  /** 演示描述 */
  description: string
  /** 创建函数 */
  create: (scene: Scene) => Promise<void>
  /** 清理函数 */
  cleanup?: (scene: Scene) => void
}

// ============================================================================
// 2D节点演示类
// ============================================================================

/**
 * 2D节点演示管理器
 */
export class Nodes2DDemo {
  private _engine: Engine | null = null
  private _scene: Scene | null = null
  private _config: DemoConfig
  private _state: DemoState
  private _animationId: number = 0

  /**
   * 构造函数
   * @param config 演示配置
   */
  constructor(config: DemoConfig) {
    this._config = {
      width: 1200,
      height: 800,
      debug: false,
      ...config
    }

    this._state = {
      currentDemo: 0,
      demos: [],
      isRunning: false,
      stats: {
        fps: 0,
        nodeCount: 0,
        renderTime: 0
      }
    }

    this._initializeDemos()
  }

  // ============================================================================
  // 公共方法
  // ============================================================================

  /**
   * 初始化演示
   */
  async initialize(): Promise<void> {
    try {
      console.log('🚀 初始化2D节点演示...')

      // 初始化引擎
      this._engine = Engine.getInstance()
      await this._engine.initialize({
        containerId: this._config.containerId,
        width: this._config.width!,
        height: this._config.height!,
        enablePhysics: false,
        enableAudio: false
      })

      // 创建演示场景
      this._scene = new Scene('2DNodesDemo')
      await this._engine.loadScene(this._scene)

      // 设置相机
      this._setupCamera()

      // 启动第一个演示
      await this.switchDemo(0)

      console.log('✅ 2D节点演示初始化完成')

    } catch (error) {
      console.error('❌ 2D节点演示初始化失败:', error)
      throw error
    }
  }

  /**
   * 启动演示
   */
  start(): void {
    if (this._state.isRunning) return

    this._state.isRunning = true
    this._startRenderLoop()
    console.log('▶️ 2D节点演示开始运行')
  }

  /**
   * 停止演示
   */
  stop(): void {
    if (!this._state.isRunning) return

    this._state.isRunning = false
    if (this._animationId) {
      cancelAnimationFrame(this._animationId)
      this._animationId = 0
    }
    console.log('⏹️ 2D节点演示停止运行')
  }

  /**
   * 切换演示
   * @param index 演示索引
   */
  async switchDemo(index: number): Promise<void> {
    if (index < 0 || index >= this._state.demos.length || !this._scene) {
      console.warn(`⚠️ 无效的演示索引: ${index}`)
      return
    }

    try {
      // 清理当前演示
      if (this._state.demos[this._state.currentDemo]?.cleanup) {
        this._state.demos[this._state.currentDemo].cleanup!(this._scene)
      }

      // 清空场景
      this._scene.clearChildren()

      // 创建新演示
      this._state.currentDemo = index
      const demo = this._state.demos[index]

      console.log(`🔄 切换到演示: ${demo.name}`)
      await demo.create(this._scene)

      // 更新统计信息
      this._updateStats()

    } catch (error) {
      console.error(`❌ 切换演示失败: ${error}`)
    }
  }

  /**
   * 获取演示列表
   */
  getDemos(): DemoItem[] {
    return [...this._state.demos]
  }

  /**
   * 获取当前演示索引
   */
  getCurrentDemoIndex(): number {
    return this._state.currentDemo
  }

  /**
   * 获取统计信息
   */
  getStats(): typeof this._state.stats {
    return { ...this._state.stats }
  }

  /**
   * 销毁演示
   */
  destroy(): void {
    this.stop()

    if (this._engine) {
      this._engine.destroy()
      this._engine = null
    }

    this._scene = null
    console.log('🗑️ 2D节点演示已销毁')
  }

  // ============================================================================
  // 私有方法
  // ============================================================================

  /**
   * 初始化演示列表
   */
  private _initializeDemos(): void {
    this._state.demos = [
      {
        name: 'Sprite2D 基础演示',
        description: '展示Sprite2D的基本功能：纹理加载、缩放、旋转、翻转',
        create: this._createSprite2DDemo.bind(this)
      },
      {
        name: 'AnimatedSprite2D 动画演示',
        description: '展示AnimatedSprite2D的动画功能：帧动画、循环播放、状态切换',
        create: this._createAnimatedSprite2DDemo.bind(this)
      },
      {
        name: 'SpriteSheetAnimator2D 精灵表动画',
        description: '展示SpriteSheetAnimator2D的精灵表动画功能：自动解析、多动画剪辑、混合过渡',
        create: this._createSpriteSheetAnimatorDemo.bind(this)
      },
      {
        name: '高级动画系统演示',
        description: '展示高级动画功能：动画混合、事件触发、性能优化',
        create: this._createAdvancedAnimationDemo.bind(this)
      },
      {
        name: 'Label 文本演示',
        description: '展示Label的文本渲染功能：字体、颜色、对齐、样式',
        create: this._createLabelDemo.bind(this)
      },
      {
        name: 'Button 按钮演示',
        description: '展示Button的交互功能：点击、悬停、状态、样式',
        create: this._createButtonDemo.bind(this)
      },
      {
        name: 'Panel 面板演示',
        description: '展示Panel的容器功能：背景、边框、渐变、阴影',
        create: this._createPanelDemo.bind(this)
      },
      {
        name: 'TextureRect 纹理演示',
        description: '展示TextureRect的纹理显示功能：拉伸模式、过滤、九宫格',
        create: this._createTextureRectDemo.bind(this)
      },
      {
        name: '综合UI演示',
        description: '展示多个2D节点组合使用的复杂UI界面',
        create: this._createComplexUIDemo.bind(this)
      },
      {
        name: '性能测试',
        description: '测试大量2D节点的渲染性能和内存使用',
        create: this._createPerformanceDemo.bind(this)
      }
    ]
  }

  /**
   * 设置相机
   */
  private _setupCamera(): void {
    if (!this._engine) return

    // 设置2D正交相机
    const camera = this._engine.getCamera()
    if (camera) {
      camera.position.set(0, 0, 1000)
      camera.lookAt(0, 0, 0)
    }
  }

  /**
   * 启动渲染循环
   */
  private _startRenderLoop(): void {
    const render = (timestamp: number) => {
      if (!this._state.isRunning) return

      const startTime = performance.now()

      // 更新引擎
      if (this._engine) {
        this._engine.update(timestamp / 1000)
      }

      // 更新统计信息
      const renderTime = performance.now() - startTime
      this._state.stats.renderTime = renderTime
      this._state.stats.fps = Math.round(1000 / (timestamp - (this._lastTimestamp || timestamp)))
      this._lastTimestamp = timestamp

      this._animationId = requestAnimationFrame(render)
    }

    this._animationId = requestAnimationFrame(render)
  }
  private _lastTimestamp: number = 0

  /**
   * 更新统计信息
   */
  private _updateStats(): void {
    if (this._scene) {
      this._state.stats.nodeCount = this._scene.getChildCount(true)
    }
  }

  // ============================================================================
  // 演示创建方法
  // ============================================================================

  /**
   * 创建Sprite2D演示
   */
  private async _createSprite2DDemo(scene: Scene): Promise<void> {
    // 创建基础精灵
    const sprite1 = new Sprite2D('BasicSprite', {
      centered: true,
      stretchMode: StretchMode.KEEP
    })
    sprite1.position = { x: -200, y: 100, z: 0 }

    // 创建一个简单的纹理（彩色方块）
    const canvas = document.createElement('canvas')
    canvas.width = 100
    canvas.height = 100
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#ff6b35'
    ctx.fillRect(0, 0, 100, 100)
    ctx.fillStyle = '#f7931e'
    ctx.fillRect(20, 20, 60, 60)

    const texture = new THREE.CanvasTexture(canvas)
    sprite1.texture = texture

    scene.addChild(sprite1)

    // 创建翻转精灵
    const sprite2 = new Sprite2D('FlippedSprite', {
      centered: true,
      flipMode: FlipMode.HORIZONTAL
    })
    sprite2.position = { x: 0, y: 100, z: 0 }
    sprite2.texture = texture
    scene.addChild(sprite2)

    // 创建旋转精灵
    const sprite3 = new Sprite2D('RotatedSprite', {
      centered: true
    })
    sprite3.position = { x: 200, y: 100, z: 0 }
    sprite3.rotation = { x: 0, y: 0, z: Math.PI / 4 }
    sprite3.texture = texture
    scene.addChild(sprite3)

    // 添加标题
    const title = new Label('SpriteTitle', {
      text: 'Sprite2D 演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -50, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建AnimatedSprite2D演示
   */
  private async _createAnimatedSprite2DDemo(scene: Scene): Promise<void> {
    const animSprite = new AnimatedSprite2D('AnimatedCharacter')
    animSprite.position = { x: 0, y: 0, z: 0 }

    // 创建简单的帧动画（颜色变化）
    const frames = []
    const colors = ['#ff6b35', '#f7931e', '#ffc425', '#f0f0f0']

    for (let i = 0; i < colors.length; i++) {
      const canvas = document.createElement('canvas')
      canvas.width = 80
      canvas.height = 80
      const ctx = canvas.getContext('2d')!
      ctx.fillStyle = colors[i]
      ctx.fillRect(0, 0, 80, 80)
      ctx.fillStyle = '#333333'
      ctx.fillRect(20, 20, 40, 40)

      const texture = new THREE.CanvasTexture(canvas)
      frames.push({
        texture,
        duration: 0.25,
        name: `frame_${i}`
      })
    }

    // 添加动画序列
    animSprite.addAnimation({
      name: 'colorCycle',
      frames,
      mode: AnimationMode.LOOP,
      speed: 1.0,
      autoPlay: true
    })

    // 播放动画
    animSprite.play('colorCycle')
    scene.addChild(animSprite)

    // 添加标题
    const title = new Label('AnimTitle', {
      text: 'AnimatedSprite2D 演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -100, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建Label演示
   */
  private async _createLabelDemo(scene: Scene): Promise<void> {
    // 不同样式的标签
    const labels = [
      {
        text: '标准文本',
        style: { fontSize: 18, color: '#333333' },
        position: { x: -200, y: 100, z: 0 }
      },
      {
        text: '大号粗体',
        style: { fontSize: 24, color: '#ff6b35', fontWeight: 'bold' },
        position: { x: 0, y: 100, z: 0 }
      },
      {
        text: '带阴影文本',
        style: {
          fontSize: 20,
          color: '#f7931e',
          shadowColor: '#333333',
          shadowOffset: { x: 2, y: 2 },
          shadowBlur: 4
        },
        position: { x: 200, y: 100, z: 0 }
      },
      {
        text: '居中对齐的长文本示例',
        style: { fontSize: 16, color: '#666666' },
        align: TextAlign.CENTER,
        position: { x: 0, y: 0, z: 0 }
      }
    ]

    labels.forEach((config, index) => {
      const label = new Label(`Label${index}`, {
        text: config.text,
        style: config.style,
        align: config.align || TextAlign.LEFT
      })
      label.position = config.position
      label.size = { x: 300, y: 40 }
      scene.addChild(label)
    })

    // 添加标题
    const title = new Label('LabelTitle', {
      text: 'Label 文本演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -100, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建Button演示
   */
  private async _createButtonDemo(scene: Scene): Promise<void> {
    // 标准按钮
    const button1 = new Button('StandardButton', {
      text: '标准按钮'
    })
    button1.position = { x: -150, y: 50, z: 0 }
    button1.size = { x: 120, y: 40 }
    button1.setOnPressed(() => {
      console.log('标准按钮被点击')
    })
    scene.addChild(button1)

    // 切换按钮
    const button2 = new Button('ToggleButton', {
      text: '切换按钮',
      toggleMode: true
    })
    button2.position = { x: 0, y: 50, z: 0 }
    button2.size = { x: 120, y: 40 }
    button2.setOnToggled((pressed) => {
      console.log(`切换按钮状态: ${pressed ? '按下' : '释放'}`)
    })
    scene.addChild(button2)

    // 禁用按钮
    const button3 = new Button('DisabledButton', {
      text: '禁用按钮',
      disabled: true
    })
    button3.position = { x: 150, y: 50, z: 0 }
    button3.size = { x: 120, y: 40 }
    scene.addChild(button3)

    // 添加标题
    const title = new Label('ButtonTitle', {
      text: 'Button 按钮演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -50, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建Panel演示
   */
  private async _createPanelDemo(scene: Scene): Promise<void> {
    // 基础面板
    const panel1 = new Panel('BasicPanel', {
      style: {
        backgroundColor: '#f0f0f0',
        borderColor: '#cccccc',
        borderWidth: 2,
        borderRadius: 8
      }
    })
    panel1.position = { x: -200, y: 0, z: 0 }
    panel1.size = { x: 150, y: 100 }
    scene.addChild(panel1)

    // 渐变面板
    const panel2 = new Panel('GradientPanel')
    panel2.setGradient({
      type: GradientType.LINEAR,
      startColor: '#ff6b35',
      endColor: '#f7931e',
      angle: 45
    })
    panel2.position = { x: 0, y: 0, z: 0 }
    panel2.size = { x: 150, y: 100 }
    scene.addChild(panel2)

    // 阴影面板
    const panel3 = new Panel('ShadowPanel', {
      style: {
        backgroundColor: '#ffffff',
        borderRadius: 12
      }
    })
    panel3.setShadow({
      color: 'rgba(0, 0, 0, 0.3)',
      offset: { x: 4, y: 4 },
      blur: 8
    })
    panel3.position = { x: 200, y: 0, z: 0 }
    panel3.size = { x: 150, y: 100 }
    scene.addChild(panel3)

    // 添加标题
    const title = new Label('PanelTitle', {
      text: 'Panel 面板演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -100, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建TextureRect演示
   */
  private async _createTextureRectDemo(scene: Scene): Promise<void> {
    // 创建测试纹理
    const canvas = document.createElement('canvas')
    canvas.width = 64
    canvas.height = 64
    const ctx = canvas.getContext('2d')!

    // 绘制棋盘格
    for (let x = 0; x < 8; x++) {
      for (let y = 0; y < 8; y++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? '#ff6b35' : '#f7931e'
        ctx.fillRect(x * 8, y * 8, 8, 8)
      }
    }

    const texture = new THREE.CanvasTexture(canvas)

    // 拉伸模式演示
    const rect1 = new TextureRect('StretchRect', {
      texture,
      stretchMode: TextureStretchMode.STRETCH
    })
    rect1.position = { x: -200, y: 0, z: 0 }
    rect1.size = { x: 120, y: 80 }
    scene.addChild(rect1)

    // 平铺模式演示
    const rect2 = new TextureRect('TileRect', {
      texture,
      stretchMode: TextureStretchMode.TILE
    })
    rect2.position = { x: 0, y: 0, z: 0 }
    rect2.size = { x: 120, y: 80 }
    scene.addChild(rect2)

    // 保持比例演示
    const rect3 = new TextureRect('KeepRect', {
      texture,
      stretchMode: TextureStretchMode.KEEP_ASPECT_FITTED
    })
    rect3.position = { x: 200, y: 0, z: 0 }
    rect3.size = { x: 120, y: 80 }
    scene.addChild(rect3)

    // 添加标题
    const title = new Label('TextureTitle', {
      text: 'TextureRect 纹理演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -100, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建综合UI演示
   */
  private async _createComplexUIDemo(scene: Scene): Promise<void> {
    // 主面板
    const mainPanel = new Panel('MainPanel', {
      style: {
        backgroundColor: '#ffffff',
        borderColor: '#dddddd',
        borderWidth: 1,
        borderRadius: 8
      }
    })
    mainPanel.setShadow({
      color: 'rgba(0, 0, 0, 0.1)',
      offset: { x: 0, y: 2 },
      blur: 8
    })
    mainPanel.position = { x: 0, y: 0, z: 0 }
    mainPanel.size = { x: 400, y: 300 }
    scene.addChild(mainPanel)

    // 标题栏
    const titleBar = new Panel('TitleBar')
    titleBar.setGradient({
      type: GradientType.LINEAR,
      startColor: '#4a90e2',
      endColor: '#357abd',
      angle: 90
    })
    titleBar.position = { x: -199, y: -149, z: 1 }
    titleBar.size = { x: 398, y: 40 }
    scene.addChild(titleBar)

    // 标题文本
    const titleText = new Label('TitleText', {
      text: '综合UI演示',
      style: { fontSize: 18, color: '#ffffff', fontWeight: 'bold' },
      align: TextAlign.CENTER,
      verticalAlign: VerticalAlign.CENTER
    })
    titleText.position = { x: -199, y: -149, z: 2 }
    titleText.size = { x: 398, y: 40 }
    scene.addChild(titleText)

    // 内容区域按钮
    const buttons = ['确定', '取消', '应用']
    buttons.forEach((text, index) => {
      const button = new Button(`Button${index}`, { text })
      button.position = { x: -100 + index * 100, y: 50, z: 1 }
      button.size = { x: 80, y: 35 }
      button.setOnPressed(() => {
        console.log(`${text} 按钮被点击`)
      })
      scene.addChild(button)
    })

    // 信息标签
    const infoLabel = new Label('InfoLabel', {
      text: '这是一个复杂的UI界面示例，\n展示了多个2D节点的组合使用。',
      style: { fontSize: 14, color: '#666666' },
      align: TextAlign.CENTER,
      overflowMode: OverflowMode.WORD_WRAP
    })
    infoLabel.position = { x: -150, y: -20, z: 1 }
    infoLabel.size = { x: 300, y: 60 }
    scene.addChild(infoLabel)
  }

  /**
   * 创建性能测试演示
   */
  private async _createPerformanceDemo(scene: Scene): Promise<void> {
    const nodeCount = 100
    const colors = ['#ff6b35', '#f7931e', '#ffc425', '#4a90e2', '#357abd']

    // 创建大量精灵进行性能测试
    for (let i = 0; i < nodeCount; i++) {
      const sprite = new Sprite2D(`PerfSprite${i}`)

      // 创建彩色纹理
      const canvas = document.createElement('canvas')
      canvas.width = 32
      canvas.height = 32
      const ctx = canvas.getContext('2d')!
      ctx.fillStyle = colors[i % colors.length]
      ctx.fillRect(0, 0, 32, 32)

      const texture = new THREE.CanvasTexture(canvas)
      sprite.texture = texture

      // 随机位置
      sprite.position = {
        x: (Math.random() - 0.5) * 800,
        y: (Math.random() - 0.5) * 600,
        z: 0
      }

      // 随机缩放
      const scale = 0.5 + Math.random() * 0.5
      sprite.scale = { x: scale, y: scale, z: 1 }

      scene.addChild(sprite)
    }

    // 性能信息标签
    const perfLabel = new Label('PerfLabel', {
      text: `性能测试: ${nodeCount} 个精灵节点`,
      style: { fontSize: 20, color: '#333333' },
      align: TextAlign.CENTER
    })
    perfLabel.position = { x: 0, y: -250, z: 0 }
    perfLabel.size = { x: 400, y: 40 }
    scene.addChild(perfLabel)
  }

  /**
   * 创建SpriteSheetAnimator2D演示
   */
  private async _createSpriteSheetAnimatorDemo(scene: Scene): Promise<void> {
    // 创建精灵表动画器
    const animator = new SpriteSheetAnimator2D('CharacterAnimator')
    animator.position = { x: 0, y: 0, z: 0 }

    // 创建测试精灵表
    const spriteSheetCanvas = document.createElement('canvas')
    spriteSheetCanvas.width = 256
    spriteSheetCanvas.height = 128
    const ctx = spriteSheetCanvas.getContext('2d')!

    // 绘制测试精灵表（8x4的帧）
    const colors = [
      '#ff6b35', '#f7931e', '#ffc425', '#f0f0f0',
      '#4a90e2', '#357abd', '#28a745', '#dc3545'
    ]

    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 8; col++) {
        const x = col * 32
        const y = row * 32
        const colorIndex = (row * 8 + col) % colors.length

        ctx.fillStyle = colors[colorIndex]
        ctx.fillRect(x, y, 32, 32)

        // 添加一些细节
        ctx.fillStyle = '#333333'
        ctx.fillRect(x + 8, y + 8, 16, 16)

        // 帧编号
        ctx.fillStyle = '#ffffff'
        ctx.font = '10px Arial'
        ctx.fillText((row * 8 + col).toString(), x + 2, y + 12)
      }
    }

    // 加载精灵表
    const spriteSheetTexture = new THREE.CanvasTexture(spriteSheetCanvas)

    const success = await animator.loadSpriteSheet({
      texturePath: '', // 我们直接使用纹理
      frameWidth: 32,
      frameHeight: 32,
      framesPerRow: 8,
      totalRows: 4
    })

    if (success) {
      // 手动设置纹理（因为我们没有通过路径加载）
      animator['_spriteSheetTexture'] = spriteSheetTexture
      await animator['_parseSpriteSheet']()

      // 添加动画剪辑
      animator.addAnimationClips([
        {
          name: 'idle',
          startFrame: 0,
          frameCount: 4,
          frameDurations: [0.2, 0.2, 0.2, 0.2],
          playMode: PlayMode.LOOP,
          speed: 1.0,
          loop: true
        },
        {
          name: 'walk',
          startFrame: 8,
          frameCount: 6,
          frameDurations: [0.1, 0.1, 0.1, 0.1, 0.1, 0.1],
          playMode: PlayMode.LOOP,
          speed: 1.5,
          loop: true
        },
        {
          name: 'jump',
          startFrame: 16,
          frameCount: 4,
          frameDurations: [0.15, 0.1, 0.1, 0.15],
          playMode: PlayMode.ONCE,
          speed: 1.0,
          loop: false
        }
      ])

      // 播放默认动画
      animator.play('idle')
    }

    scene.addChild(animator)

    // 添加控制按钮
    const buttons = [
      { text: 'Idle', animation: 'idle', x: -150 },
      { text: 'Walk', animation: 'walk', x: 0 },
      { text: 'Jump', animation: 'jump', x: 150 }
    ]

    buttons.forEach(config => {
      const button = new Button(`${config.animation}Button`, {
        text: config.text
      })
      button.position = { x: config.x, y: 100, z: 0 }
      button.size = { x: 80, y: 35 }
      button.setOnPressed(() => {
        animator.play(config.animation, BlendMode.FADE, 0.2)
        console.log(`切换到动画: ${config.animation}`)
      })
      scene.addChild(button)
    })

    // 添加标题
    const title = new Label('SpriteSheetTitle', {
      text: 'SpriteSheetAnimator2D 精灵表动画演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -150, z: 0 }
    title.size = { x: 500, y: 40 }
    scene.addChild(title)
  }

  /**
   * 创建高级动画系统演示
   */
  private async _createAdvancedAnimationDemo(scene: Scene): Promise<void> {
    // 创建多个动画角色
    const characters = []

    for (let i = 0; i < 3; i++) {
      const animator = new SpriteSheetAnimator2D(`Character${i}`)
      animator.position = { x: (i - 1) * 200, y: 0, z: 0 }

      // 创建不同颜色的精灵表
      const canvas = document.createElement('canvas')
      canvas.width = 128
      canvas.height = 64
      const ctx = canvas.getContext('2d')!

      const baseColors = ['#ff6b35', '#4a90e2', '#28a745']
      const baseColor = baseColors[i]

      // 绘制简单的动画帧
      for (let frame = 0; frame < 8; frame++) {
        const x = (frame % 4) * 32
        const y = Math.floor(frame / 4) * 32

        // 基础形状
        ctx.fillStyle = baseColor
        ctx.fillRect(x, y, 32, 32)

        // 动画变化
        const offset = Math.sin(frame * 0.5) * 4
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(x + 8 + offset, y + 8, 16, 16)
      }

      const texture = new THREE.CanvasTexture(canvas)

      // 设置精灵表配置
      await animator.loadSpriteSheet({
        texturePath: '',
        frameWidth: 32,
        frameHeight: 32,
        framesPerRow: 4,
        totalRows: 2
      })

      // 手动设置纹理
      animator['_spriteSheetTexture'] = texture
      await animator['_parseSpriteSheet']()

      // 添加动画剪辑
      animator.addAnimationClips([
        {
          name: 'bounce',
          startFrame: 0,
          frameCount: 4,
          frameDurations: [0.15, 0.1, 0.1, 0.15],
          playMode: PlayMode.PING_PONG,
          speed: 1.0 + i * 0.3,
          loop: true
        },
        {
          name: 'spin',
          startFrame: 4,
          frameCount: 4,
          frameDurations: [0.1, 0.1, 0.1, 0.1],
          playMode: PlayMode.LOOP,
          speed: 2.0 - i * 0.2,
          loop: true
        }
      ])

      // 设置动画事件
      animator.setOnAnimationEvent((event) => {
        console.log(`角色${i}动画事件: ${event.name}`)
      })

      // 播放不同的动画
      animator.play(i % 2 === 0 ? 'bounce' : 'spin')

      characters.push(animator)
      scene.addChild(animator)
    }

    // 添加同步控制
    const syncButton = new Button('SyncButton', {
      text: '同步动画'
    })
    syncButton.position = { x: 0, y: 150, z: 0 }
    syncButton.size = { x: 120, y: 40 }
    syncButton.setOnPressed(() => {
      characters.forEach((char, index) => {
        char.play('bounce', BlendMode.CROSS_FADE, 0.5)
      })
    })
    scene.addChild(syncButton)

    // 添加标题
    const title = new Label('AdvancedTitle', {
      text: '高级动画系统演示',
      style: { fontSize: 24, color: '#333333' },
      align: TextAlign.CENTER
    })
    title.position = { x: 0, y: -150, z: 0 }
    title.size = { x: 400, y: 40 }
    scene.addChild(title)

    // 添加说明
    const description = new Label('AdvancedDesc', {
      text: '展示多角色动画同步、混合过渡和事件系统',
      style: { fontSize: 14, color: '#666666' },
      align: TextAlign.CENTER
    })
    description.position = { x: 0, y: -120, z: 0 }
    description.size = { x: 500, y: 30 }
    scene.addChild(description)
  }
}

// ============================================================================
// 导出
// ============================================================================

export default Nodes2DDemo
