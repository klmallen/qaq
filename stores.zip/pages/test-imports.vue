<template>
  <div class="p-8">
    <h1 class="text-3xl font-bold mb-6">TypeScript 导入测试</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <!-- 核心模块测试 -->
      <div class="bg-blue-50 p-6 rounded-lg">
        <h2 class="text-xl font-semibold mb-4">🔧 核心模块</h2>
        <div class="space-y-2">
          <div class="flex items-center">
            <span :class="tests.engine ? 'text-green-600' : 'text-red-600'">
              {{ tests.engine ? '✅' : '❌' }}
            </span>
            <span class="ml-2">Engine 模块</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.sceneTree ? 'text-green-600' : 'text-red-600'">
              {{ tests.sceneTree ? '✅' : '❌' }}
            </span>
            <span class="ml-2">SceneTree 模块</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.scene ? 'text-green-600' : 'text-red-600'">
              {{ tests.scene ? '✅' : '❌' }}
            </span>
            <span class="ml-2">Scene 模块</span>
          </div>
        </div>
      </div>

      <!-- 资源加载器测试 -->
      <div class="bg-green-50 p-6 rounded-lg">
        <h2 class="text-xl font-semibold mb-4">📦 资源加载器</h2>
        <div class="space-y-2">
          <div class="flex items-center">
            <span :class="tests.resourceLoader ? 'text-green-600' : 'text-red-600'">
              {{ tests.resourceLoader ? '✅' : '❌' }}
            </span>
            <span class="ml-2">ResourceLoader 类</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.loadProgress ? 'text-green-600' : 'text-red-600'">
              {{ tests.loadProgress ? '✅' : '❌' }}
            </span>
            <span class="ml-2">LoadProgress 接口</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.loadResult ? 'text-green-600' : 'text-red-600'">
              {{ tests.loadResult ? '✅' : '❌' }}
            </span>
            <span class="ml-2">LoadResult 接口</span>
          </div>
        </div>
      </div>

      <!-- 节点系统测试 -->
      <div class="bg-purple-50 p-6 rounded-lg">
        <h2 class="text-xl font-semibold mb-4">🎯 节点系统</h2>
        <div class="space-y-2">
          <div class="flex items-center">
            <span :class="tests.node ? 'text-green-600' : 'text-red-600'">
              {{ tests.node ? '✅' : '❌' }}
            </span>
            <span class="ml-2">Node 基类</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.meshInstance3D ? 'text-green-600' : 'text-red-600'">
              {{ tests.meshInstance3D ? '✅' : '❌' }}
            </span>
            <span class="ml-2">MeshInstance3D 节点</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.camera3D ? 'text-green-600' : 'text-red-600'">
              {{ tests.camera3D ? '✅' : '❌' }}
            </span>
            <span class="ml-2">Camera3D 节点</span>
          </div>
        </div>
      </div>

      <!-- 类型系统测试 -->
      <div class="bg-yellow-50 p-6 rounded-lg">
        <h2 class="text-xl font-semibold mb-4">📝 类型系统</h2>
        <div class="space-y-2">
          <div class="flex items-center">
            <span :class="tests.sceneTypes ? 'text-green-600' : 'text-red-600'">
              {{ tests.sceneTypes ? '✅' : '❌' }}
            </span>
            <span class="ml-2">场景类型定义</span>
          </div>
          <div class="flex items-center">
            <span :class="tests.coreTypes ? 'text-green-600' : 'text-red-600'">
              {{ tests.coreTypes ? '✅' : '❌' }}
            </span>
            <span class="ml-2">核心类型定义</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 总体状态 -->
    <div class="mt-8 p-6 rounded-lg" :class="allTestsPassed ? 'bg-green-100' : 'bg-red-100'">
      <h2 class="text-2xl font-bold mb-2">
        {{ allTestsPassed ? '🎉 所有测试通过！' : '⚠️ 存在导入问题' }}
      </h2>
      <p class="text-lg">
        {{ allTestsPassed 
          ? 'TypeScript 模块导入系统工作正常，编辑器可以安全启动。' 
          : '发现模块导入错误，请检查控制台获取详细信息。' 
        }}
      </p>
    </div>

    <!-- 错误信息 -->
    <div v-if="errors.length > 0" class="mt-6 p-4 bg-red-50 rounded-lg">
      <h3 class="text-lg font-semibold text-red-800 mb-2">错误详情:</h3>
      <ul class="list-disc list-inside space-y-1">
        <li v-for="error in errors" :key="error" class="text-red-700">{{ error }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const tests = ref({
  engine: false,
  sceneTree: false,
  scene: false,
  resourceLoader: false,
  loadProgress: false,
  loadResult: false,
  node: false,
  meshInstance3D: false,
  camera3D: false,
  sceneTypes: false,
  coreTypes: false
})

const errors = ref([])

const allTestsPassed = computed(() => {
  return Object.values(tests.value).every(test => test === true)
})

onMounted(async () => {
  console.log('🧪 开始 TypeScript 导入测试...')

  // 测试核心模块
  await testCoreModules()
  
  // 测试资源加载器
  await testResourceLoader()
  
  // 测试节点系统
  await testNodeSystem()
  
  // 测试类型系统
  await testTypeSystem()

  console.log('✅ TypeScript 导入测试完成')
})

async function testCoreModules() {
  try {
    const { default: Engine } = await import('~/core/engine/Engine')
    tests.value.engine = true
    console.log('✅ Engine 模块导入成功')
  } catch (error) {
    errors.value.push(`Engine 模块导入失败: ${error.message}`)
    console.error('❌ Engine 模块导入失败:', error)
  }

  try {
    const { default: SceneTree } = await import('~/core/scene/SceneTree')
    tests.value.sceneTree = true
    console.log('✅ SceneTree 模块导入成功')
  } catch (error) {
    errors.value.push(`SceneTree 模块导入失败: ${error.message}`)
    console.error('❌ SceneTree 模块导入失败:', error)
  }

  try {
    const { default: Scene } = await import('~/core/scene/Scene')
    tests.value.scene = true
    console.log('✅ Scene 模块导入成功')
  } catch (error) {
    errors.value.push(`Scene 模块导入失败: ${error.message}`)
    console.error('❌ Scene 模块导入失败:', error)
  }
}

async function testResourceLoader() {
  try {
    const { default: ResourceLoader } = await import('~/core/resources/ResourceLoader')
    tests.value.resourceLoader = true
    console.log('✅ ResourceLoader 类导入成功')
  } catch (error) {
    errors.value.push(`ResourceLoader 导入失败: ${error.message}`)
    console.error('❌ ResourceLoader 导入失败:', error)
  }

  try {
    // 测试类型导入
    const types = await import('~/core/resources/ResourceLoader')
    tests.value.loadProgress = true
    tests.value.loadResult = true
    console.log('✅ ResourceLoader 类型导入成功')
  } catch (error) {
    errors.value.push(`ResourceLoader 类型导入失败: ${error.message}`)
    console.error('❌ ResourceLoader 类型导入失败:', error)
  }
}

async function testNodeSystem() {
  try {
    const { default: Node } = await import('~/core/nodes/Node')
    tests.value.node = true
    console.log('✅ Node 基类导入成功')
  } catch (error) {
    errors.value.push(`Node 基类导入失败: ${error.message}`)
    console.error('❌ Node 基类导入失败:', error)
  }

  try {
    const { default: MeshInstance3D } = await import('~/core/nodes/MeshInstance3D')
    tests.value.meshInstance3D = true
    console.log('✅ MeshInstance3D 节点导入成功')
  } catch (error) {
    errors.value.push(`MeshInstance3D 导入失败: ${error.message}`)
    console.error('❌ MeshInstance3D 导入失败:', error)
  }

  try {
    const { default: Camera3D } = await import('~/core/nodes/3d/Camera3D')
    tests.value.camera3D = true
    console.log('✅ Camera3D 节点导入成功')
  } catch (error) {
    errors.value.push(`Camera3D 导入失败: ${error.message}`)
    console.error('❌ Camera3D 导入失败:', error)
  }
}

async function testTypeSystem() {
  try {
    const sceneTypes = await import('~/core/scene/types')
    tests.value.sceneTypes = true
    console.log('✅ 场景类型定义导入成功')
  } catch (error) {
    errors.value.push(`场景类型定义导入失败: ${error.message}`)
    console.error('❌ 场景类型定义导入失败:', error)
  }

  try {
    const coreTypes = await import('~/types/core')
    tests.value.coreTypes = true
    console.log('✅ 核心类型定义导入成功')
  } catch (error) {
    errors.value.push(`核心类型定义导入失败: ${error.message}`)
    console.error('❌ 核心类型定义导入失败:', error)
  }
}
</script>
