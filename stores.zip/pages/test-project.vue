<template>
  <div class="test-project-page">
    <div class="test-container">
      <h1>QAQ Game Engine - Project Management Test</h1>
      
      <div class="test-section">
        <h2>项目管理测试</h2>
        
        <div class="test-buttons">
          <UButton
            icon="i-heroicons-folder-plus"
            size="lg"
            @click="testCreateProject"
          >
            测试创建项目
          </UButton>
          
          <UButton
            icon="i-heroicons-folder-open"
            size="lg"
            variant="outline"
            @click="testOpenProject"
          >
            测试打开项目
          </UButton>
          
          <UButton
            icon="i-heroicons-document-plus"
            size="lg"
            variant="outline"
            @click="testCreateScene"
          >
            测试创建场景
          </UButton>
          
          <UButton
            icon="i-heroicons-document-arrow-down"
            size="lg"
            variant="outline"
            @click="testSaveScene"
          >
            测试保存场景
          </UButton>
        </div>
      </div>
      
      <div class="test-section">
        <h2>属性系统测试</h2>
        
        <div class="property-test">
          <div v-if="testNode" class="property-renderer-test">
            <h3>测试节点属性渲染</h3>
            <PropertyRenderer 
              :node="testNode"
              @property-changed="onPropertyChanged"
            />
          </div>
          
          <div class="test-buttons">
            <UButton
              @click="createTestNode"
            >
              创建测试节点
            </UButton>
            
            <UButton
              variant="outline"
              @click="clearTestNode"
            >
              清除测试节点
            </UButton>
          </div>
        </div>
      </div>
      
      <div class="test-section">
        <h2>当前状态</h2>
        
        <div class="status-display">
          <div class="status-item">
            <strong>项目状态:</strong>
            <span v-if="editorStore.state.currentProject">
              {{ editorStore.state.projectName }} ({{ editorStore.state.projectPath }})
            </span>
            <span v-else>无项目</span>
          </div>
          
          <div class="status-item">
            <strong>选中节点:</strong>
            <span v-if="editorStore.state.selectedNode">
              {{ editorStore.state.selectedNode.name }} ({{ editorStore.state.selectedNode.className }})
            </span>
            <span v-else>无选中节点</span>
          </div>
          
          <div class="status-item">
            <strong>场景树:</strong>
            <span v-if="editorStore.state.sceneTree">
              {{ editorStore.state.sceneTree.name }}
            </span>
            <span v-else>无场景</span>
          </div>
        </div>
      </div>
      
      <div class="test-section">
        <h2>输出日志</h2>
        
        <div class="log-display">
          <div
            v-for="log in editorStore.state.outputLogs.slice(-10)"
            :key="log.timestamp"
            :class="['log-item', `log-${log.level}`]"
          >
            <span class="log-time">{{ formatTime(log.timestamp) }}</span>
            <span class="log-message">{{ log.message }}</span>
          </div>
        </div>
        
        <UButton
          variant="outline"
          size="sm"
          @click="clearLogs"
        >
          清除日志
        </UButton>
      </div>
    </div>
    
    <!-- 项目管理对话框 -->
    <ProjectDialog
      v-model="showProjectDialog"
      @project-created="onProjectCreated"
      @project-opened="onProjectOpened"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useEditorStore } from '~/stores/editor'
import { Node3D, MeshInstance3D } from '~/core'
import PropertyRenderer from '~/components/editor/inspector/PropertyRenderer.vue'
import ProjectDialog from '~/components/editor/dialogs/ProjectDialog.vue'

// ============================================================================
// 状态管理
// ============================================================================

const editorStore = useEditorStore()

// ============================================================================
// 响应式数据
// ============================================================================

const showProjectDialog = ref(false)
const testNode = ref<Node3D | null>(null)

// ============================================================================
// 方法
// ============================================================================

async function testCreateProject() {
  try {
    showProjectDialog.value = true
    editorStore.addOutputLog('info', '打开项目创建对话框')
  } catch (error) {
    editorStore.addOutputLog('error', `创建项目失败: ${error}`)
  }
}

async function testOpenProject() {
  try {
    showProjectDialog.value = true
    editorStore.addOutputLog('info', '打开项目选择对话框')
  } catch (error) {
    editorStore.addOutputLog('error', `打开项目失败: ${error}`)
  }
}

async function testCreateScene() {
  try {
    await editorStore.createNewScene()
    editorStore.addOutputLog('success', '场景创建成功')
  } catch (error) {
    editorStore.addOutputLog('error', `创建场景失败: ${error}`)
  }
}

async function testSaveScene() {
  try {
    if (editorStore.projectManager) {
      await editorStore.saveCurrentScene()
      editorStore.addOutputLog('success', '场景保存成功')
    } else {
      editorStore.addOutputLog('warning', '没有打开的项目，无法保存场景')
    }
  } catch (error) {
    editorStore.addOutputLog('error', `保存场景失败: ${error}`)
  }
}

function createTestNode() {
  const node = new MeshInstance3D()
  node.name = 'TestMeshInstance3D'
  node.position.set(1, 2, 3)
  node.rotation.set(0.1, 0.2, 0.3)
  node.scale.set(2, 2, 2)
  
  testNode.value = node
  editorStore.setSelectedNode(node)
  editorStore.addOutputLog('info', '创建测试节点: TestMeshInstance3D')
}

function clearTestNode() {
  testNode.value = null
  editorStore.setSelectedNode(null)
  editorStore.addOutputLog('info', '清除测试节点')
}

function onPropertyChanged(propertyName: string, newValue: any) {
  editorStore.addOutputLog('info', `属性变更: ${propertyName} = ${JSON.stringify(newValue)}`)
}

function onProjectCreated(project: any) {
  editorStore.addOutputLog('success', `项目创建成功: ${project.name}`)
}

function onProjectOpened(project: any) {
  editorStore.addOutputLog('success', `项目打开成功: ${project.name}`)
}

function clearLogs() {
  editorStore.clearOutputLogs()
}

function formatTime(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString()
}
</script>

<style scoped>
.test-project-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  color: #ffffff;
  padding: 20px;
}

.test-container {
  max-width: 1200px;
  margin: 0 auto;
}

.test-container h1 {
  text-align: center;
  margin-bottom: 40px;
  color: #4ade80;
}

.test-section {
  background: #2a2a2a;
  border-radius: 8px;
  padding: 24px;
  margin-bottom: 24px;
  border: 1px solid #333;
}

.test-section h2 {
  margin-bottom: 16px;
  color: #4ade80;
  border-bottom: 1px solid #333;
  padding-bottom: 8px;
}

.test-buttons {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.property-test {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.property-renderer-test {
  background: #1a1a1a;
  border-radius: 6px;
  padding: 16px;
  border: 1px solid #333;
}

.status-display {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.status-item {
  display: flex;
  gap: 8px;
}

.status-item strong {
  min-width: 120px;
  color: #4ade80;
}

.log-display {
  background: #1a1a1a;
  border-radius: 6px;
  padding: 16px;
  max-height: 300px;
  overflow-y: auto;
  margin-bottom: 12px;
  border: 1px solid #333;
}

.log-item {
  display: flex;
  gap: 12px;
  padding: 4px 0;
  border-bottom: 1px solid #333;
}

.log-item:last-child {
  border-bottom: none;
}

.log-time {
  color: #888;
  font-size: 12px;
  min-width: 80px;
}

.log-message {
  flex: 1;
}

.log-info .log-message { color: #ffffff; }
.log-success .log-message { color: #4ade80; }
.log-warning .log-message { color: #fbbf24; }
.log-error .log-message { color: #ef4444; }
</style>
