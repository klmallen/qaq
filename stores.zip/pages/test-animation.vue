<template>
  <div class="test-animation-page">
    <h1>Animation Editor Test</h1>
    
    <div class="test-controls">
      <UButton @click="createTestMesh">Create Test Mesh</UButton>
      <UButton @click="openAnimationEditor" :disabled="!testMesh">Open Animation Editor</UButton>
    </div>
    
    <div class="test-content">
      <!-- 动画编辑器 -->
      <div v-if="showAnimationEditor" class="animation-editor-container">
        <h2>Animation Editor</h2>
        <QaqAnimationEditor
          :target-mesh="testMesh"
          @animation-created="onAnimationCreated"
          @animation-updated="onAnimationUpdated"
          @animation-deleted="onAnimationDeleted"
          @target-changed="onAnimationTargetChanged"
        />
      </div>
      
      <!-- 测试信息 -->
      <div class="test-info">
        <h3>Test Information</h3>
        <p>Test Mesh: {{ testMesh ? testMesh.name : 'None' }}</p>
        <p>Animation Editor Visible: {{ showAnimationEditor }}</p>
        
        <h4>Events Log:</h4>
        <div class="events-log">
          <div v-for="(event, index) in eventsLog" :key="index" class="event-item">
            {{ event }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { MeshInstance3D } from '~/core'
import QaqAnimationEditor from '~/components/editor/animation/QaqAnimationEditor.vue'

// 页面元数据
definePageMeta({
  layout: 'default'
})

// 响应式数据
const testMesh = ref<MeshInstance3D | null>(null)
const showAnimationEditor = ref(false)
const eventsLog = ref<string[]>([])

// 创建测试网格
function createTestMesh() {
  testMesh.value = new MeshInstance3D('TestMesh')
  testMesh.value.createBoxMesh()
  addEvent('Created test mesh: ' + testMesh.value.name)
}

// 打开动画编辑器
function openAnimationEditor() {
  if (testMesh.value) {
    showAnimationEditor.value = true
    addEvent('Opened animation editor for: ' + testMesh.value.name)
  }
}

// 动画事件处理
function onAnimationCreated(animation: any) {
  addEvent(`Animation created: ${animation.name}`)
}

function onAnimationUpdated(animation: any) {
  addEvent(`Animation updated: ${animation.name}`)
}

function onAnimationDeleted(animationId: string) {
  addEvent(`Animation deleted: ${animationId}`)
}

function onAnimationTargetChanged(target: any) {
  addEvent(`Animation target changed: ${target ? target.name : 'None'}`)
}

// 添加事件日志
function addEvent(message: string) {
  const timestamp = new Date().toLocaleTimeString()
  eventsLog.value.unshift(`[${timestamp}] ${message}`)
  
  // 限制日志条数
  if (eventsLog.value.length > 20) {
    eventsLog.value = eventsLog.value.slice(0, 20)
  }
}
</script>

<style scoped>
.test-animation-page {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.test-controls {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.test-content {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
}

.animation-editor-container {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 16px;
  background: #f9f9f9;
  min-height: 600px;
}

.test-info {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  background: #fff;
}

.events-log {
  max-height: 300px;
  overflow-y: auto;
  border: 1px solid #eee;
  border-radius: 4px;
  padding: 8px;
  background: #f8f8f8;
  font-family: monospace;
  font-size: 12px;
}

.event-item {
  padding: 2px 0;
  border-bottom: 1px solid #eee;
}

.event-item:last-child {
  border-bottom: none;
}

h1 {
  color: #333;
  margin-bottom: 20px;
}

h2, h3, h4 {
  color: #555;
  margin-bottom: 10px;
}
</style>
