<template>
  <div class="test-qaq-demo">
    <h1>QAQ引擎测试演示</h1>

    <div class="demo-status">
      <p v-if="isLoading">正在初始化引擎...</p>
      <p v-else-if="error" class="error">错误: {{ error }}</p>
      <p v-else class="success">引擎初始化成功！</p>
    </div>

    <div class="demo-controls">
      <button @click="initEngine" :disabled="isLoading">初始化引擎</button>
      <button @click="testBasicFeatures" :disabled="!engineReady">测试基础功能</button>
    </div>

    <div class="test-controls">
      <h3>QAQ引擎功能测试</h3>
      <div class="test-buttons">
        <button @click="testBasicRendering" class="btn btn-danger">测试基础渲染</button>
        <button @click="removeTestObjects" class="btn btn-secondary">移除测试对象</button>
        <button @click="testCamera2D" class="btn btn-primary">测试2D相机</button>
        <button @click="testQAQNodes" class="btn btn-info">测试QAQ节点</button>
        <button @click="testNodeCommunication" class="btn btn-success">测试节点通信</button>
        <button @click="testButtonInteraction" class="btn btn-warning">测试按钮交互</button>
      </div>
    </div>

    <div class="demo-canvas">
      <div id="qaq-test-canvas"></div>
    </div>

    <div class="demo-logs">
      <h3>日志</h3>
      <div class="log-container">
        <div v-for="(log, index) in logs" :key="index" class="log-entry">
          {{ log }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import * as THREE from 'three'

// 响应式数据
const isLoading = ref(false)
const error = ref('')
const engineReady = ref(false)
const logs = ref<string[]>([])

// 添加日志
const addLog = (message: string) => {
  const timestamp = new Date().toLocaleTimeString()
  logs.value.push(`[${timestamp}] ${message}`)
  console.log(message)
}

// 初始化引擎
const initEngine = async () => {
  try {
    isLoading.value = true
    error.value = ''

    addLog('开始初始化QAQ引擎...')

    // 动态导入引擎模块
    const { default: Engine } = await import('~/core/engine/Engine')
    addLog('✅ Engine模块导入成功')

    // 获取引擎实例
    const engine = Engine.getInstance()
    addLog('✅ 获取引擎实例成功')

    // 获取容器
    const container = document.getElementById('qaq-test-canvas')
    if (!container) {
      throw new Error('找不到画布容器')
    }

    // 初始化引擎
    const success = await engine.initialize({
      container: container,
      width: 800,
      height: 600,
      antialias: true,
      enableShadows: false
    })

    if (!success) {
      throw new Error('引擎初始化失败')
    }

    addLog('✅ 引擎初始化成功！')

    // 切换到2D模式
    engine.switchTo2D()
    addLog('✅ 切换到2D渲染模式')

    // 启动渲染循环
    engine.startRendering()
    addLog('✅ 渲染循环已启动')

    // 验证渲染器设置
    const renderer = engine.getRenderer()
    if (renderer) {
      addLog(`✅ 渲染器配置: 尺寸=${renderer.domElement.width}x${renderer.domElement.height}`)
      addLog(`✅ 渲染器透明度: ${renderer.getClearAlpha()}`)
    }

    // 验证相机设置
    const camera2D = engine.getCamera2D()
    if (camera2D) {
      addLog(`✅ 2D相机已创建: 位置(${camera2D.position.x}, ${camera2D.position.y}, ${camera2D.position.z})`)
    } else {
      addLog('⚠️ 2D相机未找到')
    }

    engineReady.value = true

  } catch (err) {
    error.value = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ 初始化失败: ${error.value}`)
    console.error('引擎初始化错误详情:', err)
  } finally {
    isLoading.value = false
  }
}

// 测试基础功能
const testBasicFeatures = async () => {
  try {
    addLog('🧪 开始测试QAQ引擎的2D功能...')

    // 动态导入所需模块
    const { default: Scene } = await import('~/core/scene/Scene')
    const { default: Node2D } = await import('~/core/nodes/Node2D')

    addLog('✅ 核心模块导入成功')

    // 获取引擎实例
    const { default: Engine } = await import('~/core/engine/Engine')
    const engine = Engine.getInstance()

    // 创建测试场景
    const scene = new Scene('Test2DScene', {
      type: 'MAIN',
      persistent: false,
      autoStart: true
    })

    addLog('✅ 场景创建成功')

    // 创建根节点
    const rootNode = new Node2D('Root2D')
    rootNode._renderLayer = '2D' // 确保在2D层渲染
    scene.addChild(rootNode)

    addLog('✅ 根节点创建成功')

    // 创建一个简单的测试精灵（使用Three.js原生对象）
    const testSprite = createTestSprite('TestSprite', 0, 0, 100, 100, '#ff6b35')
    rootNode.object3D.add(testSprite)

    addLog('✅ 测试精灵创建成功')

    // 创建测试按钮（使用Three.js原生对象）
    const button1 = createTestButton('Button1', -100, -100, 120, 40, '#007bff', '按钮1')
    rootNode.object3D.add(button1)

    const button2 = createTestButton('Button2', 100, -100, 120, 40, '#28a745', '按钮2')
    rootNode.object3D.add(button2)

    addLog('✅ 测试按钮创建成功')

    // 创建测试标签
    const label = createTestLabel('TestLabel', 0, 100, 'QAQ引擎2D测试', '#ffffff')
    rootNode.object3D.add(label)

    addLog('✅ 测试标签创建成功')

    // 设置为主场景
    await engine.setMainScene(scene)

    addLog('✅ 场景设置为主场景')

    // 验证场景内容
    const layer2D = engine.getLayer('2D')
    if (layer2D) {
      addLog(`✅ 2D层找到，包含 ${layer2D.children.length} 个对象`)
      layer2D.traverse((obj) => {
        if (obj.name) {
          addLog(`  - 对象: ${obj.name} (类型: ${obj.type})`)
        }
      })
    } else {
      addLog('❌ 2D层未找到')
    }

    // 验证相机设置
    const camera2D = engine.getCamera2D()
    if (camera2D) {
      addLog(`✅ 2D相机配置: left=${camera2D.left}, right=${camera2D.right}, top=${camera2D.top}, bottom=${camera2D.bottom}`)
    }

    addLog('🎉 QAQ引擎2D功能测试完成！')
    addLog('💡 如果看到内容，说明渲染管道正常工作')

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ 测试失败: ${errorMsg}`)
    console.error('测试错误详情:', err)
  }
}

// 创建测试精灵的辅助函数
const createTestSprite = (name: string, x: number, y: number, width: number, height: number, color: string) => {
  const geometry = new THREE.PlaneGeometry(width, height)
  const material = new THREE.MeshBasicMaterial({
    color: color,
    transparent: true,
    side: THREE.DoubleSide
  })
  const mesh = new THREE.Mesh(geometry, material)
  mesh.name = name
  mesh.position.set(x, y, 0)
  return mesh
}

// 创建测试按钮的辅助函数
const createTestButton = (name: string, x: number, y: number, width: number, height: number, color: string, text: string) => {
  // 创建Canvas用于按钮渲染
  const canvas = document.createElement('canvas')
  canvas.width = width * 2
  canvas.height = height * 2
  const context = canvas.getContext('2d')!

  // 绘制按钮
  context.fillStyle = color
  context.fillRect(0, 0, canvas.width, canvas.height)

  // 绘制边框
  context.strokeStyle = '#000000'
  context.lineWidth = 4
  context.strokeRect(2, 2, canvas.width - 4, canvas.height - 4)

  // 绘制文本
  context.fillStyle = '#ffffff'
  context.font = 'bold 24px Arial'
  context.textAlign = 'center'
  context.textBaseline = 'middle'
  context.fillText(text, canvas.width / 2, canvas.height / 2)

  // 创建纹理和网格
  const texture = new THREE.CanvasTexture(canvas)
  const geometry = new THREE.PlaneGeometry(width, height)
  const material = new THREE.MeshBasicMaterial({
    map: texture,
    transparent: true,
    side: THREE.DoubleSide
  })
  const mesh = new THREE.Mesh(geometry, material)
  mesh.name = name
  mesh.position.set(x, y, 0)
  return mesh
}

// 创建测试标签的辅助函数
const createTestLabel = (name: string, x: number, y: number, text: string, color: string) => {
  // 创建Canvas用于文本渲染
  const canvas = document.createElement('canvas')
  canvas.width = 512
  canvas.height = 128
  const context = canvas.getContext('2d')!

  // 绘制文本
  context.fillStyle = color
  context.font = '32px Arial'
  context.textAlign = 'center'
  context.textBaseline = 'middle'
  context.fillText(text, canvas.width / 2, canvas.height / 2)

  // 创建纹理和网格
  const texture = new THREE.CanvasTexture(canvas)
  const geometry = new THREE.PlaneGeometry(256, 64)
  const material = new THREE.MeshBasicMaterial({
    map: texture,
    transparent: true,
    side: THREE.DoubleSide
  })
  const mesh = new THREE.Mesh(geometry, material)
  mesh.name = name
  mesh.position.set(x, y, 0)
  return mesh
}

// 测试2D相机功能
const testCamera2D = async () => {
  try {
    addLog('🎥 开始测试2D相机功能...')

    // 获取引擎实例
    const { default: Engine } = await import('~/core/engine/Engine')
    const engine = Engine.getInstance()

    // 获取当前2D相机
    const camera2D = engine.getCamera2D()
    if (!camera2D) {
      addLog('❌ 2D相机未找到')
      return
    }

    addLog('✅ 2D相机已找到')
    addLog(`📍 相机位置: (${camera2D.position.x}, ${camera2D.position.y}, ${camera2D.position.z})`)
    addLog(`📐 相机视锥: left=${camera2D.left}, right=${camera2D.right}, top=${camera2D.top}, bottom=${camera2D.bottom}`)
    addLog(`🔍 相机缩放: ${camera2D.zoom}`)

    // 测试相机缩放
    const originalZoom = camera2D.zoom
    camera2D.zoom = 2.0
    camera2D.updateProjectionMatrix()
    addLog(`✅ 相机缩放从 ${originalZoom} 改为 ${camera2D.zoom}`)

    // 等待一秒后恢复
    setTimeout(() => {
      camera2D.zoom = originalZoom
      camera2D.updateProjectionMatrix()
      addLog(`🔄 相机缩放恢复为 ${camera2D.zoom}`)
    }, 2000)

    // 测试相机移动
    const originalX = camera2D.position.x
    const originalY = camera2D.position.y

    camera2D.position.x = 50
    camera2D.position.y = 50
    addLog(`✅ 相机移动到 (${camera2D.position.x}, ${camera2D.position.y})`)

    // 等待一秒后恢复
    setTimeout(() => {
      camera2D.position.x = originalX
      camera2D.position.y = originalY
      addLog(`🔄 相机位置恢复为 (${camera2D.position.x}, ${camera2D.position.y})`)
    }, 2000)

    addLog('💡 2D相机功能测试完成 - 观察画面变化')

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ 2D相机测试失败: ${errorMsg}`)
    console.error('相机测试错误:', err)
  }
}

// 测试QAQ原生节点
const testQAQNodes = async () => {
  try {
    addLog('🎮 开始测试QAQ原生2D节点...')

    // 动态导入QAQ节点模块
    const { default: Sprite2D } = await import('~/core/nodes/2d/Sprite2D')
    const { default: Button } = await import('~/core/nodes/2d/Button')
    const { default: Label } = await import('~/core/nodes/2d/Label')
    const { default: Scene } = await import('~/core/scene/Scene')
    const { default: Node2D } = await import('~/core/nodes/Node2D')

    addLog('✅ QAQ节点模块导入成功')

    // 获取引擎实例
    const { default: Engine } = await import('~/core/engine/Engine')
    const engine = Engine.getInstance()

    // 确保切换到2D模式
    engine.switchTo2D()
    addLog('✅ 切换到2D渲染模式')

    // 移除测试立方体以避免干扰
    engine.removeTestObjects()
    addLog('✅ 移除测试立方体')

    // 创建新的测试场景
    const scene = new Scene('QAQNodesTest', {
      type: 'MAIN',
      persistent: false,
      autoStart: true
    })

    const rootNode = new Node2D('QAQRoot')
    scene.addChild(rootNode)

    addLog('✅ QAQ测试场景创建成功')
    addLog(`📍 根节点渲染层: ${rootNode.renderLayer}`)

    // 创建Sprite2D节点（带纹理）
    try {
      const sprite = new Sprite2D('QAQSprite', {
        centered: true
      })

      // 创建简单的彩色纹理
      const canvas = document.createElement('canvas')
      canvas.width = 100
      canvas.height = 100
      const ctx = canvas.getContext('2d')!
      ctx.fillStyle = '#ff6b35'
      ctx.fillRect(0, 0, 100, 100)
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(10, 10, 80, 80)
      ctx.fillStyle = '#ff6b35'
      ctx.fillRect(20, 20, 60, 60)

      const texture = new THREE.CanvasTexture(canvas)
      sprite.texture = texture
      sprite.position = { x: 0, y: 50, z: 0 }
      sprite.size = { width: 100, height: 100 }

      rootNode.addChild(sprite)
      addLog('✅ Sprite2D节点创建并添加成功')

    } catch (spriteErr) {
      addLog(`❌ Sprite2D创建失败: ${spriteErr instanceof Error ? spriteErr.message : spriteErr}`)
      console.error('Sprite2D错误:', spriteErr)
    }

    // 创建Button节点
    try {
      const button = new Button('QAQButton', {
        text: 'QAQ按钮',
        styles: {
          normal: {
            backgroundColor: '#007bff',
            textColor: '#ffffff',
            borderColor: '#0056b3',
            borderWidth: 2
          }
        }
      })
      button.position = { x: -80, y: -50, z: 0 }
      button.size = { width: 120, height: 40 }

      rootNode.addChild(button)
      addLog('✅ Button节点创建并添加成功')

    } catch (buttonErr) {
      addLog(`❌ Button创建失败: ${buttonErr instanceof Error ? buttonErr.message : buttonErr}`)
      console.error('Button错误:', buttonErr)
    }

    // 创建Label节点
    try {
      const label = new Label('QAQLabel', {
        text: 'QAQ引擎2D渲染测试',
        style: {
          fontSize: 24,
          color: '#ffffff',
          fontFamily: 'Arial'
        }
      })
      label.position = { x: 0, y: 120, z: 0 }

      rootNode.addChild(label)
      addLog('✅ Label节点创建并添加成功')

    } catch (labelErr) {
      addLog(`❌ Label创建失败: ${labelErr instanceof Error ? labelErr.message : labelErr}`)
      console.error('Label错误:', labelErr)
    }

    // 设置为主场景
    await engine.setMainScene(scene)
    addLog('✅ QAQ节点测试场景已设置为主场景')

    // 验证2D层内容
    const layer2D = engine.getLayer('2D')
    if (layer2D) {
      addLog(`✅ 2D层包含 ${layer2D.children.length} 个对象`)
      layer2D.traverse((obj) => {
        if (obj.name && obj.name !== 'Layer2D') {
          addLog(`  - 2D对象: ${obj.name} (类型: ${obj.type})`)
        }
      })
    }

    // 验证相机设置
    const camera2D = engine.getCamera2D()
    if (camera2D) {
      addLog(`✅ 2D相机位置: (${camera2D.position.x}, ${camera2D.position.y}, ${camera2D.position.z})`)
    }

    addLog('🎉 QAQ原生节点测试完成！')
    addLog('💡 现在应该能看到橙色精灵、蓝色按钮和白色文本')

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ QAQ节点测试失败: ${errorMsg}`)
    console.error('QAQ节点测试错误:', err)
  }
}

// 测试节点通信
const testNodeCommunication = () => {
  addLog('📡 测试节点通信功能...')
  addLog('💡 节点通信已在基础功能测试中设置')
  addLog('💡 点击画布中的按钮可以看到节点间的通信效果')
  addLog('💡 按钮1点击会改变精灵颜色并通知按钮2')
  addLog('💡 按钮2点击会移动精灵位置并通知按钮1')
}

// 测试按钮交互
const testButtonInteraction = () => {
  addLog('🔘 测试按钮交互功能...')
  addLog('💡 两个测试按钮已创建在画布中')
  addLog('💡 蓝色按钮: 点击改变精灵颜色')
  addLog('💡 绿色按钮: 点击移动精灵位置')
  addLog('💡 请直接点击画布中的按钮进行交互测试')
}

// 测试基础渲染功能
const testBasicRendering = async () => {
  try {
    addLog('🎲 开始测试基础渲染功能...')

    // 获取引擎实例
    const { default: Engine } = await import('~/core/engine/Engine')
    const engine = Engine.getInstance()

    // 获取渲染器和场景
    const renderer = engine.getRenderer()
    const scene3D = engine.getLayer('3D')
    const camera3D = engine.getCamera3D()

    if (!renderer || !scene3D || !camera3D) {
      addLog('❌ 渲染器、场景或相机未找到')
      return
    }

    addLog('✅ 渲染器、场景和相机已找到')

    // 创建测试立方体
    const geometry = new THREE.BoxGeometry(100, 100, 100)
    const material = new THREE.MeshBasicMaterial({
      color: 0xff6b35,
      wireframe: false
    })
    const cube = new THREE.Mesh(geometry, material)
    cube.position.set(0, 0, 0)
    cube.name = 'TestCube'

    // 添加到3D场景
    scene3D.add(cube)
    addLog('✅ 测试立方体已添加到3D场景')

    // 设置3D相机位置
    camera3D.position.set(200, 200, 200)
    camera3D.lookAt(0, 0, 0)
    addLog('✅ 3D相机位置已设置')

    // 动态导入轨道控制器
    const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls.js')

    // 创建轨道控制器
    const controls = new OrbitControls(camera3D, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.05
    controls.enableZoom = true
    controls.enableRotate = true
    controls.enablePan = true

    addLog('✅ 轨道控制器已创建')

    // 添加立方体旋转动画
    let animationId: number
    const animate = () => {
      cube.rotation.x += 0.01
      cube.rotation.y += 0.01

      controls.update()

      animationId = requestAnimationFrame(animate)
    }

    // 启动动画
    animate()
    addLog('✅ 立方体旋转动画已启动')

    // 切换到3D模式确保渲染
    engine.switchTo3D()
    addLog('✅ 切换到3D渲染模式')

    // 验证场景内容
    addLog(`📊 3D场景包含 ${scene3D.children.length} 个对象`)
    scene3D.traverse((obj) => {
      if (obj.name) {
        addLog(`  - 对象: ${obj.name} (类型: ${obj.type})`)
      }
    })

    addLog('🎉 基础渲染测试完成！')
    addLog('💡 您应该能看到一个旋转的橙色立方体')
    addLog('💡 可以用鼠标拖拽旋转视角，滚轮缩放')

    // 5秒后停止动画并清理
    setTimeout(() => {
      if (animationId) {
        cancelAnimationFrame(animationId)
      }
      scene3D.remove(cube)
      controls.dispose()
      addLog('🧹 测试立方体和控制器已清理')
    }, 10000)

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ 基础渲染测试失败: ${errorMsg}`)
    console.error('基础渲染测试错误:', err)
  }
}

// 移除测试对象
const removeTestObjects = async () => {
  try {
    addLog('🧹 开始移除引擎内置测试对象...')

    // 获取引擎实例
    const { default: Engine } = await import('~/core/engine/Engine')
    const engine = Engine.getInstance()

    // 移除测试对象
    engine.removeTestObjects()

    addLog('✅ 引擎内置测试对象已移除')
    addLog('💡 现在可以测试其他功能而不受干扰')

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误'
    addLog(`❌ 移除测试对象失败: ${errorMsg}`)
    console.error('移除测试对象错误:', err)
  }
}

// 页面加载时自动初始化
onMounted(() => {
  addLog('页面加载完成')
})
</script>

<style scoped>
.test-qaq-demo {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

h1 {
  color: #333;
  text-align: center;
  margin-bottom: 30px;
}

.demo-status {
  text-align: center;
  margin-bottom: 20px;
  padding: 15px;
  border-radius: 8px;
  background: #f5f5f5;
}

.success {
  color: #28a745;
  font-weight: bold;
}

.error {
  color: #dc3545;
  font-weight: bold;
}

.demo-controls {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-bottom: 30px;
}

.test-controls {
  text-align: center;
  margin-bottom: 30px;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
  border: 2px solid #007bff;
}

.test-controls h3 {
  margin: 0 0 15px 0;
  color: #007bff;
  font-size: 18px;
}

.test-buttons {
  display: flex;
  justify-content: center;
  gap: 15px;
  flex-wrap: wrap;
}

button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background: #007bff;
  color: white;
  cursor: pointer;
  font-size: 14px;
}

button:hover:not(:disabled) {
  background: #0056b3;
}

button:disabled {
  background: #6c757d;
  cursor: not-allowed;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.btn-primary {
  background: #007bff;
  color: white;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-warning {
  background: #ffc107;
  color: #333;
}

.btn-info {
  background: #17a2b8;
  color: white;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.btn-secondary {
  background: #6c757d;
  color: white;
}

.btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.demo-canvas {
  display: flex;
  justify-content: center;
  margin-bottom: 30px;
}

#qaq-test-canvas {
  width: 800px;
  height: 600px;
  border: 2px solid #ddd;
  border-radius: 8px;
}

.demo-logs {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
}

.demo-logs h3 {
  margin: 0 0 15px 0;
  color: #333;
}

.log-container {
  max-height: 300px;
  overflow-y: auto;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 10px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
}

.log-entry {
  margin-bottom: 5px;
  color: #333;
}

.log-entry:last-child {
  margin-bottom: 0;
}
</style>
