<template>
  <div class="qaq-test-page">
    <div class="qaq-test-header">
      <h1>QAQ Game Engine - Component Test Page</h1>
      <p>This page tests all major components to ensure they load correctly.</p>
    </div>

    <div class="qaq-test-grid">
      <!-- 主编辑器测试 -->
      <div class="qaq-test-card">
        <h3>Main Editor</h3>
        <div class="qaq-test-status">
          <UIcon name="i-heroicons-check-circle" class="qaq-status-icon qaq-success" />
          <span>Available</span>
        </div>
        <p>Core editor with scene tree, 3D viewport, and property inspector.</p>
        <UButton @click="navigateTo('/editor')">Open Editor</UButton>
      </div>

      <!-- 代码编辑器测试 -->
      <div class="qaq-test-card">
        <h3>Code Editor</h3>
        <div class="qaq-test-status">
          <UIcon :name="monacoAvailable ? 'i-heroicons-check-circle' : 'i-heroicons-exclamation-triangle'" 
                 :class="monacoAvailable ? 'qaq-status-icon qaq-success' : 'qaq-status-icon qaq-warning'" />
          <span>{{ monacoAvailable ? 'Available' : 'Needs Monaco Editor' }}</span>
        </div>
        <p>Full-featured code editor with syntax highlighting.</p>
        <div v-if="!monacoAvailable" class="qaq-install-hint">
          <code>npm install monaco-editor</code>
        </div>
      </div>

      <!-- 材质编辑器测试 -->
      <div class="qaq-test-card">
        <h3>Material Editor (Simple)</h3>
        <div class="qaq-test-status">
          <UIcon name="i-heroicons-check-circle" class="qaq-status-icon qaq-success" />
          <span>Available</span>
        </div>
        <p>Basic node-based material editor.</p>
      </div>

      <!-- Vue Flow材质编辑器测试 -->
      <div class="qaq-test-card">
        <h3>Material Editor (Vue Flow)</h3>
        <div class="qaq-test-status">
          <UIcon :name="vueFlowAvailable ? 'i-heroicons-check-circle' : 'i-heroicons-exclamation-triangle'" 
                 :class="vueFlowAvailable ? 'qaq-status-icon qaq-success' : 'qaq-status-icon qaq-warning'" />
          <span>{{ vueFlowAvailable ? 'Available' : 'Needs Vue Flow' }}</span>
        </div>
        <p>Professional node-based material editor with advanced features.</p>
        <div v-if="!vueFlowAvailable" class="qaq-install-hint">
          <code>npm install @vue-flow/core @vue-flow/controls @vue-flow/minimap @vue-flow/background</code>
        </div>
      </div>

      <!-- 地形编辑器测试 -->
      <div class="qaq-test-card">
        <h3>Terrain Editor</h3>
        <div class="qaq-test-status">
          <UIcon name="i-heroicons-check-circle" class="qaq-status-icon qaq-success" />
          <span>Available</span>
        </div>
        <p>UE-style terrain sculpting with brushes and properties.</p>
      </div>

      <!-- Three.js测试 -->
      <div class="qaq-test-card">
        <h3>3D Rendering (Three.js)</h3>
        <div class="qaq-test-status">
          <UIcon name="i-heroicons-check-circle" class="qaq-status-icon qaq-success" />
          <span>Available</span>
        </div>
        <p>3D graphics rendering engine.</p>
      </div>
    </div>

    <div class="qaq-test-actions">
      <UButton @click="runAllTests" :loading="testing">
        Run All Tests
      </UButton>
      <UButton @click="navigateTo('/project-manager')" variant="outline">
        Go to Project Manager
      </UButton>
      <UButton @click="navigateTo('/editor')" variant="outline">
        Go to Editor
      </UButton>
    </div>

    <div v-if="testResults.length > 0" class="qaq-test-results">
      <h3>Test Results</h3>
      <div class="qaq-results-list">
        <div
          v-for="result in testResults"
          :key="result.name"
          class="qaq-result-item"
          :class="{ 'qaq-result-success': result.success, 'qaq-result-error': !result.success }"
        >
          <UIcon :name="result.success ? 'i-heroicons-check' : 'i-heroicons-x-mark'" />
          <span>{{ result.name }}: {{ result.message }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

// 响应式数据
const monacoAvailable = ref(false)
const vueFlowAvailable = ref(false)
const testing = ref(false)
const testResults = ref<Array<{ name: string; success: boolean; message: string }>>([])

// 检查依赖可用性
async function checkDependencies() {
  // 检查Monaco Editor
  try {
    await import('monaco-editor')
    monacoAvailable.value = true
  } catch {
    monacoAvailable.value = false
  }

  // 检查Vue Flow
  try {
    await import('@vue-flow/core')
    vueFlowAvailable.value = true
  } catch {
    vueFlowAvailable.value = false
  }
}

// 运行所有测试
async function runAllTests() {
  testing.value = true
  testResults.value = []

  const tests = [
    {
      name: 'Vue 3',
      test: () => typeof ref === 'function'
    },
    {
      name: 'Nuxt UI',
      test: () => document.querySelector('[data-nuxt-ui]') !== null
    },
    {
      name: 'Three.js',
      test: async () => {
        try {
          await import('three')
          return true
        } catch {
          return false
        }
      }
    },
    {
      name: 'Monaco Editor',
      test: async () => {
        try {
          await import('monaco-editor')
          return true
        } catch {
          return false
        }
      }
    },
    {
      name: 'Vue Flow',
      test: async () => {
        try {
          await import('@vue-flow/core')
          return true
        } catch {
          return false
        }
      }
    }
  ]

  for (const test of tests) {
    try {
      const result = await test.test()
      testResults.value.push({
        name: test.name,
        success: result,
        message: result ? 'Available' : 'Not available'
      })
    } catch (error) {
      testResults.value.push({
        name: test.name,
        success: false,
        message: `Error: ${error}`
      })
    }
  }

  testing.value = false
}

// 生命周期
onMounted(() => {
  checkDependencies()
})
</script>

<style scoped>
.qaq-test-page {
  min-height: 100vh;
  background-color: var(--qaq-bg-primary, #0a0a0a);
  color: var(--qaq-text-primary, #ffffff);
  padding: 32px;
}

.qaq-test-header {
  text-align: center;
  margin-bottom: 48px;
}

.qaq-test-header h1 {
  font-size: 2.5rem;
  font-weight: 700;
  margin: 0 0 16px 0;
  color: var(--qaq-accent, #00DC82);
}

.qaq-test-header p {
  font-size: 1.125rem;
  color: var(--qaq-text-secondary, #cccccc);
  margin: 0;
}

.qaq-test-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin-bottom: 48px;
}

.qaq-test-card {
  background-color: var(--qaq-bg-secondary, #1a1a1a);
  border-radius: 12px;
  padding: 24px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.qaq-test-card h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0 0 12px 0;
  color: var(--qaq-text-primary, #ffffff);
}

.qaq-test-status {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
}

.qaq-status-icon {
  width: 20px;
  height: 20px;
}

.qaq-success {
  color: #10b981;
}

.qaq-warning {
  color: #f59e0b;
}

.qaq-test-card p {
  color: var(--qaq-text-secondary, #cccccc);
  margin: 0 0 16px 0;
  line-height: 1.5;
}

.qaq-install-hint {
  background-color: var(--qaq-bg-tertiary, #2a2a2a);
  padding: 8px 12px;
  border-radius: 6px;
  margin: 12px 0;
}

.qaq-install-hint code {
  font-family: monospace;
  font-size: 0.875rem;
  color: var(--qaq-accent, #00DC82);
}

.qaq-test-actions {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-bottom: 48px;
}

.qaq-test-results {
  background-color: var(--qaq-bg-secondary, #1a1a1a);
  border-radius: 12px;
  padding: 24px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.qaq-test-results h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0 0 16px 0;
  color: var(--qaq-text-primary, #ffffff);
}

.qaq-results-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.qaq-result-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 6px;
}

.qaq-result-success {
  background-color: rgba(16, 185, 129, 0.1);
  color: #10b981;
}

.qaq-result-error {
  background-color: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}
</style>
