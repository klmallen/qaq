<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">模块导入测试</h1>
    <div class="space-y-4">
      <div class="p-4 bg-green-100 rounded">
        <h2 class="font-semibold">测试结果:</h2>
        <p v-if="importSuccess" class="text-green-600">✅ 模块导入成功！</p>
        <p v-else class="text-red-600">❌ 模块导入失败</p>
      </div>
      
      <div class="p-4 bg-blue-100 rounded">
        <h2 class="font-semibold">导入的类型:</h2>
        <ul class="list-disc list-inside">
          <li>SceneChangeMode: {{ sceneChangeMode }}</li>
          <li>SceneChangeOptions: {{ sceneChangeOptions }}</li>
        </ul>
      </div>
      
      <div class="p-4 bg-yellow-100 rounded">
        <h2 class="font-semibold">错误信息:</h2>
        <p v-if="error" class="text-red-600">{{ error }}</p>
        <p v-else class="text-green-600">无错误</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const importSuccess = ref(false)
const sceneChangeMode = ref(null)
const sceneChangeOptions = ref(null)
const error = ref(null)

onMounted(async () => {
  try {
    // 测试导入场景类型
    const { SceneChangeMode, SceneChangeOptions } = await import('~/core/scene/types')
    
    sceneChangeMode.value = Object.keys(SceneChangeMode)
    sceneChangeOptions.value = 'interface defined'
    importSuccess.value = true
    
    console.log('✅ 模块导入测试成功')
    console.log('SceneChangeMode:', SceneChangeMode)
    
  } catch (err) {
    error.value = err.message
    importSuccess.value = false
    console.error('❌ 模块导入测试失败:', err)
  }
})
</script>
