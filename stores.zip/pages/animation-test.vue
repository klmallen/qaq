<template>
  <div class="qaq-animation-test">
    <div class="qaq-test-header">
      <h1>QAQ 动画状态机编辑器测试</h1>
      <p>测试动画状态机编辑器的各项功能</p>
    </div>
    
    <div class="qaq-test-container">
      <QaqAnimationStateMachine />
    </div>
    
    <div class="qaq-test-instructions">
      <h2>使用说明</h2>
      <div class="qaq-instructions-grid">
        <div class="qaq-instruction-card">
          <h3>🖱️ 基本操作</h3>
          <ul>
            <li><strong>Q</strong> - 选择工具</li>
            <li><strong>W</strong> - 添加状态</li>
            <li><strong>E</strong> - 添加过渡</li>
            <li><strong>R</strong> - 设置入口状态</li>
            <li><strong>Delete</strong> - 删除选中项</li>
          </ul>
        </div>
        
        <div class="qaq-instruction-card">
          <h3>🎮 预览功能</h3>
          <ul>
            <li>点击播放按钮开始预览</li>
            <li>在调试面板中调整参数</li>
            <li>观察状态切换效果</li>
            <li>查看过渡条件触发</li>
          </ul>
        </div>
        
        <div class="qaq-instruction-card">
          <h3>⚙️ 编辑功能</h3>
          <ul>
            <li>拖拽节点移动位置</li>
            <li>选择节点编辑属性</li>
            <li>选择连接编辑过渡</li>
            <li>管理状态机参数</li>
          </ul>
        </div>
        
        <div class="qaq-instruction-card">
          <h3>🔗 过渡创建</h3>
          <ul>
            <li>选择过渡工具 (E)</li>
            <li>点击源状态节点</li>
            <li>点击目标状态节点</li>
            <li>编辑过渡条件</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import QaqAnimationStateMachine from '~/components/editor/QaqAnimationStateMachine.vue'

// 页面元数据
useHead({
  title: 'QAQ 动画状态机编辑器测试',
  meta: [
    { name: 'description', content: '测试QAQ游戏引擎的动画状态机编辑器功能' }
  ]
})
</script>

<style scoped>
.qaq-animation-test {
  min-height: 100vh;
  background: var(--qaq-editor-bg, #1a1a1a);
  color: var(--qaq-editor-text, #ffffff);
  padding: 20px;
}

.qaq-test-header {
  text-align: center;
  margin-bottom: 20px;
  padding: 20px;
  background: var(--qaq-editor-panel, #2a2a2a);
  border-radius: 8px;
  border: 1px solid var(--qaq-editor-border, #404040);
}

.qaq-test-header h1 {
  font-size: 28px;
  margin: 0 0 8px;
  color: var(--qaq-primary, #00DC82);
}

.qaq-test-header p {
  font-size: 16px;
  margin: 0;
  color: var(--qaq-editor-text-muted, #aaaaaa);
}

.qaq-test-container {
  height: 600px;
  margin-bottom: 30px;
  border: 2px solid var(--qaq-editor-border, #404040);
  border-radius: 8px;
  overflow: hidden;
}

.qaq-test-instructions {
  background: var(--qaq-editor-panel, #2a2a2a);
  border-radius: 8px;
  padding: 20px;
  border: 1px solid var(--qaq-editor-border, #404040);
}

.qaq-test-instructions h2 {
  font-size: 20px;
  margin: 0 0 20px;
  color: var(--qaq-primary, #00DC82);
  text-align: center;
}

.qaq-instructions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.qaq-instruction-card {
  background: rgba(0, 0, 0, 0.3);
  border-radius: 6px;
  padding: 16px;
  border: 1px solid var(--qaq-editor-border, #404040);
}

.qaq-instruction-card h3 {
  font-size: 16px;
  margin: 0 0 12px;
  color: var(--qaq-accent-blue, #3b82f6);
}

.qaq-instruction-card ul {
  margin: 0;
  padding-left: 20px;
}

.qaq-instruction-card li {
  margin-bottom: 6px;
  font-size: 14px;
  line-height: 1.4;
}

.qaq-instruction-card strong {
  color: var(--qaq-primary, #00DC82);
  font-weight: 600;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .qaq-animation-test {
    padding: 10px;
  }
  
  .qaq-test-container {
    height: 400px;
  }
  
  .qaq-instructions-grid {
    grid-template-columns: 1fr;
  }
  
  .qaq-test-header h1 {
    font-size: 24px;
  }
}
</style>
