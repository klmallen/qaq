<template>
  <div class="min-h-screen bg-black text-white p-8">
    <div class="max-w-4xl mx-auto">
      <h1 class="text-3xl font-bold mb-8 text-green-400">🧪 项目API测试页面</h1>
      
      <!-- 测试按钮 -->
      <div class="flex gap-4 mb-8">
        <UButton @click="testBasicAPI" :loading="testing.basic" color="blue">
          测试基础API
        </UButton>
        <UButton @click="testAuthenticatedAPI" :loading="testing.auth" color="green">
          测试认证API
        </UButton>
        <UButton @click="testProjectStore" :loading="testing.store" color="purple">
          测试项目Store
        </UButton>
        <UButton @click="initTestData" :loading="testing.init" color="orange">
          初始化测试数据
        </UButton>
        <UButton @click="clearResults" variant="outline">
          清除结果
        </UButton>
      </div>
      
      <!-- 认证状态 -->
      <div class="mb-6 p-4 bg-gray-800 rounded-lg">
        <h3 class="text-lg font-semibold mb-2">认证状态</h3>
        <div class="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span class="text-gray-400">已登录:</span>
            <span :class="authStore.isAuthenticated ? 'text-green-400' : 'text-red-400'">
              {{ authStore.isAuthenticated ? '✅ 是' : '❌ 否' }}
            </span>
          </div>
          <div>
            <span class="text-gray-400">用户:</span>
            <span class="text-blue-400">{{ authStore.user?.email || '未登录' }}</span>
          </div>
          <div>
            <span class="text-gray-400">Token:</span>
            <span :class="!!authStore.token ? 'text-green-400' : 'text-red-400'">
              {{ !!authStore.token ? '✅ 有效' : '❌ 无效' }}
            </span>
          </div>
          <div>
            <span class="text-gray-400">项目数量:</span>
            <span class="text-yellow-400">{{ projectStore.recentProjects.length }}</span>
          </div>
        </div>
      </div>
      
      <!-- 测试结果 -->
      <div class="space-y-4">
        <div v-for="(result, index) in testResults" :key="index" class="p-4 bg-gray-800 rounded-lg">
          <div class="flex items-center justify-between mb-2">
            <h3 class="font-semibold" :class="result.success ? 'text-green-400' : 'text-red-400'">
              {{ result.success ? '✅' : '❌' }} {{ result.title }}
            </h3>
            <span class="text-xs text-gray-400">{{ result.timestamp }}</span>
          </div>
          
          <div class="text-sm text-gray-300 mb-2">{{ result.message }}</div>
          
          <details v-if="result.data" class="text-xs">
            <summary class="cursor-pointer text-blue-400 hover:text-blue-300">查看详细数据</summary>
            <pre class="mt-2 p-2 bg-gray-900 rounded overflow-x-auto">{{ JSON.stringify(result.data, null, 2) }}</pre>
          </details>
          
          <div v-if="result.error" class="mt-2 p-2 bg-red-900/20 border border-red-500/20 rounded">
            <div class="text-red-400 text-sm font-semibold">错误信息:</div>
            <div class="text-red-300 text-xs">{{ result.error }}</div>
          </div>
        </div>
      </div>
      
      <!-- 空状态 -->
      <div v-if="testResults.length === 0" class="text-center py-12 text-gray-400">
        <UIcon name="i-heroicons-beaker" class="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>点击上方按钮开始测试API功能</p>
      </div>
    </div>
  </div>
</template>

<script setup>
// 页面元数据
definePageMeta({
  title: '项目API测试',
  layout: 'default'
})

// 使用stores
const authStore = useAuthStore()
const projectStore = useProjectStore()

// 响应式数据
const testResults = ref([])
const testing = ref({
  basic: false,
  auth: false,
  store: false,
  init: false
})

// 添加测试结果
function addResult(title, success, message, data = null, error = null) {
  testResults.value.unshift({
    title,
    success,
    message,
    data,
    error,
    timestamp: new Date().toLocaleTimeString()
  })
}

// 测试基础API
async function testBasicAPI() {
  testing.value.basic = true
  try {
    const response = await $fetch('/api/projects/test')
    addResult(
      '基础API测试',
      response.success,
      response.message,
      response.data
    )
  } catch (error) {
    addResult(
      '基础API测试',
      false,
      '基础API调用失败',
      null,
      error.message
    )
  } finally {
    testing.value.basic = false
  }
}

// 测试认证API
async function testAuthenticatedAPI() {
  testing.value.auth = true
  try {
    if (!authStore.token) {
      throw new Error('用户未登录，无法测试认证API')
    }
    
    const response = await $fetch('/api/projects', {
      headers: {
        'Authorization': `Bearer ${authStore.token}`
      }
    })
    
    addResult(
      '认证API测试',
      response.success,
      `${response.message} - 获取到 ${response.data?.projects?.length || 0} 个项目`,
      response.data
    )
  } catch (error) {
    addResult(
      '认证API测试',
      false,
      '认证API调用失败',
      null,
      error.message
    )
  } finally {
    testing.value.auth = false
  }
}

// 测试项目Store
async function testProjectStore() {
  testing.value.store = true
  try {
    if (!authStore.isAuthenticated) {
      throw new Error('用户未登录，无法测试项目Store')
    }
    
    await projectStore.fetchUserProjects()
    
    addResult(
      '项目Store测试',
      true,
      `Store调用成功 - 加载了 ${projectStore.recentProjects.length} 个项目`,
      projectStore.recentProjects
    )
  } catch (error) {
    addResult(
      '项目Store测试',
      false,
      'Store调用失败',
      null,
      error.message
    )
  } finally {
    testing.value.store = false
  }
}

// 初始化测试数据
async function initTestData() {
  testing.value.init = true
  try {
    // 这里应该调用初始化脚本，但在浏览器中无法直接执行
    // 作为替代，我们显示提示信息
    addResult(
      '初始化测试数据',
      false,
      '请在服务器端运行: node scripts/init-test-projects.js',
      null,
      '浏览器环境无法直接执行初始化脚本'
    )
  } finally {
    testing.value.init = false
  }
}

// 清除结果
function clearResults() {
  testResults.value = []
}

// 页面挂载时自动运行基础测试
onMounted(() => {
  testBasicAPI()
})
</script>

<style scoped>
pre {
  font-family: 'Courier New', monospace;
  font-size: 11px;
  line-height: 1.4;
}
</style>
