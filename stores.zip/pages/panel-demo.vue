<template>
  <div class="panel-demo">
    <h1>QAQ 可拖拽面板演示</h1>

    <div class="demo-controls">
      <UButton @click="resetPanels">重置面板位置</UButton>
      <UButton @click="togglePanel('demo1')">切换面板1</UButton>
      <UButton @click="togglePanel('demo2')">切换面板2</UButton>
      <UButton @click="togglePanel('demo3')">切换面板3</UButton>
    </div>

    <div class="demo-container">
      <!-- 演示面板1 -->
      <QaqDraggablePanel
        v-if="panels.demo1.visible"
        title="演示面板 1"
        icon="i-heroicons-squares-2x2"
        :width="panels.demo1.width"
        :height="panels.demo1.height"
        :x="panels.demo1.x"
        :y="panels.demo1.y"
        :can-resize-right="true"
        :can-resize-bottom="true"
        @resize="(size) => handlePanelResize('demo1', size)"
        @move="(pos) => handlePanelMove('demo1', pos)"
        @fullscreen="(fs) => handlePanelFullscreen('demo1', fs)"
        @close="() => closePanel('demo1')"
      >
        <div class="demo-content">
          <h3>这是演示面板 1</h3>
          <p>您可以：</p>
          <ul>
            <li>拖拽标题栏移动面板</li>
            <li>拖拽右边缘和底边缘调整大小</li>
            <li>双击标题栏或点击全屏按钮切换全屏</li>
            <li>点击关闭按钮关闭面板</li>
          </ul>

          <div class="demo-stats">
            <p>位置: ({{ panels.demo1.x }}, {{ panels.demo1.y }})</p>
            <p>大小: {{ panels.demo1.width }} × {{ panels.demo1.height }}</p>
          </div>
        </div>
      </QaqDraggablePanel>

      <!-- 演示面板2 -->
      <QaqDraggablePanel
        v-if="panels.demo2.visible"
        title="演示面板 2"
        icon="i-heroicons-cube"
        :width="panels.demo2.width"
        :height="panels.demo2.height"
        :x="panels.demo2.x"
        :y="panels.demo2.y"
        :can-resize-right="true"
        :can-resize-bottom="true"
        @resize="(size) => handlePanelResize('demo2', size)"
        @move="(pos) => handlePanelMove('demo2', pos)"
        @fullscreen="(fs) => handlePanelFullscreen('demo2', fs)"
        @close="() => closePanel('demo2')"
      >
        <div class="demo-content">
          <h3>这是演示面板 2</h3>
          <p>这个面板展示了不同的内容和样式。</p>

          <div class="demo-form">
            <UInput v-model="demoText" placeholder="输入一些文本..." />
            <UButton @click="addDemoItem">添加项目</UButton>
          </div>

          <div class="demo-list">
            <div v-for="(item, index) in demoItems" :key="index" class="demo-item">
              {{ item }}
            </div>
          </div>
        </div>
      </QaqDraggablePanel>

      <!-- 演示面板3 -->
      <QaqDraggablePanel
        v-if="panels.demo3.visible"
        title="演示面板 3"
        icon="i-heroicons-cog-6-tooth"
        :width="panels.demo3.width"
        :height="panels.demo3.height"
        :x="panels.demo3.x"
        :y="panels.demo3.y"
        :can-resize-right="false"
        :can-resize-bottom="true"
        @resize="(size) => handlePanelResize('demo3', size)"
        @move="(pos) => handlePanelMove('demo3', pos)"
        @fullscreen="(fs) => handlePanelFullscreen('demo3', fs)"
        @close="() => closePanel('demo3')"
      >
        <div class="demo-content">
          <h3>这是演示面板 3</h3>
          <p>这个面板只能垂直调整大小（不能水平调整）。</p>

          <div class="demo-settings">
            <div class="setting-item">
              <label>设置 1:</label>
              <UToggle v-model="settings.setting1" />
            </div>
            <div class="setting-item">
              <label>设置 2:</label>
              <UToggle v-model="settings.setting2" />
            </div>
            <div class="setting-item">
              <label>设置 3:</label>
              <URange v-model="settings.setting3" :min="0" :max="100" />
            </div>
          </div>
        </div>
      </QaqDraggablePanel>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import QaqDraggablePanel from '~/components/editor/QaqDraggablePanel.vue'

// 面板状态 - 优化紧凑布局
const panels = ref({
  demo1: {
    visible: true,
    x: 10,
    y: 10,
    width: 320,
    height: 280
  },
  demo2: {
    visible: true,
    x: 340,
    y: 10,
    width: 380,
    height: 320
  },
  demo3: {
    visible: true,
    x: 730,
    y: 10,
    width: 280,
    height: 380
  }
})

// 演示数据
const demoText = ref('')
const demoItems = ref(['项目 1', '项目 2', '项目 3'])
const settings = ref({
  setting1: false,
  setting2: true,
  setting3: 50
})

// 面板管理方法
function handlePanelResize(panelId: string, size: { width: number; height: number }) {
  const panel = panels.value[panelId as keyof typeof panels.value]
  if (panel) {
    panel.width = size.width
    panel.height = size.height
  }
}

function handlePanelMove(panelId: string, position: { x: number; y: number }) {
  const panel = panels.value[panelId as keyof typeof panels.value]
  if (panel) {
    panel.x = position.x
    panel.y = position.y
  }
}

function handlePanelFullscreen(panelId: string, isFullscreen: boolean) {
  console.log(`Panel ${panelId} fullscreen: ${isFullscreen}`)
}

function closePanel(panelId: string) {
  const panel = panels.value[panelId as keyof typeof panels.value]
  if (panel) {
    panel.visible = false
  }
}

function togglePanel(panelId: string) {
  const panel = panels.value[panelId as keyof typeof panels.value]
  if (panel) {
    panel.visible = !panel.visible
  }
}

function resetPanels() {
  panels.value.demo1 = { visible: true, x: 10, y: 10, width: 320, height: 280 }
  panels.value.demo2 = { visible: true, x: 340, y: 10, width: 380, height: 320 }
  panels.value.demo3 = { visible: true, x: 730, y: 10, width: 280, height: 380 }
}

function addDemoItem() {
  if (demoText.value.trim()) {
    demoItems.value.push(demoText.value.trim())
    demoText.value = ''
  }
}
</script>

<style scoped>
.panel-demo {
  min-height: 100vh;
  background: var(--qaq-editor-bg, #1a1a1a);
  color: var(--qaq-editor-text, #ffffff);
  padding: 20px;
}

.panel-demo h1 {
  color: var(--qaq-primary, #00DC82);
  margin-bottom: 20px;
}

.demo-controls {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  padding: 16px;
  background: var(--qaq-editor-panel, #2a2a2a);
  border-radius: 8px;
}

.demo-container {
  position: relative;
  height: calc(100vh - 200px);
  background: var(--qaq-editor-bg, #0a0a0a);
  border: 1px solid var(--qaq-editor-border, #404040);
  border-radius: 8px;
  overflow: hidden;
}

.demo-content {
  padding: 16px;
}

.demo-content h3 {
  color: var(--qaq-primary, #00DC82);
  margin-bottom: 12px;
}

.demo-content ul {
  margin: 12px 0;
  padding-left: 20px;
}

.demo-stats {
  margin-top: 16px;
  padding: 12px;
  background: var(--qaq-editor-bg, #0a0a0a);
  border-radius: 4px;
  font-family: monospace;
  font-size: 12px;
}

.demo-form {
  display: flex;
  gap: 8px;
  margin: 16px 0;
}

.demo-list {
  max-height: 150px;
  overflow-y: auto;
}

.demo-item {
  padding: 8px;
  margin: 4px 0;
  background: var(--qaq-editor-bg, #0a0a0a);
  border-radius: 4px;
  border-left: 3px solid var(--qaq-primary, #00DC82);
}

.demo-settings {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.setting-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.setting-item label {
  font-size: 14px;
  color: var(--qaq-editor-text-secondary, #cccccc);
}
</style>
