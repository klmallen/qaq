<template>
  <div class="qaq-home min-h-screen" style="background-color: var(--qaq-bg-primary)">
    <!-- 顶部导航栏 -->
    <header class="flex justify-between items-center p-6">
      <div class="flex items-center space-x-3">
        <UIcon
          name="i-heroicons-cube-transparent"
          class="w-8 h-8"
          style="color: var(--qaq-accent)"
        />
        <h1 class="text-xl font-bold" style="color: var(--qaq-text-primary)">
          QAQ Game Engine
        </h1>
      </div>

      <!-- 用户状态区域 -->
      <div class="flex items-center space-x-4">
        <!-- 语言切换器 -->
        <LanguageSwitcher />

        <!-- 已登录用户下拉菜单 -->
        <QaqUserDropdown v-if="authStore.isAuthenticated" />

        <!-- 调试按钮（开发环境） -->
        <UButton
          v-if="authStore.isAuthenticated && isDev"
          @click="showDebug = !showDebug"
          variant="ghost"
          size="sm"
          icon="i-heroicons-bug-ant"
        >
          {{ t('common.debug') || '调试' }}
        </UButton>

        <!-- 登录按钮 -->
        <UButton
          v-else
          @click="navigateTo('/auth/login')"
          icon="i-heroicons-user-circle"
          variant="outline"
          size="sm"
        >
          {{ t('auth.login') }}
        </UButton>
      </div>
    </header>

    <!-- 主要内容区域 -->
    <div class="flex items-center justify-center" style="min-height: calc(100vh - 120px)">
      <div class="max-w-4xl mx-auto px-6 text-center">
        <!-- Logo and Title -->
        <div class="mb-12">
          <UIcon
            name="i-heroicons-cube-transparent"
            class="w-24 h-24 mx-auto mb-6"
            style="color: var(--qaq-accent)"
          />
          <h1 class="text-6xl font-bold mb-4" style="color: var(--qaq-text-primary)">
            QAQ Game Engine
          </h1>
          <p class="text-xl mb-8" style="color: var(--qaq-text-secondary)">
            A modern game engine editor built with Vue 3 + Nuxt UI Pro
          </p>
          <p style="color: var(--qaq-text-muted)">
            Inspired by Godot, powered by modern web technologies
          </p>
        </div>

        <!-- Action Buttons -->
        <div v-if="authStore.isAuthenticated" class="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <UButton
            @click="showCreateProjectModal = true"
            size="xl"
            icon="i-heroicons-folder-plus"
            class="w-full sm:w-auto"
          >
            Create New Project
          </UButton>

          <UButton
            @click="navigateTo('/profile/projects')"
            size="xl"
            variant="outline"
            icon="i-heroicons-folder-open"
            class="w-full sm:w-auto"
          >
            My Projects
          </UButton>

          <UButton
            @click="navigateTo('/test-2d')"
            size="xl"
            variant="soft"
            icon="i-heroicons-cube"
            class="w-full sm:w-auto"
          >
            2D节点演示
          </UButton>

          <UButton
            @click="navigateTo('/demo-2d-nodes')"
            size="xl"
            variant="ghost"
            icon="i-heroicons-play"
            class="w-full sm:w-auto"
          >
            QAQ引擎演示
          </UButton>

          <UButton
            @click="navigateTo('/test-qaq-demo')"
            size="xl"
            variant="soft"
            icon="i-heroicons-wrench-screwdriver"
            class="w-full sm:w-auto"
          >
            引擎测试
          </UButton>

          <UButton
            @click="navigateTo('/camera-demo')"
            size="xl"
            variant="outline"
            icon="i-heroicons-camera"
            class="w-full sm:w-auto"
          >
            2D相机演示
          </UButton>
        </div>

        <!-- 未登录时的提示 -->
        <div v-else class="mb-12">
          <p class="text-lg mb-6" style="color: var(--qaq-text-secondary)">
            请先登录以访问项目管理功能，或查看演示了解引擎功能
          </p>
          <div class="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <UButton
              @click="navigateTo('/auth/login')"
              size="xl"
              icon="i-heroicons-user-circle"
              class="w-full sm:w-auto"
            >
              立即登录
            </UButton>
            <UButton
              @click="navigateTo('/test-2d')"
              size="xl"
              variant="outline"
              icon="i-heroicons-cube"
              class="w-full sm:w-auto"
            >
              查看2D节点演示
            </UButton>
            <UButton
              @click="navigateTo('/demo-2d-nodes')"
              size="xl"
              variant="ghost"
              icon="i-heroicons-play"
              class="w-full sm:w-auto"
            >
              QAQ引擎演示
            </UButton>
            <UButton
              @click="navigateTo('/test-qaq-demo')"
              size="xl"
              variant="soft"
              icon="i-heroicons-wrench-screwdriver"
              class="w-full sm:w-auto"
            >
              引擎测试
            </UButton>
            <UButton
              @click="navigateTo('/camera-demo')"
              size="xl"
              variant="outline"
              icon="i-heroicons-camera"
              class="w-full sm:w-auto"
            >
              2D相机演示
            </UButton>
          </div>
        </div>

        <!-- Recent Projects (仅在已登录时显示) -->
        <div v-if="authStore.isAuthenticated && recentProjects.length > 0" class="mb-12">
          <h2 class="text-2xl font-semibold text-white mb-6">Recent Projects</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <UCard
              v-for="project in recentProjects.slice(0, 6)"
              :key="project.id"
              class="hover:bg-gray-800 transition-colors cursor-pointer"
              @click="openProject(project)"
            >
              <template #header>
                <div class="flex items-center justify-between">
                  <UIcon name="i-heroicons-folder" class="w-6 h-6 text-primary-500" />
                  <span class="text-xs text-gray-400">
                    {{ formatDate(project.lastOpened) }}
                  </span>
                </div>
              </template>

              <div>
                <h3 class="font-semibold text-white mb-2">{{ project.name }}</h3>
                <p class="text-sm text-gray-400 truncate">{{ project.path }}</p>
              </div>
            </UCard>
          </div>
        </div>

        <!-- Features -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div class="text-center">
            <UIcon name="i-heroicons-cube" class="w-12 h-12 text-primary-500 mx-auto mb-4" />
            <h3 class="text-lg font-semibold text-white mb-2">Node-Based Architecture</h3>
            <p class="text-gray-400">
              Flexible scene system with hierarchical nodes, just like Godot
            </p>
          </div>

          <div class="text-center">
            <UIcon name="i-heroicons-code-bracket" class="w-12 h-12 text-primary-500 mx-auto mb-4" />
            <h3 class="text-lg font-semibold text-white mb-2">Modern Web Stack</h3>
            <p class="text-gray-400">
              Built with Vue 3, Nuxt UI Pro, TypeScript, and Three.js
            </p>
          </div>

          <div class="text-center">
            <UIcon name="i-heroicons-paint-brush" class="w-12 h-12 text-primary-500 mx-auto mb-4" />
            <h3 class="text-lg font-semibold text-white mb-2">Beautiful UI</h3>
            <p class="text-gray-400">
              Clean, modern interface with Nuxt UI Pro components
            </p>
          </div>
        </div>

        <!-- Footer -->
        <div class="text-center text-gray-500">
          <p class="mb-2">QAQ Game Engine v1.0.0</p>
          <div class="flex justify-center space-x-4">
            <UButton
              variant="ghost"
              size="sm"
              icon="i-heroicons-book-open"
              @click="openDocumentation"
            >
              Documentation
            </UButton>
            <UButton
              variant="ghost"
              size="sm"
              icon="i-heroicons-chat-bubble-left-right"
              @click="openCommunity"
            >
              Community
            </UButton>
            <UButton
              variant="ghost"
              size="sm"
              icon="i-heroicons-information-circle"
              @click="showAbout = true"
            >
              About
            </UButton>
          </div>
        </div>
      </div>
    </div>

    <!-- About Modal -->
    <UModal v-model="showAbout">
      <UCard>
        <template #header>
          <div class="flex items-center justify-between">
            <h2 class="text-xl font-bold">About QAQ Game Engine</h2>
            <UButton
              @click="showAbout = false"
              variant="ghost"
              icon="i-heroicons-x-mark"
              size="sm"
            />
          </div>
        </template>

        <div class="space-y-4">
          <div class="text-center">
            <UIcon name="i-heroicons-cube-transparent" class="w-16 h-16 text-primary-500 mx-auto mb-4" />
            <h3 class="text-lg font-semibold mb-2">QAQ Game Engine</h3>
            <p class="text-gray-400 mb-4">Version 1.0.0</p>
          </div>

          <div>
            <p class="text-gray-300 mb-4">
              QAQ Game Engine is a modern web-based game engine editor inspired by Godot Engine.
              Built with cutting-edge web technologies including Vue 3, Nuxt UI Pro, and Three.js.
            </p>

            <h4 class="font-semibold mb-2">Technologies Used:</h4>
            <ul class="text-sm text-gray-400 space-y-1">
              <li>• Vue 3 - Progressive JavaScript framework</li>
              <li>• Nuxt 3 - Full-stack Vue framework</li>
              <li>• Nuxt UI Pro - Beautiful UI components</li>
              <li>• TypeScript - Type-safe JavaScript</li>
              <li>• Three.js - 3D graphics library</li>
              <li>• Pinia - State management</li>
            </ul>
          </div>
        </div>
      </UCard>
    </UModal>

    <!-- Create Project Modal -->
    <!-- <CreateProjectModal
      v-model="showCreateProjectModal"
      @create="handleProjectCreated"
    /> -->

    <!-- 调试面板 -->
    <UModal v-model="showDebug" :ui="{ width: 'max-w-4xl' }">
      <div class="p-6">
        <UserInfoDebug />
      </div>
    </UModal>
  </div>
</template>

<script setup>
// import CreateProjectModal from '~/components/CreateProjectModal.vue'
// 页面元数据
definePageMeta({
  title: 'QAQ Game Engine',
  layout: 'default'
})

// 使用 Pinia store 和 i18n
const authStore = useAuthStore()
const projectStore = useProjectStore()
const { t } = useI18n()

// 响应式数据
const showAbout = ref(false)
const showCreateProjectModal = ref(false)
const showDebug = ref(false)

// 开发环境检查
const isDev = process.env.NODE_ENV === 'development'

// 计算属性
const recentProjects = computed(() => projectStore.recentProjects)

// 方法
async function openProject(project) {
  try {
    await projectStore.openProject(project.path)
    navigateTo('/editor')
  } catch (error) {
    console.error('Failed to open project:', error)
  }
}



function formatDate(date) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(new Date(date))
}

function openDocumentation() {
  // TODO: 打开文档
  console.log('Opening documentation...')
}

function openCommunity() {
  // TODO: 打开社区
  console.log('Opening community...')
}

async function handleProjectCreated(project) {
  console.log('✅ 项目创建成功:', project)

  // 将新项目添加到项目列表
  projectStore.addToRecentProjects(project)

  // 重新获取项目列表以确保数据同步
  try {
    await projectStore.fetchUserProjects()
  } catch (error) {
    console.warn('⚠️ 刷新项目列表失败:', error)
  }

  // 导航到项目管理页面
  navigateTo('/profile/projects')
}

// 页面挂载时检查认证状态
onMounted(async () => {
  console.log('🏠 首页加载，检查认证状态...')

  // 等待认证状态稳定，给autoLogin更多时间完成
  await new Promise(resolve => setTimeout(resolve, 200))

  // 如果用户已登录，加载项目列表
  if (authStore.isAuthenticated && authStore.token) {
    console.log('✅ 用户已登录且有令牌，加载项目列表...')
    try {
      await projectStore.fetchUserProjects()
    } catch (error) {
      console.warn('⚠️ 首页项目列表加载失败:', error)
    }
  } else {
    console.log('❌ 用户未登录或无令牌，跳过项目加载')
  }
})

// 监听认证状态变化
watch(() => authStore.isAuthenticated, async (isAuthenticated) => {
  if (isAuthenticated && authStore.token) {
    console.log('🔄 检测到用户登录且有令牌，自动加载项目列表...')
    try {
      await projectStore.fetchUserProjects()
    } catch (error) {
      console.warn('⚠️ 认证状态变化后项目列表加载失败:', error)
    }
  }
}, { immediate: false })

// 监听令牌变化
watch(() => authStore.token, async (token) => {
  if (token && authStore.isAuthenticated) {
    console.log('🔄 检测到令牌变化，重新加载项目列表...')
    try {
      await projectStore.fetchUserProjects()
    } catch (error) {
      console.warn('⚠️ 令牌变化后项目列表加载失败:', error)
    }
  }
}, { immediate: false })
</script>
