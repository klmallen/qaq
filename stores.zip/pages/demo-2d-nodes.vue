<template>
  <div class="demo-page">
    <!-- 头部导航 -->
    <header class="demo-header">
      <h1 class="demo-title">QAQ游戏引擎 - 2D节点演示</h1>
      <div class="demo-controls">
        <select v-model="currentDemoIndex" @change="switchDemo" class="demo-selector">
          <option v-for="(demo, index) in demoList" :key="index" :value="index">
            {{ demo.name }}
          </option>
        </select>
        <button @click="togglePlay" class="btn" :class="isPlaying ? 'btn-pause' : 'btn-play'">
          {{ isPlaying ? '⏸️ 暂停' : '▶️ 播放' }}
        </button>
        <button @click="resetDemo" class="btn btn-reset">🔄 重置</button>
      </div>
    </header>

    <!-- 主要内容区域 -->
    <main class="demo-main">
      <!-- 左侧信息面板 -->
      <aside class="info-panel">
        <div class="demo-info">
          <h3>{{ currentDemo?.name }}</h3>
          <p class="demo-description">{{ currentDemo?.description }}</p>
        </div>

        <!-- 统计信息 -->
        <div class="stats-panel">
          <h4>性能统计</h4>
          <div class="stat-item">
            <span class="stat-label">FPS:</span>
            <span class="stat-value">{{ stats.fps }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">节点数:</span>
            <span class="stat-value">{{ stats.nodeCount }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">渲染时间:</span>
            <span class="stat-value">{{ stats.renderTime.toFixed(2) }}ms</span>
          </div>
        </div>

        <!-- 控制面板 -->
        <div class="controls-panel">
          <h4>演示控制</h4>

          <!-- 通用控制 -->
          <div class="control-group">
            <label>缩放:</label>
            <input
              v-model.number="cameraZoom"
              type="range"
              min="0.5"
              max="3"
              step="0.1"
              @input="updateCameraZoom"
            />
            <span>{{ (cameraZoom * 100).toFixed(0) }}%</span>
          </div>

          <!-- 动画控制 -->
          <div v-if="isAnimationDemo" class="control-group">
            <label>动画速度:</label>
            <input
              v-model.number="animationSpeed"
              type="range"
              min="0.1"
              max="3"
              step="0.1"
              @input="updateAnimationSpeed"
            />
            <span>{{ animationSpeed.toFixed(1) }}x</span>
          </div>

          <!-- 调试选项 -->
          <div class="control-group">
            <label>
              <input v-model="showDebugInfo" type="checkbox" @change="toggleDebugInfo" />
              显示调试信息
            </label>
          </div>

          <div class="control-group">
            <label>
              <input v-model="showBoundingBoxes" type="checkbox" @change="toggleBoundingBoxes" />
              显示边界框
            </label>
          </div>

          <!-- 交互测试 -->
          <div class="control-group">
            <button @click="testRotateSprites" class="btn btn-secondary btn-small">
              旋转精灵
            </button>
          </div>

          <div class="control-group">
            <button @click="testChangeColors" class="btn btn-secondary btn-small">
              改变颜色
            </button>
          </div>
        </div>

        <!-- 精灵表编辑器入口 -->
        <div class="editor-panel">
          <h4>编辑工具</h4>
          <button @click="openSpriteSheetEditor" class="btn btn-primary btn-full">
            🎨 打开精灵表编辑器
          </button>
        </div>
      </aside>

      <!-- 中央画布区域 -->
      <section class="canvas-container">
        <div id="game-canvas" class="game-canvas"></div>

        <!-- 加载指示器 -->
        <div v-if="isLoading" class="loading-overlay">
          <div class="loading-spinner"></div>
          <p>正在加载演示...</p>
        </div>

        <!-- 错误提示 -->
        <div v-if="error" class="error-overlay">
          <div class="error-content">
            <h3>❌ 演示加载失败</h3>
            <p>{{ error }}</p>
            <button @click="retryDemo" class="btn btn-primary">重试</button>
          </div>
        </div>
      </section>

      <!-- 右侧工具面板 -->
      <aside class="tools-panel">
        <!-- 节点树 -->
        <div class="node-tree">
          <h4>场景节点树</h4>
          <div class="tree-container">
            <div v-for="node in sceneNodes" :key="node.id" class="tree-node">
              <span class="node-icon">{{ getNodeIcon(node.type) }}</span>
              <span class="node-name">{{ node.name }}</span>
              <span class="node-type">{{ node.type }}</span>
            </div>
          </div>
        </div>

        <!-- 属性面板 -->
        <div class="properties-panel">
          <h4>节点属性</h4>
          <div v-if="selectedNode" class="property-list">
            <div v-for="prop in selectedNode.properties" :key="prop.name" class="property-item">
              <label>{{ prop.label }}:</label>
              <span>{{ prop.value }}</span>
            </div>
          </div>
          <div v-else class="no-selection">
            <p>请选择一个节点查看属性</p>
          </div>
        </div>

        <!-- 日志面板 -->
        <div class="log-panel">
          <h4>控制台日志</h4>
          <div class="log-container" ref="logContainer">
            <div
              v-for="(log, index) in logs"
              :key="index"
              class="log-entry"
              :class="log.level"
            >
              <span class="log-time">{{ log.time }}</span>
              <span class="log-message">{{ log.message }}</span>
            </div>
          </div>
          <button @click="clearLogs" class="btn btn-secondary btn-small">清除日志</button>
        </div>
      </aside>
    </main>

    <!-- 精灵表编辑器模态框 -->
    <div v-if="showSpriteSheetEditor" class="modal-overlay" @click="closeSpriteSheetEditor">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>精灵表动画编辑器</h3>
          <button @click="closeSpriteSheetEditor" class="btn-close">×</button>
        </div>
        <div class="modal-body">
          <SpriteSheetEditor @close="closeSpriteSheetEditor" @export="handleAnimationExport" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { QAQ2DDemo } from '~/demos/qaq-2d-demo'
import SpriteSheetEditor from '~/components/editor/SpriteSheetEditor.vue'

// 类型定义
interface DemoItem {
  name: string
  description: string
}

interface Stats {
  fps: number
  nodeCount: number
  renderTime: number
}

interface LogEntry {
  time: string
  level: 'info' | 'warn' | 'error'
  message: string
}

interface SceneNode {
  id: string
  name: string
  type: string
  properties: Array<{ name: string; label: string; value: any }>
}

// 响应式数据
const demo = ref<QAQ2DDemo | null>(null)
const isLoading = ref(true)
const error = ref<string>('')
const isPlaying = ref(false)

const currentDemoIndex = ref(0)
const demoList = ref<DemoItem[]>([
  { name: 'Sprite2D 基础演示', description: '展示Sprite2D的基本功能' },
  { name: 'AnimatedSprite2D 动画演示', description: '展示动画功能' },
  { name: 'SpriteSheetAnimator2D 精灵表动画', description: '展示精灵表动画功能' },
  { name: 'Label 文本演示', description: '展示文本渲染功能' },
  { name: 'Button 按钮演示', description: '展示按钮交互功能' },
  { name: 'Panel 面板演示', description: '展示面板容器功能' },
  { name: 'TextureRect 纹理演示', description: '展示纹理显示功能' },
  { name: '综合UI演示', description: '展示复杂UI界面' },
  { name: '性能测试', description: '测试渲染性能' }
])

const currentDemo = computed(() => demoList.value[currentDemoIndex.value])

const stats = reactive<Stats>({
  fps: 60,
  nodeCount: 0,
  renderTime: 0
})

const cameraZoom = ref(1)
const animationSpeed = ref(1)
const showDebugInfo = ref(false)
const showBoundingBoxes = ref(false)

const isAnimationDemo = computed(() => {
  return currentDemo.value?.name.includes('动画') || false
})

const sceneNodes = ref<SceneNode[]>([])
const selectedNode = ref<SceneNode | null>(null)

const logs = ref<LogEntry[]>([])
const logContainer = ref<HTMLDivElement>()

const showSpriteSheetEditor = ref(false)

// 方法
const initializeDemo = async () => {
  try {
    isLoading.value = true
    error.value = ''

    console.log('🚀 初始化2D节点演示...')

    // 创建演示实例
    demo.value = new QAQ2DDemo()

    // 初始化演示系统
    const success = await demo.value.initialize('game-canvas', 800, 600)

    if (!success) {
      throw new Error('演示系统初始化失败')
    }

    // 启动演示
    demo.value.start()
    isPlaying.value = true

    // 启动统计更新
    startStatsUpdate()

    console.log('✅ 2D节点演示初始化完成')

  } catch (err) {
    error.value = err instanceof Error ? err.message : '未知错误'
    console.error('❌ 演示初始化失败:', err)
  } finally {
    isLoading.value = false
  }
}

const switchDemo = async () => {
  console.log(`切换到演示: ${currentDemo.value.name}`)
  // 简化版本暂时不支持多个演示
  addLog('info', `切换到演示: ${currentDemo.value.name}`)
}

const togglePlay = () => {
  if (!demo.value) return

  if (isPlaying.value) {
    demo.value.stop()
    isPlaying.value = false
    console.log('⏸️ 暂停演示')
  } else {
    demo.value.start()
    isPlaying.value = true
    console.log('▶️ 开始演示')
  }
}

const resetDemo = async () => {
  console.log('🔄 重置演示')
  if (demo.value) {
    demo.value.destroy()
  }
  await initializeDemo()
}

const retryDemo = async () => {
  error.value = ''
  await initializeDemo()
}

const updateCameraZoom = () => {
  console.log(`相机缩放: ${cameraZoom.value}`)
  addLog('info', `相机缩放设置为: ${(cameraZoom.value * 100).toFixed(0)}%`)
}

const updateAnimationSpeed = () => {
  console.log(`动画速度: ${animationSpeed.value}`)
  addLog('info', `动画速度设置为: ${animationSpeed.value.toFixed(1)}x`)
}

const toggleDebugInfo = () => {
  console.log(`调试信息: ${showDebugInfo.value ? '开启' : '关闭'}`)
  addLog('info', `调试信息: ${showDebugInfo.value ? '开启' : '关闭'}`)
}

const toggleBoundingBoxes = () => {
  console.log(`边界框: ${showBoundingBoxes.value ? '显示' : '隐藏'}`)
  addLog('info', `边界框: ${showBoundingBoxes.value ? '显示' : '隐藏'}`)
}

const startStatsUpdate = () => {
  const updateStats = () => {
    if (demo.value && isPlaying.value) {
      const demoStats = demo.value.getStats()
      stats.fps = demoStats.fps
      stats.nodeCount = demoStats.nodeCount
      stats.renderTime = demoStats.renderTime

      // 继续更新
      setTimeout(updateStats, 100)
    }
  }
  updateStats()
}

const updateSceneNodes = () => {
  sceneNodes.value = [
    {
      id: '1',
      name: 'Scene',
      type: 'Scene',
      properties: [
        { name: 'name', label: '名称', value: '2DNodesDemo' },
        { name: 'children', label: '子节点数', value: 5 }
      ]
    },
    {
      id: '2',
      name: 'Sprite2D',
      type: 'Sprite2D',
      properties: [
        { name: 'position', label: '位置', value: '(0, 0)' },
        { name: 'scale', label: '缩放', value: '(1, 1)' }
      ]
    }
  ]
}

const getNodeIcon = (nodeType: string): string => {
  const icons: Record<string, string> = {
    'Scene': '🎬',
    'Node2D': '📐',
    'Sprite2D': '🖼️',
    'AnimatedSprite2D': '🎞️',
    'Label': '📝',
    'Button': '🔘',
    'Panel': '📋',
    'TextureRect': '🖼️'
  }
  return icons[nodeType] || '📦'
}

const addLog = (level: 'info' | 'warn' | 'error', message: string) => {
  const now = new Date()
  const time = now.toLocaleTimeString()

  logs.value.push({ time, level, message })

  if (logs.value.length > 100) {
    logs.value.shift()
  }

  nextTick(() => {
    if (logContainer.value) {
      logContainer.value.scrollTop = logContainer.value.scrollHeight
    }
  })
}

const clearLogs = () => {
  logs.value = []
}

const openSpriteSheetEditor = () => {
  showSpriteSheetEditor.value = true
}

const closeSpriteSheetEditor = () => {
  showSpriteSheetEditor.value = false
}

const handleAnimationExport = (animationData: any) => {
  console.log('导出动画数据:', animationData)
  addLog('info', '动画数据已导出')
}

const testRotateSprites = () => {
  if (demo.value) {
    demo.value.clickButton('RotateButton')
    addLog('info', '测试旋转精灵功能')
  }
}

const testChangeColors = () => {
  if (demo.value) {
    demo.value.clickButton('ColorButton')
    addLog('info', '测试改变颜色功能')
  }
}

// 生命周期
onMounted(async () => {
  console.log('📱 2D节点演示页面已加载')

  // 添加一些示例日志
  addLog('info', '演示页面加载完成')
  addLog('info', '正在初始化2D节点演示系统...')

  // 初始化演示
  await initializeDemo()

  // 更新场景节点显示
  updateSceneNodes()

  // 添加一些测试按钮功能
  setTimeout(() => {
    if (demo.value) {
      addLog('info', '演示系统就绪，可以进行交互测试')
    }
  }, 1000)
})

onUnmounted(() => {
  console.log('📱 2D节点演示页面已卸载')

  // 清理演示系统
  if (demo.value) {
    demo.value.destroy()
    demo.value = null
  }
})
</script>

<style scoped>
.demo-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #1a1a1a;
  color: #ffffff;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.demo-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: #2d2d2d;
  border-bottom: 1px solid #404040;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.demo-title {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #ffffff;
}

.demo-controls {
  display: flex;
  align-items: center;
  gap: 12px;
}

.demo-selector {
  padding: 8px 12px;
  background: #404040;
  border: 1px solid #666666;
  border-radius: 4px;
  color: #ffffff;
  font-size: 14px;
  min-width: 200px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.btn-play {
  background: #28a745;
  color: white;
}

.btn-pause {
  background: #ffc107;
  color: #333;
}

.btn-reset {
  background: #6c757d;
  color: white;
}

.btn-primary {
  background: #007bff;
  color: white;
}

.btn-secondary {
  background: #6c757d;
  color: white;
}

.btn:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

.demo-main {
  display: flex;
  flex: 1;
  overflow: hidden;
}

.info-panel,
.tools-panel {
  width: 300px;
  background: #2d2d2d;
  border-right: 1px solid #404040;
  overflow-y: auto;
  padding: 16px;
}

.tools-panel {
  border-right: none;
  border-left: 1px solid #404040;
}

.canvas-container {
  flex: 1;
  position: relative;
  background: #1a1a1a;
  display: flex;
  align-items: center;
  justify-content: center;
}

.game-canvas {
  width: 800px;
  height: 600px;
  border: 2px solid #404040;
  border-radius: 8px;
  background: #000000;
}

.loading-overlay,
.error-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.8);
  color: white;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #404040;
  border-top: 4px solid #007bff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 16px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-content {
  text-align: center;
  padding: 24px;
  background: #2d2d2d;
  border-radius: 8px;
  border: 1px solid #dc3545;
}

.demo-info h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
  color: #ffffff;
}

.demo-description {
  margin: 0 0 16px 0;
  color: #cccccc;
  line-height: 1.5;
}

.stats-panel,
.controls-panel,
.editor-panel,
.node-tree,
.properties-panel,
.log-panel {
  margin-bottom: 24px;
  padding: 16px;
  background: #1a1a1a;
  border-radius: 8px;
  border: 1px solid #404040;
}

.stats-panel h4,
.controls-panel h4,
.editor-panel h4,
.node-tree h4,
.properties-panel h4,
.log-panel h4 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #ffffff;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.stat-label {
  color: #cccccc;
}

.stat-value {
  color: #ffffff;
  font-weight: 600;
}

.control-group {
  margin-bottom: 16px;
}

.control-group label {
  display: block;
  margin-bottom: 4px;
  color: #cccccc;
  font-size: 14px;
}

.control-group input[type="range"] {
  width: 100%;
  margin-bottom: 4px;
}

.control-group input[type="checkbox"] {
  margin-right: 8px;
}

.btn-full {
  width: 100%;
}

.tree-container {
  max-height: 200px;
  overflow-y: auto;
}

.tree-node {
  display: flex;
  align-items: center;
  padding: 4px 8px;
  margin-bottom: 2px;
  background: #404040;
  border-radius: 4px;
  cursor: pointer;
}

.tree-node:hover {
  background: #505050;
}

.node-icon {
  margin-right: 8px;
  font-size: 16px;
}

.node-name {
  flex: 1;
  font-weight: 500;
}

.node-type {
  font-size: 12px;
  color: #999999;
}

.property-list {
  max-height: 200px;
  overflow-y: auto;
}

.property-item {
  display: flex;
  justify-content: space-between;
  padding: 4px 0;
  border-bottom: 1px solid #404040;
}

.property-item label {
  color: #cccccc;
  font-size: 12px;
}

.no-selection {
  text-align: center;
  color: #999999;
  font-style: italic;
}

.log-container {
  max-height: 200px;
  overflow-y: auto;
  background: #000000;
  border: 1px solid #404040;
  border-radius: 4px;
  padding: 8px;
  margin-bottom: 8px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
}

.log-entry {
  margin-bottom: 4px;
  display: flex;
  gap: 8px;
}

.log-entry.info {
  color: #ffffff;
}

.log-entry.warn {
  color: #ffc107;
}

.log-entry.error {
  color: #dc3545;
}

.log-time {
  color: #666666;
  min-width: 80px;
}

.btn-small {
  padding: 4px 8px;
  font-size: 12px;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: #2d2d2d;
  border-radius: 8px;
  width: 90vw;
  height: 90vh;
  max-width: 1200px;
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid #404040;
}

.modal-header h3 {
  margin: 0;
  color: #ffffff;
}

.btn-close {
  background: none;
  border: none;
  color: #ffffff;
  font-size: 24px;
  cursor: pointer;
  padding: 0;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
}

.btn-close:hover {
  background: #404040;
}

.modal-body {
  flex: 1;
  overflow: hidden;
}
</style>
