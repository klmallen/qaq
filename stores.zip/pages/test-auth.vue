<!--
  QAQ游戏引擎 - 认证状态测试页面

  用于测试和调试用户认证状态
-->

<template>
  <div class="test-auth-page">
    <div class="container mx-auto p-6">
      <h1 class="text-3xl font-bold mb-6">认证状态测试</h1>

      <!-- 认证状态显示 -->
      <UCard class="mb-6">
        <template #header>
          <h2 class="text-xl font-semibold">当前认证状态</h2>
        </template>

        <div class="space-y-4">
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="text-sm font-medium text-gray-600">登录状态:</label>
              <UBadge
                :color="authStore.isAuthenticated ? 'green' : 'red'"
                variant="soft"
                class="ml-2"
              >
                {{ authStore.isAuthenticated ? '已登录' : '未登录' }}
              </UBadge>
            </div>

            <div>
              <label class="text-sm font-medium text-gray-600">Token状态:</label>
              <UBadge
                :color="authStore.token ? 'green' : 'red'"
                variant="soft"
                class="ml-2"
              >
                {{ authStore.token ? '存在' : '不存在' }}
              </UBadge>
            </div>

            <div>
              <label class="text-sm font-medium text-gray-600">用户信息:</label>
              <span class="ml-2 text-sm">
                {{ authStore.user ? authStore.user.email : '无' }}
              </span>
            </div>

            <div>
              <label class="text-sm font-medium text-gray-600">Token长度:</label>
              <span class="ml-2 text-sm">
                {{ authStore.token ? authStore.token.length : 0 }}
              </span>
            </div>
          </div>

          <div v-if="authStore.token" class="mt-4">
            <label class="text-sm font-medium text-gray-600">Token预览:</label>
            <div class="mt-1 p-2 bg-gray-100 rounded text-xs font-mono break-all">
              {{ authStore.token.substring(0, 100) }}...
            </div>
          </div>
        </div>
      </UCard>

      <!-- 测试按钮 -->
      <UCard class="mb-6">
        <template #header>
          <h2 class="text-xl font-semibold">API测试</h2>
        </template>

        <div class="space-y-4">
          <div class="flex gap-4 flex-wrap">
            <UButton
              @click="testTokenAPI"
              :loading="testing.token"
              color="purple"
              :disabled="!authStore.token"
            >
              测试Token
            </UButton>

            <UButton
              @click="testDebugAPI"
              :loading="testing.debug"
              color="blue"
              :disabled="!authStore.token"
            >
              测试调试API
            </UButton>

            <UButton
              @click="testCreateAPI"
              :loading="testing.create"
              color="green"
              :disabled="!authStore.token"
            >
              测试简化创建API
            </UButton>

            <UButton
              @click="testOriginalCreateAPI"
              :loading="testing.original"
              color="red"
              :disabled="!authStore.token"
            >
              测试原始创建API
            </UButton>

            <UButton
              @click="refreshAuth"
              :loading="testing.refresh"
              color="orange"
            >
              刷新认证状态
            </UButton>
          </div>
        </div>
      </UCard>

      <!-- 测试结果 -->
      <UCard v-if="testResults.length > 0">
        <template #header>
          <h2 class="text-xl font-semibold">测试结果</h2>
        </template>

        <div class="space-y-4">
          <div
            v-for="(result, index) in testResults"
            :key="index"
            class="p-4 border rounded"
            :class="{
              'border-green-200 bg-green-50': result.success,
              'border-red-200 bg-red-50': !result.success
            }"
          >
            <div class="flex items-center justify-between mb-2">
              <h3 class="font-semibold">{{ result.title }}</h3>
              <UBadge
                :color="result.success ? 'green' : 'red'"
                variant="soft"
              >
                {{ result.success ? '成功' : '失败' }}
              </UBadge>
            </div>

            <p class="text-sm text-gray-600 mb-2">{{ result.message }}</p>

            <div v-if="result.data" class="mt-2">
              <details>
                <summary class="cursor-pointer text-sm font-medium">详细数据</summary>
                <pre class="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">{{ JSON.stringify(result.data, null, 2) }}</pre>
              </details>
            </div>

            <div v-if="result.error" class="mt-2 text-red-600 text-sm">
              <strong>错误:</strong> {{ result.error }}
            </div>
          </div>
        </div>
      </UCard>

      <!-- 快速登录 -->
      <UCard v-if="!authStore.isAuthenticated">
        <template #header>
          <h2 class="text-xl font-semibold">快速登录</h2>
        </template>

        <div class="space-y-4">
          <p class="text-sm text-gray-600">
            如果您还没有登录，请先登录以测试项目创建功能。
          </p>

          <UButton
            @click="goToLogin"
            color="primary"
          >
            前往登录页面
          </UButton>
        </div>
      </UCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useAuthStore } from '~/stores/auth'
import { useNotification } from '~/composables/useNotification'
import { useAuthCheck } from '~/utils/auth/authUtils'
import { authenticatedRequest } from '~/utils/api/errorHandler'

// 页面元数据
definePageMeta({
  title: '认证状态测试'
})

// 状态管理
const authStore = useAuthStore()
const router = useRouter()

// 测试状态
const testing = reactive({
  token: false,
  debug: false,
  create: false,
  original: false,
  refresh: false
})

// 测试结果
const testResults = ref<Array<{
  title: string
  success: boolean
  message: string
  data?: any
  error?: string
}>>([])

// 添加测试结果
function addResult(title: string, success: boolean, message: string, data?: any, error?: string) {
  testResults.value.unshift({
    title,
    success,
    message,
    data,
    error
  })
}

// 测试Token有效性
async function testTokenAPI() {
  testing.token = true
  try {
    const response = await $fetch('/api/auth/test-token', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`,
        'Content-Type': 'application/json'
      }
    })

    addResult(
      'Token验证测试',
      response.success,
      response.message || 'Token验证完成',
      response.data || response.details,
      response.error
    )
  } catch (error: any) {
    addResult(
      'Token验证测试',
      false,
      'Token验证API调用失败',
      null,
      error.message
    )
  } finally {
    testing.token = false
  }
}

// 测试调试API
async function testDebugAPI() {
  testing.debug = true
  try {
    const response = await $fetch('/api/projects/debug', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`,
        'Content-Type': 'application/json'
      },
      body: {
        name: 'TestProject',
        location: '/tmp/test'
      }
    })

    addResult(
      '调试API测试',
      response.success,
      response.message || '调试API调用完成',
      response.debug,
      response.error
    )
  } catch (error: any) {
    addResult(
      '调试API测试',
      false,
      '调试API调用失败',
      null,
      error.message
    )
  } finally {
    testing.debug = false
  }
}

// 测试简化创建API
async function testCreateAPI() {
  testing.create = true
  try {
    const response = await $fetch('/api/projects/create-simple', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`,
        'Content-Type': 'application/json'
      },
      body: {
        name: 'TestProject_' + Date.now(),
        location: '/tmp/test',
        description: '测试项目（简化版）'
      }
    })

    addResult(
      '简化创建API测试',
      response.success,
      response.message || '简化项目创建API调用完成',
      response.data,
      response.error
    )
  } catch (error: any) {
    addResult(
      '简化创建API测试',
      false,
      '简化项目创建API调用失败',
      null,
      error.message
    )
  } finally {
    testing.create = false
  }
}

// 测试原始创建API
async function testOriginalCreateAPI() {
  testing.original = true
  try {
    const response = await $fetch('/api/projects/create', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`,
        'Content-Type': 'application/json'
      },
      body: {
        name: 'TestProject_Original_' + Date.now(),
        location: '/tmp/test',
        description: '测试项目（原始版）'
      }
    })

    addResult(
      '原始创建API测试',
      response.success,
      response.message || '原始项目创建API调用完成',
      response.data,
      response.error
    )
  } catch (error: any) {
    addResult(
      '原始创建API测试',
      false,
      '原始项目创建API调用失败',
      null,
      error.message
    )
  } finally {
    testing.original = false
  }
}

// 刷新认证状态
async function refreshAuth() {
  testing.refresh = true
  try {
    await authStore.autoLogin()

    addResult(
      '认证状态刷新',
      authStore.isAuthenticated,
      authStore.isAuthenticated ? '认证状态刷新成功' : '用户未登录',
      {
        isAuthenticated: authStore.isAuthenticated,
        hasToken: !!authStore.token,
        user: authStore.user
      }
    )
  } catch (error: any) {
    addResult(
      '认证状态刷新',
      false,
      '认证状态刷新失败',
      null,
      error.message
    )
  } finally {
    testing.refresh = false
  }
}

// 前往登录页面
function goToLogin() {
  router.push('/auth/login')
}
</script>

<style scoped>
.test-auth-page {
  min-height: 100vh;
  background-color: #f9fafb;
}
</style>
