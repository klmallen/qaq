<template>
  <div class="camera-demo-page">
    <!-- 头部 -->
    <div class="demo-header">
      <h1>QAQ游戏引擎 - 2D相机和节点通信演示</h1>
      <div class="demo-controls">
        <button @click="togglePlay" class="btn" :class="isPlaying ? 'btn-pause' : 'btn-play'">
          {{ isPlaying ? '⏸️ 暂停' : '▶️ 播放' }}
        </button>
        <button @click="resetDemo" class="btn btn-reset">🔄 重置</button>
      </div>
    </div>

    <!-- 主要内容 -->
    <div class="demo-content">
      <!-- 左侧信息面板 -->
      <div class="info-panel">
        <div class="demo-info">
          <h3>演示功能</h3>
          <ul>
            <li>✅ 2D正交相机</li>
            <li>✅ 相机跟随目标</li>
            <li>✅ 相机缩放控制</li>
            <li>✅ 按钮节点交互</li>
            <li>✅ 节点间消息通信</li>
          </ul>
        </div>

        <!-- 统计信息 -->
        <div class="stats-panel">
          <h4>性能统计</h4>
          <div class="stat-item">
            <span>FPS:</span>
            <span>{{ stats.fps }}</span>
          </div>
          <div class="stat-item">
            <span>节点数:</span>
            <span>{{ stats.nodeCount }}</span>
          </div>
          <div class="stat-item">
            <span>渲染时间:</span>
            <span>{{ stats.renderTime.toFixed(2) }}ms</span>
          </div>
        </div>

        <!-- 控制面板 -->
        <div class="controls-panel">
          <h4>演示控制</h4>
          
          <div class="control-group">
            <button @click="testZoomCamera" class="btn btn-primary">
              🔍 测试相机缩放
            </button>
          </div>
          
          <div class="control-group">
            <button @click="testMoveTarget" class="btn btn-secondary">
              🎯 测试移动目标
            </button>
          </div>
          
          <div class="control-group">
            <button @click="testNodeCommunication" class="btn btn-success">
              📡 测试节点通信
            </button>
          </div>
        </div>
      </div>

      <!-- 中央画布区域 -->
      <div class="canvas-container">
        <div id="camera-demo-canvas" class="demo-canvas"></div>
        
        <!-- 加载指示器 -->
        <div v-if="isLoading" class="loading-overlay">
          <div class="loading-spinner"></div>
          <p>正在加载演示...</p>
        </div>

        <!-- 错误提示 -->
        <div v-if="error" class="error-overlay">
          <div class="error-content">
            <h3>❌ 演示加载失败</h3>
            <p>{{ error }}</p>
            <button @click="retryDemo" class="btn btn-primary">重试</button>
          </div>
        </div>
      </div>

      <!-- 右侧说明面板 -->
      <div class="info-panel">
        <div class="instructions">
          <h4>操作说明</h4>
          <div class="instruction-item">
            <strong>橙色方块</strong>: 相机跟随的目标精灵
          </div>
          <div class="instruction-item">
            <strong>蓝色按钮</strong>: 点击缩放相机 (0.5x → 1x → 1.5x → 2x)
          </div>
          <div class="instruction-item">
            <strong>绿色按钮</strong>: 点击随机移动目标，相机会平滑跟随
          </div>
          <div class="instruction-item">
            <strong>节点通信</strong>: 按钮点击时会发送消息给其他节点
          </div>
        </div>

        <!-- 消息日志 -->
        <div class="message-log">
          <h4>节点通信日志</h4>
          <div class="log-container" ref="logContainer">
            <div
              v-for="(log, index) in logs"
              :key="index"
              class="log-entry"
              :class="log.level"
            >
              <span class="log-time">{{ log.time }}</span>
              <span class="log-message">{{ log.message }}</span>
            </div>
          </div>
          <button @click="clearLogs" class="btn btn-small">清除日志</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted, nextTick } from 'vue'
import { Simple2DCameraDemo } from '~/demos/simple-2d-camera-demo'

// 响应式数据
const demo = ref<Simple2DCameraDemo | null>(null)
const isLoading = ref(true)
const error = ref<string>('')
const isPlaying = ref(false)

const stats = reactive({
  fps: 0,
  nodeCount: 0,
  renderTime: 0
})

const logs = ref<Array<{ time: string; level: string; message: string }>>([])
const logContainer = ref<HTMLDivElement>()

// 方法
const addLog = (level: string, message: string) => {
  const now = new Date()
  const time = now.toLocaleTimeString()
  logs.value.push({ time, level, message })
  
  if (logs.value.length > 100) {
    logs.value.shift()
  }
  
  nextTick(() => {
    if (logContainer.value) {
      logContainer.value.scrollTop = logContainer.value.scrollHeight
    }
  })
}

const initializeDemo = async () => {
  try {
    isLoading.value = true
    error.value = ''
    
    addLog('info', '开始初始化2D相机演示系统...')
    
    // 创建演示实例
    demo.value = new Simple2DCameraDemo()
    
    // 初始化演示系统
    const success = await demo.value.initialize('camera-demo-canvas', 800, 600)
    
    if (!success) {
      throw new Error('演示系统初始化失败')
    }
    
    // 启动演示
    demo.value.start()
    isPlaying.value = true
    
    // 启动统计更新
    startStatsUpdate()
    
    addLog('success', '2D相机演示系统初始化完成！')
    
  } catch (err) {
    error.value = err instanceof Error ? err.message : '未知错误'
    addLog('error', `初始化失败: ${error.value}`)
  } finally {
    isLoading.value = false
  }
}

const togglePlay = () => {
  if (!demo.value) return
  
  if (isPlaying.value) {
    demo.value.stop()
    isPlaying.value = false
    addLog('info', '演示已暂停')
  } else {
    demo.value.start()
    isPlaying.value = true
    addLog('info', '演示已开始')
  }
}

const resetDemo = async () => {
  addLog('info', '重置演示系统...')
  if (demo.value) {
    demo.value.destroy()
  }
  await initializeDemo()
}

const retryDemo = async () => {
  error.value = ''
  await initializeDemo()
}

const testZoomCamera = () => {
  if (demo.value) {
    demo.value.clickButton('ZoomButton')
    addLog('info', '执行相机缩放测试')
  }
}

const testMoveTarget = () => {
  if (demo.value) {
    demo.value.clickButton('MoveButton')
    addLog('info', '执行目标移动测试')
  }
}

const testNodeCommunication = () => {
  addLog('info', '测试节点通信功能')
  addLog('info', '→ 点击按钮会发送消息给其他节点')
  addLog('info', '→ 查看浏览器控制台可看到详细通信日志')
  
  // 连续测试两个按钮
  setTimeout(() => testZoomCamera(), 500)
  setTimeout(() => testMoveTarget(), 1000)
}

const startStatsUpdate = () => {
  const updateStats = () => {
    if (demo.value && isPlaying.value) {
      const demoStats = demo.value.getStats()
      stats.fps = demoStats.fps
      stats.nodeCount = demoStats.nodeCount
      stats.renderTime = demoStats.renderTime
      
      // 继续更新
      setTimeout(updateStats, 100)
    }
  }
  updateStats()
}

const clearLogs = () => {
  logs.value = []
}

// 生命周期
onMounted(async () => {
  addLog('info', '页面加载完成')
  await initializeDemo()
})

onUnmounted(() => {
  if (demo.value) {
    demo.value.destroy()
    demo.value = null
  }
  addLog('info', '页面已卸载')
})
</script>

<style scoped>
.camera-demo-page {
  min-height: 100vh;
  background: #1a1a1a;
  color: #ffffff;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.demo-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background: #2d2d2d;
  border-bottom: 1px solid #404040;
}

.demo-header h1 {
  margin: 0;
  font-size: 24px;
  color: #ffffff;
}

.demo-controls {
  display: flex;
  gap: 10px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.btn-play { background: #28a745; color: white; }
.btn-pause { background: #ffc107; color: #333; }
.btn-reset { background: #6c757d; color: white; }
.btn-primary { background: #007bff; color: white; }
.btn-secondary { background: #6c757d; color: white; }
.btn-success { background: #28a745; color: white; }
.btn-small { padding: 4px 8px; font-size: 12px; }

.btn:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

.demo-content {
  display: flex;
  height: calc(100vh - 80px);
}

.info-panel {
  width: 300px;
  background: #2d2d2d;
  padding: 20px;
  overflow-y: auto;
}

.canvas-container {
  flex: 1;
  position: relative;
  background: #000000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.demo-canvas {
  width: 800px;
  height: 600px;
  border: 2px solid #404040;
  border-radius: 8px;
}

.loading-overlay,
.error-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.8);
  color: white;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #404040;
  border-top: 4px solid #007bff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 16px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-content {
  text-align: center;
  padding: 24px;
  background: #2d2d2d;
  border-radius: 8px;
  border: 1px solid #dc3545;
}

.demo-info h3,
.stats-panel h4,
.controls-panel h4,
.instructions h4,
.message-log h4 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #ffffff;
}

.demo-info ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.demo-info li {
  padding: 4px 0;
  color: #cccccc;
}

.stats-panel,
.controls-panel,
.instructions,
.message-log {
  margin-bottom: 24px;
  padding: 16px;
  background: #1a1a1a;
  border-radius: 8px;
  border: 1px solid #404040;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  color: #cccccc;
}

.control-group {
  margin-bottom: 12px;
}

.control-group .btn {
  width: 100%;
}

.instruction-item {
  margin-bottom: 12px;
  padding: 8px;
  background: #404040;
  border-radius: 4px;
  font-size: 14px;
  line-height: 1.4;
}

.log-container {
  max-height: 200px;
  overflow-y: auto;
  background: #000000;
  border: 1px solid #404040;
  border-radius: 4px;
  padding: 8px;
  margin-bottom: 8px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
}

.log-entry {
  margin-bottom: 4px;
  display: flex;
  gap: 8px;
}

.log-entry.info { color: #ffffff; }
.log-entry.success { color: #28a745; }
.log-entry.error { color: #dc3545; }

.log-time {
  color: #666666;
  min-width: 80px;
}
</style>
