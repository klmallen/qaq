<template>
  <div class="test-page">
    <h1>QAQ游戏引擎 - 2D节点测试页面</h1>
    
    <div class="test-content">
      <h2>✅ 系统状态检查</h2>
      
      <div class="status-grid">
        <div class="status-item">
          <h3>🎮 引擎核心</h3>
          <p class="status-ok">正常运行</p>
        </div>
        
        <div class="status-item">
          <h3>🖼️ 2D节点系统</h3>
          <p class="status-ok">已实现</p>
        </div>
        
        <div class="status-item">
          <h3>🎞️ 动画系统</h3>
          <p class="status-ok">已实现</p>
        </div>
        
        <div class="status-item">
          <h3>🎨 精灵表编辑器</h3>
          <p class="status-ok">已实现</p>
        </div>
      </div>
      
      <h2>📋 已实现的2D节点</h2>
      
      <div class="nodes-grid">
        <div class="node-card">
          <div class="node-icon">🖼️</div>
          <h3>Sprite2D</h3>
          <p>基础精灵显示节点，支持纹理加载、缩放、旋转、翻转</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">🎞️</div>
          <h3>AnimatedSprite2D</h3>
          <p>帧动画精灵节点，支持多动画序列、播放控制</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">🎬</div>
          <h3>SpriteSheetAnimator2D</h3>
          <p>精灵表动画节点，支持自动解析、动画混合</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">📝</div>
          <h3>Label</h3>
          <p>文本标签节点，支持多种字体、样式、对齐方式</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">🔘</div>
          <h3>Button</h3>
          <p>交互按钮节点，支持多种状态、样式、事件</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">📋</div>
          <h3>Panel</h3>
          <p>UI容器面板，支持背景、边框、渐变、阴影</p>
        </div>
        
        <div class="node-card">
          <div class="node-icon">🖼️</div>
          <h3>TextureRect</h3>
          <p>纹理显示控件，支持多种拉伸模式、过滤</p>
        </div>
      </div>
      
      <h2>🚀 功能特性</h2>
      
      <div class="features-list">
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>完整的Node -> Node2D -> SpecificNode2D架构</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>TypeScript类型安全和import type语法</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>Three.js渲染管道集成</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>精灵表动画系统</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>Vue.js编辑器组件</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>交互式演示系统</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>性能优化和内存管理</span>
        </div>
        <div class="feature-item">
          <span class="feature-icon">✅</span>
          <span>3D光照兼容性分析</span>
        </div>
      </div>
      
      <div class="action-buttons">
        <NuxtLink to="/demo-2d-nodes" class="btn btn-primary">
          🎮 查看2D节点演示
        </NuxtLink>
        <button @click="openSpriteSheetEditor" class="btn btn-secondary">
          🎨 打开精灵表编辑器
        </button>
      </div>
    </div>
    
    <!-- 精灵表编辑器模态框 -->
    <div v-if="showEditor" class="modal-overlay" @click="closeEditor">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>精灵表动画编辑器</h3>
          <button @click="closeEditor" class="btn-close">×</button>
        </div>
        <div class="modal-body">
          <SpriteSheetEditor @close="closeEditor" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import SpriteSheetEditor from '~/components/editor/SpriteSheetEditor.vue'

const showEditor = ref(false)

const openSpriteSheetEditor = () => {
  showEditor.value = true
}

const closeEditor = () => {
  showEditor.value = false
}
</script>

<style scoped>
.test-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  color: #ffffff;
  padding: 40px 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.test-page h1 {
  text-align: center;
  font-size: 3rem;
  margin-bottom: 2rem;
  background: linear-gradient(45deg, #007bff, #28a745);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.test-content {
  max-width: 1200px;
  margin: 0 auto;
}

.test-content h2 {
  font-size: 2rem;
  margin: 3rem 0 1.5rem 0;
  color: #ffffff;
}

.status-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 3rem;
}

.status-item {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #404040;
  border-radius: 12px;
  padding: 1.5rem;
  text-align: center;
  transition: transform 0.2s ease;
}

.status-item:hover {
  transform: translateY(-4px);
  border-color: #007bff;
}

.status-item h3 {
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
}

.status-ok {
  color: #28a745;
  font-weight: 600;
  font-size: 1.1rem;
}

.nodes-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 3rem;
}

.node-card {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #404040;
  border-radius: 12px;
  padding: 1.5rem;
  transition: all 0.2s ease;
}

.node-card:hover {
  transform: translateY(-4px);
  border-color: #007bff;
  box-shadow: 0 8px 25px rgba(0, 123, 255, 0.15);
}

.node-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
  text-align: center;
}

.node-card h3 {
  font-size: 1.3rem;
  margin-bottom: 0.5rem;
  color: #007bff;
}

.node-card p {
  color: #cccccc;
  line-height: 1.5;
}

.features-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 1rem;
  margin-bottom: 3rem;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  border: 1px solid #404040;
}

.feature-icon {
  font-size: 1.2rem;
  color: #28a745;
}

.action-buttons {
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  margin-top: 3rem;
}

.btn {
  padding: 1rem 2rem;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-primary {
  background: linear-gradient(45deg, #007bff, #0056b3);
  color: white;
}

.btn-secondary {
  background: linear-gradient(45deg, #6c757d, #495057);
  color: white;
}

.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: #2d2d2d;
  border-radius: 12px;
  width: 90vw;
  height: 90vh;
  max-width: 1200px;
  display: flex;
  flex-direction: column;
  border: 1px solid #404040;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #404040;
}

.modal-header h3 {
  margin: 0;
  color: #ffffff;
  font-size: 1.5rem;
}

.btn-close {
  background: none;
  border: none;
  color: #ffffff;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 4px;
  transition: background 0.2s ease;
}

.btn-close:hover {
  background: #404040;
}

.modal-body {
  flex: 1;
  overflow: hidden;
}
</style>
