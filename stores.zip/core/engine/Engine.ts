/**
 * QAQ游戏引擎 - Engine 核心引擎类
 *
 * 作者: QAQ游戏引擎开发团队
 * 创建时间: 2024年
 *
 * 功能说明:
 * - 引擎的核心管理类，统一管理Three.js渲染管道
 * - 负责初始化和管理Renderer、Scene、Camera等核心对象
 * - 提供统一的2D/3D渲染架构
 * - 管理场景树与Three.js场景图的同步
 * - 处理引擎生命周期和渲染循环
 *
 * 架构设计:
 * - 所有QAQ节点都对应Three.js Object3D实例
 * - 2D节点通过Plane几何体在3D空间中渲染
 * - 统一的变换同步机制
 * - 集成的事件处理系统
 */

import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import Scene from '../scene/Scene'
import type { SceneChangeOptions } from '../scene/types'
import type { Vector2, Vector3 } from '../../types/core'

// 使用类型导入避免循环依赖
type SceneTree = any

// ============================================================================
// 引擎相关接口和枚举
// ============================================================================

/**
 * 引擎配置接口
 */
export interface EngineConfig {
  /** 画布容器元素 */
  container: HTMLElement
  /** 初始画布宽度 */
  width?: number
  /** 初始画布高度 */
  height?: number
  /** 是否启用抗锯齿 */
  antialias?: boolean
  /** 背景颜色 */
  backgroundColor?: number
  /** 是否启用阴影 */
  enableShadows?: boolean
  /** 像素比 */
  pixelRatio?: number
  /** 是否启用VR */
  enableVR?: boolean
  /** 调试模式 */
  debug?: boolean
}

/**
 * 渲染统计信息接口
 */
export interface RenderStats {
  /** 帧率 */
  fps: number
  /** 渲染调用次数 */
  drawCalls: number
  /** 三角形数量 */
  triangles: number
  /** 几何体数量 */
  geometries: number
  /** 纹理数量 */
  textures: number
  /** 内存使用量 */
  memory: {
    geometries: number
    textures: number
  }
}

/**
 * 引擎状态枚举
 */
export enum EngineState {
  /** 未初始化 */
  UNINITIALIZED = 0,
  /** 初始化中 */
  INITIALIZING = 1,
  /** 运行中 */
  RUNNING = 2,
  /** 暂停 */
  PAUSED = 3,
  /** 已销毁 */
  DESTROYED = 4
}

// ============================================================================
// Engine 核心类实现
// ============================================================================

/**
 * Engine 类 - QAQ游戏引擎核心
 *
 * 主要功能:
 * 1. Three.js渲染器管理
 * 2. 场景和相机管理
 * 3. 渲染循环控制
 * 4. 节点系统与Three.js集成
 * 5. 事件处理和输入管理
 * 6. 资源管理和优化
 */
export class Engine {
  // ========================================================================
  // 私有属性 - Three.js核心对象
  // ========================================================================

  /** Three.js渲染器 */
  private _renderer: THREE.WebGLRenderer | null = null

  /** 主场景 */
  private _scene: THREE.Scene | null = null

  /** 当前活动相机 */
  private _activeCamera: THREE.Camera | null = null

  /** 2D正交相机 */
  private _camera2D: THREE.OrthographicCamera | null = null

  /** 3D透视相机 */
  private _camera3D: THREE.PerspectiveCamera | null = null

  /** 画布元素 */
  private _canvas: HTMLCanvasElement | null = null

  /** 容器元素 */
  private _container: HTMLElement | null = null

  // ========================================================================
  // 私有属性 - 引擎状态管理
  // ========================================================================

  /** 引擎状态 */
  private _state: EngineState = EngineState.UNINITIALIZED

  /** 引擎配置 */
  private _config: EngineConfig | null = null

  /** 是否正在渲染 */
  private _isRendering: boolean = false

  /** 渲染循环ID */
  private _renderLoopId: number | null = null

  /** 上一帧时间 */
  private _lastFrameTime: number = 0

  /** 帧率计算 */
  private _frameCount: number = 0
  private _fpsUpdateTime: number = 0
  private _currentFPS: number = 0

  // ========================================================================
  // 私有属性 - 2D/3D渲染层管理
  // ========================================================================

  /** 2D渲染层 - 用于UI和2D游戏对象 */
  private _layer2D: THREE.Group | null = null

  /** 3D渲染层 - 用于3D游戏对象 */
  private _layer3D: THREE.Group | null = null

  /** UI层 - 最顶层的UI元素 */
  private _layerUI: THREE.Group | null = null

  /** 当前渲染模式 (2D/3D/混合) */
  private _renderMode: '2D' | '3D' | 'MIXED' = 'MIXED'

  // ========================================================================
  // 私有属性 - 事件和输入
  // ========================================================================

  /** 鼠标射线投射器 */
  private _raycaster: THREE.Raycaster | null = null

  /** 鼠标位置 */
  private _mousePosition: THREE.Vector2 = new THREE.Vector2(0, 0)

  /** 事件监听器映射 */
  private _eventListeners: Map<string, Function[]> = new Map()

  // ========================================================================
  // 私有属性 - 调试和测试
  // ========================================================================

  /** 测试立方体 - 用于验证渲染管道 */
  private _testCube: THREE.Mesh | null = null

  /** 轨道控制器 - 用于3D场景交互 */
  private _orbitControls: OrbitControls | null = null

  /** 测试立方体动画ID */
  private _testCubeAnimationId: number | null = null

  // ========================================================================
  // 私有属性 - 场景管理系统
  // ========================================================================

  /** 场景树管理器 */
  private _sceneTree: any = null

  /** 当前QAQ场景 */
  private _currentQAQScene: Scene | null = null

  /** 根节点 - 连接QAQ场景树和Three.js场景图 */
  private _rootNode: THREE.Group | null = null

  // ========================================================================
  // 静态属性 - 单例管理
  // ========================================================================

  /** 引擎单例实例 */
  private static _instance: Engine | null = null

  // ========================================================================
  // 构造函数和初始化
  // ========================================================================

  /**
   * 私有构造函数 - 单例模式
   */
  private constructor() {
    // 私有构造函数，防止直接实例化
  }

  /**
   * 获取引擎单例实例
   * @returns 引擎实例
   */
  static getInstance(): Engine {
    if (!Engine._instance) {
      Engine._instance = new Engine()
    }
    return Engine._instance
  }

  /**
   * 初始化引擎
   * @param config 引擎配置
   * @returns Promise<boolean> 初始化是否成功
   */
  async initialize(config: EngineConfig): Promise<boolean> {
    if (this._state !== EngineState.UNINITIALIZED) {
      console.warn('Engine is already initialized')
      return false
    }

    this._state = EngineState.INITIALIZING
    this._config = { ...config }

    try {
      // 初始化Three.js渲染器
      await this._initializeRenderer()

      // 初始化场景
      this._initializeScene()

      // 初始化相机
      this._initializeCameras()

      // 初始化渲染层
      this._initializeRenderLayers()

      // 初始化场景管理系统
      await this._initializeSceneSystem()

      // 初始化事件系统
      this._initializeEventSystem()

      // 设置渲染循环
      this._setupRenderLoop()

      this._state = EngineState.RUNNING

      console.log('🚀 QAQ Game Engine initialized successfully')
      this._emitEvent('engine_initialized')

      return true

    } catch (error) {
      console.error('❌ Failed to initialize QAQ Game Engine:', error)
      this._state = EngineState.UNINITIALIZED
      return false
    }
  }

  /**
   * 初始化Three.js渲染器
   */
  private async _initializeRenderer(): Promise<void> {
    const config = this._config!

    // 创建渲染器
    this._renderer = new THREE.WebGLRenderer({
      antialias: config.antialias ?? true,
      alpha: true,
      powerPreference: 'high-performance'
    })

    // 设置渲染器参数
    const width = config.width ?? config.container.clientWidth
    const height = config.height ?? config.container.clientHeight

    this._renderer.setSize(width, height)
    this._renderer.setPixelRatio(config.pixelRatio ?? window.devicePixelRatio)
    this._renderer.setClearColor(config.backgroundColor ?? new THREE.Color(0x222222), 1)
    // 启用阴影
    // if (config.enableShadows) {
    //   this._renderer.shadowMap.enabled = true
    //   this._renderer.shadowMap.type = THREE.PCFSoftShadowMap
    // }
	//
    // // 启用色调映射
    // this._renderer.toneMapping = THREE.ACESFilmicToneMapping
    // this._renderer.toneMappingExposure = 1

    // 获取画布并添加到容器
    this._canvas = this._renderer.domElement
    this._container = config.container
    this._container.appendChild(this._canvas)

    console.log('✅ Three.js Renderer initialized')

    // 创建测试立方体和轨道控制器
    this._createTestObjects()
  }

  /**
   * 初始化场景
   */
  private _initializeScene(): void {
    this._scene = new THREE.Scene()

    // // 设置场景背景
    // if (this._config?.backgroundColor !== undefined) {
    //   this._scene.background = new THREE.Color(this._config.backgroundColor)
    // }
	//
    // // 添加环境光
    // const ambientLight = new THREE.AmbientLight(0x404040, 0.4)
    // this._scene.add(ambientLight)
	//
    // // 添加方向光
    // const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    // directionalLight.position.set(1, 1, 1)
    // directionalLight.castShadow = true
    // this._scene.add(directionalLight)

    console.log('✅ Scene initialized')
  }

  /**
   * 初始化相机
   */
  private _initializeCameras(): void {
    const width = this._config!.width ?? this._container!.clientWidth
    const height = this._config!.height ?? this._container!.clientHeight
    const aspect = width / height

    // 创建3D透视相机
    this._camera3D = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000)
    this._camera3D.position.set(0, 0, 5)

    // 创建2D正交相机
    const frustumSize = height
    this._camera2D = new THREE.OrthographicCamera(
      -frustumSize * aspect / 2, frustumSize * aspect / 2,
      frustumSize / 2, -frustumSize / 2,
      -1000, 1000
    )
    this._camera2D.position.set(0, 0, 500) // 位置在2D层前面

    // 默认使用混合模式的3D相机
    this._activeCamera = this._camera3D

    console.log('✅ Cameras initialized')

  }

  /**
   * 初始化渲染层
   */
  private _initializeRenderLayers(): void {
    // 创建3D渲染层
    this._layer3D = new THREE.Group()
    this._layer3D.name = 'Layer3D'
    this._scene!.add(this._layer3D)

    // 创建2D渲染层
    this._layer2D = new THREE.Group()
    this._layer2D.name = 'Layer2D'
    this._layer2D.position.z = 0 // 2D层在世界原点
    this._scene!.add(this._layer2D)

    // 创建UI层
    this._layerUI = new THREE.Group()
    this._layerUI.name = 'LayerUI'
    this._layerUI.position.z = 200 // UI层在最前面
    this._scene!.add(this._layerUI)

    console.log('✅ Render layers initialized')
  }

  /**
   * 初始化场景管理系统
   */
  private async _initializeSceneSystem(): Promise<void> {
    // 动态导入SceneTree避免循环依赖
    const { default: SceneTree } = await import('../scene/SceneTree')

    // 获取SceneTree单例并初始化
    this._sceneTree = SceneTree.getInstance()
    this._sceneTree.initialize(this)

    // 创建根节点用于连接QAQ场景树和Three.js场景图
    this._rootNode = new THREE.Group()
    this._rootNode.name = 'QAQSceneRoot'
    this._layer3D!.add(this._rootNode)

    console.log('✅ Scene management system initialized')
  }

  /**
   * 初始化事件系统
   */
  private _initializeEventSystem(): void {
    this._raycaster = new THREE.Raycaster()

    // 添加鼠标事件监听
    this._canvas!.addEventListener('mousemove', this._onMouseMove.bind(this))
    this._canvas!.addEventListener('mousedown', this._onMouseDown.bind(this))
    this._canvas!.addEventListener('mouseup', this._onMouseUp.bind(this))
    this._canvas!.addEventListener('click', this._onClick.bind(this))

    // 添加窗口尺寸变化监听
    window.addEventListener('resize', this._onWindowResize.bind(this))

    console.log('✅ Event system initialized')
  }

  /**
   * 设置渲染循环
   */
  private _setupRenderLoop(): void {
    this._lastFrameTime = performance.now()
    this._fpsUpdateTime = this._lastFrameTime
    this._startRenderLoop()

    console.log('✅ Render loop started')
  }

  // ========================================================================
  // 公共API - 场景管理
  // ========================================================================

  /**
   * 获取Three.js场景对象
   * @returns Three.js场景
   */
  getScene(): THREE.Scene | null {
    return this._scene
  }

  /**
   * 获取Three.js渲染器
   * @returns Three.js渲染器
   */
  getRenderer(): THREE.WebGLRenderer | null {
    return this._renderer
  }

  /**
   * 获取当前活动相机
   * @returns 当前相机
   */
  getActiveCamera(): THREE.Camera | null {
    return this._activeCamera
  }

  /**
   * 获取2D相机
   * @returns 2D正交相机
   */
  getCamera2D(): THREE.OrthographicCamera | null {
    return this._camera2D
  }

  /**
   * 获取3D相机
   * @returns 3D透视相机
   */
  getCamera3D(): THREE.PerspectiveCamera | null {
    return this._camera3D
  }

  /**
   * 切换到2D渲染模式
   */
  switchTo2D(): void {
    this._renderMode = '2D'
    this._activeCamera = this._camera2D
    this._emitEvent('render_mode_changed', { mode: '2D' })
  }

  /**
   * 切换到3D渲染模式
   */
  switchTo3D(): void {
    this._renderMode = '3D'
    this._activeCamera = this._camera3D
    this._emitEvent('render_mode_changed', { mode: '3D' })
  }

  /**
   * 切换到混合渲染模式
   */
  switchToMixed(): void {
    this._renderMode = 'MIXED'
    this._activeCamera = this._camera3D // 混合模式使用3D相机
    this._emitEvent('render_mode_changed', { mode: 'MIXED' })
  }

  /**
   * 获取指定层的Three.js Group对象
   * @param layer 层名称
   * @returns Three.js Group对象
   */
  getLayer(layer: '2D' | '3D' | 'UI'): THREE.Group | null {
    switch (layer) {
      case '2D': return this._layer2D
      case '3D': return this._layer3D
      case 'UI': return this._layerUI
      default: return null
    }
  }

  /**
   * 添加Three.js对象到指定层
   * @param object Three.js对象
   * @param layer 目标层
   */
  addToLayer(object: THREE.Object3D, layer: '2D' | '3D' | 'UI' = '3D'): void {
    const targetLayer = this.getLayer(layer)
    if (targetLayer) {
      targetLayer.add(object)
    }
  }

  /**
   * 从指定层移除Three.js对象
   * @param object Three.js对象
   * @param layer 源层
   */
  removeFromLayer(object: THREE.Object3D, layer: '2D' | '3D' | 'UI' = '3D'): void {
    const sourceLayer = this.getLayer(layer)
    if (sourceLayer) {
      sourceLayer.remove(object)
    }
  }

  // ========================================================================
  // 公共API - 渲染控制
  // ========================================================================

  /**
   * 开始渲染循环
   */
  startRendering(): void {
    if (this._state === EngineState.RUNNING && !this._isRendering) {
      this._startRenderLoop()
    }
  }

  /**
   * 停止渲染循环
   */
  stopRendering(): void {
    if (this._renderLoopId !== null) {
      cancelAnimationFrame(this._renderLoopId)
      this._renderLoopId = null
      this._isRendering = false
    }
  }

  /**
   * 暂停引擎
   */
  pause(): void {
    if (this._state === EngineState.RUNNING) {
      this.stopRendering()
      this._state = EngineState.PAUSED
      this._emitEvent('engine_paused')
    }
  }

  /**
   * 恢复引擎
   */
  resume(): void {
    if (this._state === EngineState.PAUSED) {
      this._state = EngineState.RUNNING
      this.startRendering()
      this._emitEvent('engine_resumed')
    }
  }

  /**
   * 手动渲染一帧
   */
  renderFrame(): void {
    if (this._renderer && this._scene && this._activeCamera) {
      // 更新当前场景（如果有）
      if (this._currentQAQScene && this._currentQAQScene.isRunning()) {
        this._currentQAQScene._process(0.016) // 假设60FPS，每帧约16ms
      }
		console.log(this._scene)
      this._renderer.render(this._scene, this._activeCamera)
    }
  }

  // ========================================================================
  // 公共API - 场景管理
  // ========================================================================

  /**
   * 设置主场景
   * @param scene 主场景实例
   */
  async setMainScene(scene: Scene): Promise<void> {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }

    await this._sceneTree.setMainScene(scene)
    this._currentQAQScene = scene

    // 将场景的Three.js对象添加到根节点
    if (this._rootNode && scene.object3D) {
      this._rootNode.add(scene.object3D)
    }

    console.log(`🎬 Main scene set: ${scene.name}`)
  }

  /**
   * 切换场景
   * @param scenePath 场景路径或Scene实例
   * @param options 切换选项
   * @returns 切换后的场景
   */
  async changeScene(
    scenePath: string | Scene,
    options?: SceneChangeOptions
  ): Promise<Scene> {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }

    // 移除当前场景的Three.js对象
    if (this._currentQAQScene && this._rootNode) {
      this._rootNode.remove(this._currentQAQScene.object3D)
    }

    // 切换场景
    const newScene = await this._sceneTree.changeScene(scenePath, options)
    this._currentQAQScene = newScene

    // 添加新场景的Three.js对象
    if (this._rootNode && newScene.object3D) {
      this._rootNode.add(newScene.object3D)
    }

    console.log(`🔄 Scene changed to: ${newScene.name}`)
    return newScene
  }

  /**
   * 获取当前场景
   * @returns 当前场景
   */
  getCurrentScene(): Scene | null {
    return this._currentQAQScene
  }

  /**
   * 获取场景树管理器
   * @returns SceneTree实例
   */
  getSceneTree(): SceneTree {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }
    return this._sceneTree
  }

  /**
   * 预加载场景
   * @param scenePath 场景路径
   * @returns 预加载的场景
   */
  async preloadScene(scenePath: string): Promise<Scene> {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }
    return await this._sceneTree.preloadScene(scenePath)
  }

  /**
   * 批量预加载场景
   * @param scenePaths 场景路径数组
   * @param onProgress 进度回调
   * @returns 预加载的场景数组
   */
  async preloadScenes(
    scenePaths: string[],
    onProgress?: (completed: number, total: number) => void
  ): Promise<Scene[]> {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }
    return await this._sceneTree.preloadScenes(scenePaths, onProgress)
  }

  /**
   * 返回到上一个场景
   * @param options 切换选项
   * @returns 返回的场景
   */
  async goBackScene(options?: SceneChangeOptions): Promise<Scene | null> {
    if (!this._sceneTree) {
      throw new Error('Scene system not initialized')
    }

    const previousScene = await this._sceneTree.goBack(options)

    if (previousScene) {
      // 更新当前场景引用
      if (this._currentQAQScene && this._rootNode) {
        this._rootNode.remove(this._currentQAQScene.object3D)
      }

      this._currentQAQScene = previousScene

      if (this._rootNode && previousScene.object3D) {
        this._rootNode.add(previousScene.object3D)
      }
    }

    return previousScene
  }

  // ========================================================================
  // 私有方法 - 渲染循环
  // ========================================================================

  /**
   * 启动渲染循环
   */
  private _startRenderLoop(): void {
    if (this._isRendering) return

    this._isRendering = true
    this._renderLoop()
  }

  /**
   * 渲染循环主函数
   */
  private _renderLoop = (): void => {
    if (!this._isRendering) return

    const currentTime = performance.now()
    const deltaTime = (currentTime - this._lastFrameTime) / 1000
    this._lastFrameTime = currentTime

    // 更新FPS计算
    this._updateFPS(currentTime)

    // 发送帧更新事件
    this._emitEvent('frame_update', { deltaTime, currentTime })

    // 执行渲染
    this.renderFrame()
    // 请求下一帧
    this._renderLoopId = requestAnimationFrame(this._renderLoop)
  }

  /**
   * 更新FPS计算
   */
  private _updateFPS(currentTime: number): void {
    this._frameCount++

    if (currentTime - this._fpsUpdateTime >= 1000) {
      this._currentFPS = this._frameCount
      this._frameCount = 0
      this._fpsUpdateTime = currentTime

      this._emitEvent('fps_updated', { fps: this._currentFPS })
    }
  }

  // ========================================================================
  // 私有方法 - 事件处理
  // ========================================================================

  /**
   * 鼠标移动事件处理
   */
  private _onMouseMove(event: MouseEvent): void {
    const rect = this._canvas!.getBoundingClientRect()
    this._mousePosition.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1
    )

    this._emitEvent('mouse_move', {
      position: this._mousePosition,
      originalEvent: event
    })
  }

  /**
   * 鼠标按下事件处理
   */
  private _onMouseDown(event: MouseEvent): void {
    this._emitEvent('mouse_down', {
      position: this._mousePosition,
      button: event.button,
      originalEvent: event
    })
  }

  /**
   * 鼠标抬起事件处理
   */
  private _onMouseUp(event: MouseEvent): void {
    this._emitEvent('mouse_up', {
      position: this._mousePosition,
      button: event.button,
      originalEvent: event
    })
  }

  /**
   * 鼠标点击事件处理
   */
  private _onClick(event: MouseEvent): void {
    // 执行射线检测
    const intersects = this._performRaycast()

    this._emitEvent('mouse_click', {
      position: this._mousePosition,
      intersects,
      originalEvent: event
    })
  }

  /**
   * 窗口尺寸变化事件处理
   */
  private _onWindowResize(): void {
    if (!this._renderer || !this._container) return

    const width = this._container.clientWidth
    const height = this._container.clientHeight
    const aspect = width / height

    // 更新渲染器尺寸
    this._renderer.setSize(width, height)

    // 更新3D相机
    if (this._camera3D) {
      this._camera3D.aspect = aspect
      this._camera3D.updateProjectionMatrix()
    }

    // 更新2D相机
    if (this._camera2D) {
      const frustumSize = height
      this._camera2D.left = -frustumSize * aspect / 2
      this._camera2D.right = frustumSize * aspect / 2
      this._camera2D.top = frustumSize / 2
      this._camera2D.bottom = -frustumSize / 2
      this._camera2D.updateProjectionMatrix()
    }

    this._emitEvent('window_resize', { width, height, aspect })
  }

  /**
   * 执行射线检测
   */
  private _performRaycast(): THREE.Intersection[] {
    if (!this._raycaster || !this._activeCamera || !this._scene) {
      return []
    }

    this._raycaster.setFromCamera(this._mousePosition, this._activeCamera)
    return this._raycaster.intersectObjects(this._scene.children, true)
  }

  // ========================================================================
  // 私有方法 - 事件系统
  // ========================================================================

  /**
   * 发送事件
   */
  private _emitEvent(eventName: string, data?: any): void {
    const listeners = this._eventListeners.get(eventName)
    if (listeners) {
      listeners.forEach(listener => {
        try {
          listener(data)
        } catch (error) {
          console.error(`Error in event listener for ${eventName}:`, error)
        }
      })
    }
  }

  /**
   * 添加事件监听器
   */
  addEventListener(eventName: string, listener: Function): void {
    if (!this._eventListeners.has(eventName)) {
      this._eventListeners.set(eventName, [])
    }
    this._eventListeners.get(eventName)!.push(listener)
  }

  /**
   * 移除事件监听器
   */
  removeEventListener(eventName: string, listener: Function): void {
    const listeners = this._eventListeners.get(eventName)
    if (listeners) {
      const index = listeners.indexOf(listener)
      if (index !== -1) {
        listeners.splice(index, 1)
      }
    }
  }

  // ========================================================================
  // 公共API - 工具方法
  // ========================================================================

  /**
   * 获取渲染统计信息
   */
  getRenderStats(): RenderStats {
    const info = this._renderer?.info
    return {
      fps: this._currentFPS,
      drawCalls: info?.render.calls || 0,
      triangles: info?.render.triangles || 0,
      geometries: info?.memory.geometries || 0,
      textures: info?.memory.textures || 0,
      memory: {
        geometries: info?.memory.geometries || 0,
        textures: info?.memory.textures || 0
      }
    }
  }

  /**
   * 获取引擎状态
   */
  getState(): EngineState {
    return this._state
  }

  /**
   * 获取当前FPS
   */
  getFPS(): number {
    return this._currentFPS
  }

  /**
   * 销毁引擎
   */
  destroy(): void {
    // 停止渲染循环
    this.stopRendering()

    // 清理事件监听器
    if (this._canvas) {
      this._canvas.removeEventListener('mousemove', this._onMouseMove)
      this._canvas.removeEventListener('mousedown', this._onMouseDown)
      this._canvas.removeEventListener('mouseup', this._onMouseUp)
      this._canvas.removeEventListener('click', this._onClick)
    }

    window.removeEventListener('resize', this._onWindowResize)

    // 清理场景系统
    if (this._sceneTree) {
      this._sceneTree.unloadAll().catch(error => {
        console.error('Error unloading scenes during destroy:', error)
      })
      this._sceneTree.destroy().catch(error => {
        console.error('Error destroying SceneTree:', error)
      })
      this._sceneTree = null
    }

    this._currentQAQScene = null
    this._rootNode = null

    // 清理测试对象
    this._cleanupTestObjects()

    // 清理Three.js资源
    if (this._renderer) {
      this._renderer.dispose()
    }

    if (this._scene) {
      this._scene.clear()
    }

    // 从容器中移除画布
    if (this._canvas && this._container) {
      this._container.removeChild(this._canvas)
    }

    // 重置状态
    this._state = EngineState.DESTROYED
    this._eventListeners.clear()

    // 清除单例引用
    Engine._instance = null

    this._emitEvent('engine_destroyed')
    console.log('🗑️ QAQ Game Engine destroyed')
  }

  // ========================================================================
  // 私有方法 - 调试和测试
  // ========================================================================

  /**
   * 创建测试对象 - 立方体和轨道控制器
   * 用于验证渲染管道是否正常工作
   */
  private _createTestObjects(): void {
    try {
      console.log('🎲 创建测试立方体和轨道控制器...')

      // 创建测试立方体
      const geometry = new THREE.BoxGeometry(100, 100, 100)
      const material = new THREE.MeshBasicMaterial({
        color: 0xff6b35,  // 橙色
        wireframe: false
      })
      this._testCube = new THREE.Mesh(geometry, material)
      this._testCube.position.set(0, 0, 0)
      this._testCube.name = 'EngineTestCube'

      // 添加到3D层
      if (this._layer3D) {
        this._layer3D.add(this._testCube)
        console.log('✅ 测试立方体已添加到3D层')
      }

      // 创建轨道控制器
      if (this._camera3D && this._canvas) {
        this._orbitControls = new OrbitControls(this._camera3D, this._canvas)
        this._orbitControls.enableDamping = true
        this._orbitControls.dampingFactor = 0.05
        this._orbitControls.enableZoom = true
        this._orbitControls.enableRotate = true
        this._orbitControls.enablePan = true

        // 设置控制器限制
        this._orbitControls.maxDistance = 1000
        this._orbitControls.minDistance = 50

        console.log('✅ 轨道控制器已创建')
      }

      // 设置3D相机位置
      if (this._camera3D) {
        this._camera3D.position.set(200, 200, 200)
        this._camera3D.lookAt(0, 0, 0)
        console.log('✅ 3D相机位置已设置')
      }

      // 启动测试立方体动画
      this._startTestCubeAnimation()

      console.log('🎉 测试对象创建完成')

    } catch (error) {
      console.error('❌ 创建测试对象失败:', error)
    }
  }

  /**
   * 启动测试立方体旋转动画
   */
  private _startTestCubeAnimation(): void {
    if (!this._testCube) return

    const animate = () => {
      if (this._testCube) {
        this._testCube.rotation.x += 0.01
        this._testCube.rotation.y += 0.01
      }

      // 更新轨道控制器
      if (this._orbitControls) {
        this._orbitControls.update()
      }

      this._testCubeAnimationId = requestAnimationFrame(animate)
    }

    animate()
    console.log('✅ 测试立方体动画已启动')
  }

  /**
   * 停止测试立方体动画
   */
  private _stopTestCubeAnimation(): void {
    if (this._testCubeAnimationId) {
      cancelAnimationFrame(this._testCubeAnimationId)
      this._testCubeAnimationId = null
      console.log('⏹️ 测试立方体动画已停止')
    }
  }

  /**
   * 清理测试对象
   */
  private _cleanupTestObjects(): void {
    try {
      // 停止动画
      this._stopTestCubeAnimation()

      // 清理测试立方体
      if (this._testCube && this._layer3D) {
        this._layer3D.remove(this._testCube)
        this._testCube.geometry.dispose()
        if (this._testCube.material instanceof THREE.Material) {
          this._testCube.material.dispose()
        }
        this._testCube = null
        console.log('🧹 测试立方体已清理')
      }

      // 清理轨道控制器
      if (this._orbitControls) {
        this._orbitControls.dispose()
        this._orbitControls = null
        console.log('🧹 轨道控制器已清理')
      }

    } catch (error) {
      console.error('❌ 清理测试对象失败:', error)
    }
  }

  /**
   * 公共方法：移除测试对象
   * 允许外部代码清理测试对象
   */
  public removeTestObjects(): void {
    this._cleanupTestObjects()
  }

  /**
   * 公共方法：获取测试立方体
   */
  public getTestCube(): THREE.Mesh | null {
    return this._testCube
  }

  /**
   * 公共方法：获取轨道控制器
   */
  public getOrbitControls(): OrbitControls | null {
    return this._orbitControls
  }
}

// ============================================================================
// 导出
// ============================================================================

export default Engine
