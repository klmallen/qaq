/**
 * QAQ 游戏引擎节点基类
 * 提供节点树结构、生命周期管理和基础功能
 * 类似于 Godot 的 Node 类
 */

import QaqObject from '../object/QaqObject'
import Engine from '../engine/Engine'
import * as THREE from 'three'
import type { NodeID, NodePath, Vector3 } from '../../types/core'
import { ProcessMode } from '../../types/core'

// ============================================================================
// 节点路径解析器
// ============================================================================

export class QaqNodePath {
  public path: string
  public subname: string
  public absolute: boolean

  constructor(path: string) {
    this.path = path
    this.subname = ''
    this.absolute = path.startsWith('/')

    // 解析子名称（如果有的话）
    const colonIndex = path.indexOf(':')
    if (colonIndex !== -1) {
      this.subname = path.substring(colonIndex + 1)
      this.path = path.substring(0, colonIndex)
    }
  }

  toString(): string {
    return this.subname ? `${this.path}:${this.subname}` : this.path
  }

  isEmpty(): boolean {
    return this.path === '' || this.path === '.'
  }

  getNames(): string[] {
    if (this.isEmpty()) return []

    const cleanPath = this.absolute ? this.path.substring(1) : this.path
    return cleanPath.split('/').filter(name => name !== '')
  }
}

// ============================================================================
// Node 基类
// ============================================================================

export class Node extends QaqObject {
  private _name: string = 'Node'
  private _parent: Node | null = null
  private _children: Node[] = []
  private _owner: Node | null = null
  private _processMode: ProcessMode = ProcessMode.INHERIT
  private _processPriority: number = 0
  private _isInsideTree: boolean = false
  private _isReady: boolean = false
  private _canProcess: boolean = true

  // ========================================================================
  // Three.js 集成属性
  // ========================================================================

  /** Three.js Object3D实例 - 每个节点在Three.js场景中的表示 */
  protected _object3D: THREE.Object3D

  /** 渲染层类型 - 决定节点添加到哪个渲染层 */
  protected _renderLayer: '2D' | '3D' | 'UI' = '3D'

  /** 是否可见 */
  protected _visible: boolean = true

  /** 变换是否需要同步到Three.js */
  protected _transformDirty: boolean = true

  constructor(name: string = 'Node') {
    super('Node')
    this._name = name

    // 创建Three.js Object3D实例
    this._object3D = this.createObject3D()
    this._object3D.name = name
    this._object3D.userData.qaqNode = this // 建立双向引用

    this.initializeNodeSignals()
    this.initializeNodeProperties()
  }

  /**
   * 创建Three.js Object3D实例
   * 子类可以重写此方法以创建特定类型的Three.js对象
   * @returns Three.js Object3D实例
   */
  protected createObject3D(): THREE.Object3D {
    return new THREE.Group()
  }

  // ========================================================================
  // 节点基础属性
  // ========================================================================

  get id(): string {
    return this.getInstanceId()
  }

  get name(): string {
    return this._name
  }

  set name(value: string) {
    if (value !== this._name) {
      const oldName = this._name
      this._name = value
      this.emit('renamed', oldName, value)
    }
  }

  get parent(): Node | null {
    return this._parent
  }

  get children(): readonly Node[] {
    return this._children
  }

  get owner(): Node | null {
    return this._owner
  }

  set owner(value: Node | null) {
    this._owner = value
  }

  get processMode(): ProcessMode {
    return this._processMode
  }

  set processMode(value: ProcessMode) {
    this._processMode = value
  }

  get processPriority(): number {
    return this._processPriority
  }

  set processPriority(value: number) {
    this._processPriority = value
  }

  // ========================================================================
  // Three.js 集成属性访问器
  // ========================================================================

  /**
   * 获取Three.js Object3D实例
   * @returns Three.js Object3D实例
   */
  get object3D(): THREE.Object3D {
    return this._object3D
  }

  /**
   * 获取渲染层类型
   * @returns 渲染层类型
   */
  get renderLayer(): '2D' | '3D' | 'UI' {
    return this._renderLayer
  }

  /**
   * 设置渲染层类型
   * @param value 渲染层类型
   */
  set renderLayer(value: '2D' | '3D' | 'UI') {
    if (this._renderLayer !== value) {
      const oldLayer = this._renderLayer
      this._renderLayer = value
      this._updateRenderLayer(oldLayer, value)
    }
  }

  /**
   * 获取可见性
   * @returns 是否可见
   */
  get visible(): boolean {
    return this._visible
  }

  /**
   * 设置可见性
   * @param value 是否可见
   */
  set visible(value: boolean) {
    if (this._visible !== value) {
      this._visible = value
      this._object3D.visible = value
      this.emit('visibility_changed', value)
    }
  }

  /**
   * 获取世界位置
   * @returns 世界位置向量
   */
  get globalPosition(): Vector3 {
    const worldPos = new THREE.Vector3()
    this._object3D.getWorldPosition(worldPos)
    return { x: worldPos.x, y: worldPos.y, z: worldPos.z }
  }

  /**
   * 设置世界位置
   * @param value 世界位置向量
   */
  set globalPosition(value: Vector3) {
    // 计算本地位置
    const parent = this._object3D.parent
    if (parent) {
      const worldPos = new THREE.Vector3(value.x, value.y, value.z)
      const localPos = parent.worldToLocal(worldPos)
      this._object3D.position.copy(localPos)
    } else {
      this._object3D.position.set(value.x, value.y, value.z)
    }
    this._transformDirty = false
  }

  /**
   * 获取本地位置
   * @returns 本地位置向量
   */
  get position(): Vector3 {
    const pos = this._object3D.position
    return { x: pos.x, y: pos.y, z: pos.z }
  }

  /**
   * 设置本地位置
   * @param value 本地位置向量
   */
  set position(value: Vector3) {
    this._object3D.position.set(value.x, value.y, value.z)
    this._transformDirty = false
  }

  get isInsideTree(): boolean {
    return this._isInsideTree
  }

  get isReady(): boolean {
    return this._isReady
  }

  // ========================================================================
  // 节点树操作
  // ========================================================================

  addChild(child: Node, forceReadableName: boolean = false): void {
    if (child._parent) {
      throw new Error(`Node "${child.name}" already has a parent`)
    }

    // 确保名称唯一
    if (forceReadableName) {
      child.name = this.getUniqueChildName(child.name)
    }

    child._parent = this
    this._children.push(child)

    // 同步Three.js场景图 - 添加子对象
    this._object3D.add(child._object3D)

    // 设置所有者
    if (!child._owner) {
      child._owner = this._owner || this
    }

    // 如果父节点在树中，将子节点也加入树
    if (this._isInsideTree) {
      child._enterTree()
    }

    this.emit('child_added', child)
    child.emit('parent_changed', this)
  }

  removeChild(child: Node): void {
    const index = this._children.indexOf(child)
    if (index === -1) {
      throw new Error(`Node "${child.name}" is not a child of "${this.name}"`)
    }

    // 如果子节点在树中，先移出树
    if (child._isInsideTree) {
      child._exitTree()
    }

    // 同步Three.js场景图 - 移除子对象
    this._object3D.remove(child._object3D)

    child._parent = null
    this._children.splice(index, 1)

    this.emit('child_removed', child)
    child.emit('parent_changed', null)
  }

  getChild(index: number): Node | null {
    return this._children[index] || null
  }

  getChildCount(): number {
    return this._children.length
  }

  getChildIndex(child: Node): number {
    return this._children.indexOf(child)
  }

  hasChild(child: Node): boolean {
    return this._children.includes(child)
  }

  moveChild(child: Node, toIndex: number): void {
    const fromIndex = this.getChildIndex(child)
    if (fromIndex === -1) {
      throw new Error(`Node "${child.name}" is not a child of "${this.name}"`)
    }

    if (toIndex < 0 || toIndex >= this._children.length) {
      throw new Error(`Invalid child index: ${toIndex}`)
    }

    // 移动子节点
    this._children.splice(fromIndex, 1)
    this._children.splice(toIndex, 0, child)

    this.emit('child_order_changed')
  }

  // ========================================================================
  // 节点查找
  // ========================================================================

  getNode(path: string): Node | null {
    const nodePath = new QaqNodePath(path)
    return this._getNodeByPath(nodePath)
  }

  hasNode(path: string): boolean {
    return this.getNode(path) !== null
  }

  findChild(name: string, recursive: boolean = true, owned: boolean = true): Node | null {
    // 在直接子节点中查找
    for (const child of this._children) {
      if (child.name === name && (!owned || child._owner === this._owner)) {
        return child
      }
    }

    // 递归查找
    if (recursive) {
      for (const child of this._children) {
        const found = child.findChild(name, true, owned)
        if (found) return found
      }
    }

    return null
  }

  findChildren(pattern: string, type?: string, recursive: boolean = true, owned: boolean = true): Node[] {
    const results: Node[] = []
    this._findChildrenRecursive(pattern, type, recursive, owned, results)
    return results
  }

  getPath(): string {
    if (!this._parent) return this.name

    const parentPath = this._parent.getPath()
    return parentPath === '' ? this.name : `${parentPath}/${this.name}`
  }

  getPathTo(node: Node): string {
    // 简化实现，实际应该计算相对路径
    return node.getPath()
  }

  // ========================================================================
  // 生命周期方法
  // ========================================================================

  _enterTree(): void {
    this._isInsideTree = true

    // 如果是根节点，将其添加到Engine的场景中
    if (!this._parent) {
      const engine = Engine.getInstance()
      const scene = engine.getScene()
      if (scene) {
        engine.addToLayer(this._object3D, this._renderLayer)
      }
    }

    this.emit('tree_entered')

    // 递归处理子节点
    for (const child of this._children) {
      child._enterTree()
    }

    // 如果还没有准备好，调用 _ready
    if (!this._isReady) {
      this._ready()
      this._isReady = true
    }
  }

  _exitTree(): void {
    this._isInsideTree = false

    // 如果是根节点，从Engine的场景中移除
    if (!this._parent) {
      const engine = Engine.getInstance()
      engine.removeFromLayer(this._object3D, this._renderLayer)
    }

    this.emit('tree_exiting')

    // 递归处理子节点
    for (const child of this._children) {
      child._exitTree()
    }

    this.emit('tree_exited')
  }

  // ========================================================================
  // Three.js 集成辅助方法
  // ========================================================================

  /**
   * 更新渲染层
   * @param oldLayer 旧渲染层
   * @param newLayer 新渲染层
   */
  private _updateRenderLayer(oldLayer: '2D' | '3D' | 'UI', newLayer: '2D' | '3D' | 'UI'): void {
    // 只有根节点需要更新渲染层
    if (!this._parent && this._isInsideTree) {
      const engine = Engine.getInstance()
      engine.removeFromLayer(this._object3D, oldLayer)
      engine.addToLayer(this._object3D, newLayer)
    }
  }

  /**
   * 同步变换到Three.js对象
   */
  protected syncTransformToThreeJS(): void {
    if (this._transformDirty) {
      // 子类可以重写此方法以实现特定的变换同步逻辑
      this._transformDirty = false
    }
  }

  /**
   * 从Three.js对象同步变换
   */
  protected syncTransformFromThreeJS(): void {
    // 子类可以重写此方法以实现特定的变换同步逻辑
  }

  /**
   * 获取Three.js世界矩阵
   * @returns Three.js世界矩阵
   */
  getWorldMatrix(): THREE.Matrix4 {
    this._object3D.updateMatrixWorld(true)
    return this._object3D.matrixWorld
  }

  /**
   * 根据Three.js对象查找对应的QAQ节点
   * @param object3D Three.js对象
   * @returns 对应的QAQ节点或null
   */
  static findNodeByObject3D(object3D: THREE.Object3D): Node | null {
    return object3D.userData.qaqNode || null
  }

  /**
   * 遍历Three.js对象层次结构查找QAQ节点
   * @param object3D Three.js对象
   * @param callback 回调函数
   */
  static traverseObject3D(object3D: THREE.Object3D, callback: (node: Node) => void): void {
    const node = Node.findNodeByObject3D(object3D)
    if (node) {
      callback(node)
    }

    for (const child of object3D.children) {
      Node.traverseObject3D(child, callback)
    }
  }

  _ready(): void {
    // 子类可重写此方法
    this.emit('ready')
  }

  _process(delta: number): void {
    // 子类可重写此方法
    if (this._canProcess) {
      // 递归处理子节点
      for (const child of this._children) {
        if (child._shouldProcess()) {
          child._process(delta)
        }
      }
    }
  }

  _physicsProcess(delta: number): void {
    // 子类可重写此方法
    if (this._canProcess) {
      // 递归处理子节点
      for (const child of this._children) {
        if (child._shouldProcess()) {
          child._physicsProcess(delta)
        }
      }
    }
  }

  // ========================================================================
  // 辅助方法
  // ========================================================================

  private getUniqueChildName(baseName: string): string {
    let name = baseName
    let counter = 1

    while (this._children.some(child => child.name === name)) {
      name = `${baseName}${counter}`
      counter++
    }

    return name
  }

  private _getNodeByPath(nodePath: QaqNodePath): Node | null {
    if (nodePath.isEmpty()) return this

    const names = nodePath.getNames()
    let current: Node = nodePath.absolute ? this.getRoot() : this

    for (const name of names) {
      if (name === '..') {
        current = current._parent || current
      } else {
        const child = current._children.find(c => c.name === name)
        if (!child) return null
        current = child
      }
    }

    return current
  }

  private getRoot(): Node {
    let root: Node = this
    while (root._parent) {
      root = root._parent
    }
    return root
  }

  private _shouldProcess(): boolean {
    switch (this._processMode) {
      case ProcessMode.INHERIT:
        return this._parent ? this._parent._shouldProcess() : true
      case ProcessMode.PAUSABLE:
        return true // TODO: 实现暂停系统
      case ProcessMode.WHEN_PAUSED:
        return false // TODO: 实现暂停系统
      case ProcessMode.ALWAYS:
        return true
      case ProcessMode.DISABLED:
        return false
      default:
        return true
    }
  }

  private _findChildrenRecursive(
    pattern: string,
    type: string | undefined,
    recursive: boolean,
    owned: boolean,
    results: Node[]
  ): void {
    for (const child of this._children) {
      // 检查名称匹配
      const nameMatches = pattern === '*' || child.name.includes(pattern)

      // 检查类型匹配
      const typeMatches = !type || child.getClassName() === type

      // 检查所有者
      const ownerMatches = !owned || child._owner === this._owner

      if (nameMatches && typeMatches && ownerMatches) {
        results.push(child)
      }

      // 递归搜索
      if (recursive) {
        child._findChildrenRecursive(pattern, type, true, owned, results)
      }
    }
  }

  // ========================================================================
  // 信号和属性初始化
  // ========================================================================

  protected initializeNodeSignals(): void {
    this.addSignal('ready')
    this.addSignal('tree_entered')
    this.addSignal('tree_exiting')
    this.addSignal('tree_exited')
    this.addSignal('child_added')
    this.addSignal('child_removed')
    this.addSignal('child_order_changed')
    this.addSignal('parent_changed')
    this.addSignal('renamed')
  }

  protected initializeNodeProperties(): void {
    this.addProperty({
      name: 'name',
      type: 'string',
      usage: 1 // STORAGE
    }, this._name)

    this.addProperty({
      name: 'process_mode',
      type: 'enum',
      usage: 1 // STORAGE
    }, this._processMode)

    this.addProperty({
      name: 'process_priority',
      type: 'int',
      usage: 1 // STORAGE
    }, this._processPriority)
  }

  // ========================================================================
  // 节点遍历
  // ========================================================================

  /**
   * 遍历节点树，对每个节点执行回调函数
   * @param callback 对每个节点执行的回调函数
   */
  traverse(callback: (node: Node) => void): void {
    callback(this)
    this._children.forEach(child => {
      child.traverse(callback)
    })
  }



  /**
   * 根据ID查找节点
   * @param id 节点ID
   * @returns 找到的节点或null
   */
  findNodeById(id: string): Node | null {
    let foundNode: Node | null = null
    this.traverse((node) => {
      if (node.id === id) {
        foundNode = node
      }
    })
    return foundNode
  }

  // ========================================================================
  // 销毁方法
  // ========================================================================

  destroy(): void {
    // 移除所有子节点
    while (this._children.length > 0) {
      const child = this._children[0]
      this.removeChild(child)
      child.destroy()
    }

    // 从父节点移除自己
    if (this._parent) {
      this._parent.removeChild(this)
    }

    super.destroy()
  }
}

export default Node
