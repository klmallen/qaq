<template>
  <div class="test-component">
    <h1>Test Component Works!</h1>
  </div>
</template>

<script setup lang="ts">
// 测试组件
</script>

<style scoped>
.test-component {
  padding: 20px;
  background: #333;
  color: white;
  text-align: center;
}
</style>
