export const engineConfig = {
  model: {
    defaultScale: 0.01
  }
}
